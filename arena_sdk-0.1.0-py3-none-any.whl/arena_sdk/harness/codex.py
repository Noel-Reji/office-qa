from __future__ import annotations

from pathlib import Path
from typing import Any

from harbor.agents.installed.codex import Codex as HarborCodex

from arena_sdk.harness.base import BaseHarnessAgent


class CodexAgent(BaseHarnessAgent):
    """Agent using Codex CLI as the execution harness.

    Delegates entirely to Harbor's Codex implementation which handles:
    - setup(): Installing Codex CLI into the container
    - run(): Executing commands via environment.exec()
    - populate_context_post_run(): Converting logs to ATIF trajectory

    Args:
        model_name: Required. Model name (e.g., "o3", "o3-mini").
        reasoning_effort: Reasoning effort level. Default "high".
        mcp_servers: Optional list of MCP server configurations.
        version: Optional Codex CLI version to install (e.g., "0.1.2504171455").
            If not specified, installs latest.
        prompt_template_path: Optional path to a Jinja2 template file for wrapping
            instructions. Template must contain {{ instruction }} variable.
        skills_dir: Optional path to skills directory in the environment.
            Skills will be copied to the agent's expected location during setup.

    Example:
        agent = CodexAgent(
            logs_dir=Path("/logs"),
            model_name="o3",
            reasoning_effort="high",
            version="0.1.2504171455",
            prompt_template_path=Path("prompts/codex_template.j2"),
            skills_dir="/app/skills",
        )
    """

    SUPPORTS_ATIF = True  # Codex produces ATIF trajectories

    @staticmethod
    def name() -> str:
        return "codex"

    def __init__(
        self,
        *args: Any,
        model_name: str,
        reasoning_effort: str = "high",
        mcp_servers: list[dict[str, Any]] | None = None,
        mcp_dir: str | None = None,
        version: str | None = None,
        prompt_template_path: Path | str | None = None,
        skills_dir: str | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(*args, model_name=model_name, **kwargs)
        self._harbor_agent = HarborCodex(
            logs_dir=self.logs_dir,
            logger=self.logger,
            model_name=model_name,
            reasoning_effort=reasoning_effort,
            mcp_servers=self._convert_mcp_servers(mcp_servers),
            version=version,
            prompt_template_path=prompt_template_path,
            skills_dir=skills_dir,
        )
        if mcp_dir is not None:
            self._harbor_agent.mcp_dir = mcp_dir
