from __future__ import annotations

from pathlib import Path
from typing import Any

from harbor.agents.installed.openhands import OpenHands as HarborOpenHands

from arena_sdk.harness.base import BaseHarnessAgent


class OpenHandsAgent(BaseHarnessAgent):
    """Agent using OpenHands as the execution harness.

    Delegates entirely to Harbor's OpenHands implementation which handles:
    - setup(): Installing OpenHands into the container
    - run(): Executing commands via environment.exec()
    - populate_context_post_run(): Converting logs to ATIF trajectory

    Args:
        model_name: Required. Model in LiteLLM format (e.g., "anthropic/claude-sonnet-4-20250514").
        mcp_servers: Optional list of MCP server configurations.
            Supports stdio, sse, and streamable-http transports.
        version: Optional OpenHands version to install.
        git_version: Optional git version for development builds.
        prompt_template_path: Optional path to a Jinja2 template file for wrapping
            instructions. Template must contain {{ instruction }} variable.
        disable_tool_calls: Disable native function calling (default: False).
        reasoning_effort: Reasoning effort level - "low", "medium", "high" (default: "medium").
        trajectory_raw_content: Use raw completions instead of parsed events (default: False).
            Note: Requires disable_tool_calls=True.
        api_base: Optional custom API base URL.
        model_info: Optional dict with token limits (max_input_tokens, max_output_tokens).

    MCP Server Configuration:
        Each MCP server dict should contain:
        - name: Server identifier
        - transport: "stdio", "sse", or "streamable-http"
        - command: Command to run (for stdio transport)
        - args: Command arguments (for stdio transport)
        - url: Server URL (for sse/streamable-http transports)

    Example:
        agent = OpenHandsAgent(
            logs_dir=Path("/logs"),
            model_name="anthropic/claude-sonnet-4-20250514",
            reasoning_effort="high",
            version="0.40.0",
            prompt_template_path=Path("prompts/openhands_template.j2"),
            mcp_servers=[
                {"name": "filesystem", "transport": "stdio", "command": "mcp-fs"},
            ],
        )
    """

    SUPPORTS_ATIF = True  # OpenHands produces ATIF trajectories

    @staticmethod
    def name() -> str:
        return "openhands"

    def __init__(
        self,
        *args: Any,
        model_name: str,
        mcp_servers: list[dict[str, Any]] | None = None,
        version: str | None = None,
        git_version: str | None = None,
        prompt_template_path: Path | str | None = None,
        disable_tool_calls: bool = False,
        reasoning_effort: str = "medium",
        trajectory_raw_content: bool = False,
        api_base: str | None = None,
        model_info: dict[str, int] | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(*args, model_name=model_name, **kwargs)

        # Build trajectory_config from parameter
        trajectory_config = None
        if trajectory_raw_content:
            trajectory_config = {"raw_content": True}

        self._harbor_agent = HarborOpenHands(
            logs_dir=self.logs_dir,
            logger=self.logger,
            model_name=model_name,
            mcp_servers=self._convert_mcp_servers(mcp_servers),
            version=version,
            git_version=git_version,
            prompt_template_path=prompt_template_path,
            disable_tool_calls=disable_tool_calls,
            reasoning_effort=reasoning_effort,
            trajectory_config=trajectory_config,
            api_base=api_base,
            model_info=model_info,
        )
