from __future__ import annotations

from pathlib import Path
from typing import Any

from harbor.agents.installed.opencode import OpenCode as HarborOpenCode

from arena_sdk.harness.base import BaseHarnessAgent


class OpenCodeAgent(BaseHarnessAgent):
    """Agent using OpenCode CLI as the execution harness.

    Delegates entirely to Harbor's OpenCode implementation which handles:
    - setup(): Installing OpenCode CLI into the container
    - run(): Executing commands via environment.exec()
    - populate_context_post_run(): Converting logs to ATIF trajectory

    Args:
        model_name: Required. Model in format "provider/model" (e.g., "anthropic/claude-sonnet-4-20250514").
        mcp_servers: Optional list of MCP server configurations.
            Supports stdio (local) and sse/streamable-http (remote) transports.
        version: Optional OpenCode CLI version to install.
        prompt_template_path: Optional path to a Jinja2 template file for wrapping
            instructions. Template must contain {{ instruction }} variable.
        skills_dir: Optional path to skills directory in the environment.
            Skills will be copied to the agent's expected location during setup.

    Supported providers: anthropic, openai, google, azure, amazon-bedrock,
        deepseek, groq, mistral, xai, github-copilot, huggingface, llama

    MCP Server Configuration:
        Each MCP server dict should contain:
        - name: Server identifier
        - transport: "stdio", "sse", or "streamable-http"
        - command: Command to run (for stdio transport)
        - args: Command arguments (for stdio transport)
        - url: Server URL (for sse/streamable-http transports)

    Example:
        agent = OpenCodeAgent(
            logs_dir=Path("/logs"),
            model_name="anthropic/claude-sonnet-4-20250514",
            version="1.0.0",
            prompt_template_path=Path("prompts/opencode_template.j2"),
            skills_dir="/app/skills",
            mcp_servers=[
                {"name": "filesystem", "transport": "stdio", "command": "mcp-fs"},
            ],
        )
    """

    SUPPORTS_ATIF = True  # OpenCode produces ATIF trajectories

    @staticmethod
    def name() -> str:
        return "opencode"

    def __init__(
        self,
        *args: Any,
        model_name: str,
        mcp_servers: list[dict[str, Any]] | None = None,
        mcp_dir: str | None = None,
        version: str | None = None,
        prompt_template_path: Path | str | None = None,
        skills_dir: str | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(*args, model_name=model_name, **kwargs)
        self._harbor_agent = HarborOpenCode(
            logs_dir=self.logs_dir,
            logger=self.logger,
            model_name=model_name,
            mcp_servers=self._convert_mcp_servers(mcp_servers),
            version=version,
            prompt_template_path=prompt_template_path,
            skills_dir=skills_dir,
        )
        if mcp_dir is not None:
            self._harbor_agent.mcp_dir = mcp_dir
