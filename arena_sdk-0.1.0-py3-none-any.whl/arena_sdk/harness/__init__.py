"""Arena SDK Harness Module — external agent harness integrations.

Provides base classes and implementations for agents that use external harness
systems (Codex, OpenHands, etc.) which write their own logs and
have those logs converted to ATIF format post-execution.

Core exports:
    BaseHarnessAgent — abstract base class for harness-based agents
"""

from arena_sdk.harness.base import BaseHarnessAgent

__all__ = ["BaseHarnessAgent"]

try:
    from arena_sdk.harness.codex import CodexAgent

    __all__.append("CodexAgent")
except ImportError:
    # Codex CLI not installed
    CodexAgent = None  # type: ignore[misc, assignment]

try:
    from arena_sdk.harness.goose import GooseAgent

    __all__.append("GooseAgent")
except ImportError:
    # Goose CLI not installed
    GooseAgent = None  # type: ignore[misc, assignment]

try:
    from arena_sdk.harness.openhands import OpenHandsAgent

    __all__.append("OpenHandsAgent")
except ImportError:
    # OpenHands not installed
    OpenHandsAgent = None  # type: ignore[misc, assignment]

try:
    from arena_sdk.harness.openhands_sdk import OpenHandsSDKAgent

    __all__.append("OpenHandsSDKAgent")
except ImportError:
    # OpenHands SDK not installed
    OpenHandsSDKAgent = None  # type: ignore[misc, assignment]

try:
    from arena_sdk.harness.opencode import OpenCodeAgent

    __all__.append("OpenCodeAgent")
except ImportError:
    # OpenCode CLI not installed
    OpenCodeAgent = None  # type: ignore[misc, assignment]
