from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

from harbor.agents.installed.openhands_sdk import OpenHandsSDK as HarborOpenHandsSDK

from arena_sdk.harness.base import BaseHarnessAgent

if TYPE_CHECKING:
    from harbor.environments.base import BaseEnvironment

_CONTAINER_SKILLS_DIR = "/root/.openhands-sdk/skills"


class OpenHandsSDKAgent(BaseHarnessAgent):
    """Agent using OpenHands SDK as the execution harness.

    This is the lightweight SDK version of OpenHands that supports both
    skills and MCP servers. It runs directly in the container via the
    OpenHands Software Agent SDK.

    Delegates entirely to Harbor's OpenHandsSDK implementation which handles:
    - setup(): Installing OpenHands SDK into the container
    - run(): Executing commands via environment.exec()
    - populate_context_post_run(): Converting logs to ATIF trajectory

    Args:
        model_name: Required. Model in LiteLLM format (e.g., "anthropic/claude-sonnet-4-20250514").
        version: Optional OpenHands SDK version to install. If not specified, installs latest.
        skills_dir: Optional path to local skills directory (relative to arena.yaml).
            Each subdirectory should contain a SKILL.md file. Uploaded to the container
            during setup() and passed to Harbor as skill_paths.
        load_skills: Whether to load skills (default: True).
        reasoning_effort: Reasoning effort level - "low", "medium", "high" (default: "high").
            Note: Stored but not yet wired in Harbor's OpenHandsSDK — the value is
            accepted for forward-compatibility but currently has no effect at runtime.
        mcp_servers: Optional list of MCP server configurations.
            Supports stdio, sse, and streamable-http transports.

    MCP Server Configuration:
        Each MCP server dict should contain:
        - name: Server identifier
        - transport: "stdio", "sse", or "streamable-http"
        - command: Command to run (for stdio transport)
        - args: Command arguments (for stdio transport)
        - url: Server URL (for sse/streamable-http transports)

    Example:
        agent = OpenHandsSDKAgent(
            logs_dir=Path("/logs"),
            model_name="anthropic/claude-sonnet-4-20250514",
            version="1.10.0",
            skills_dir="/app/skills",
            reasoning_effort="high",
            mcp_servers=[
                {"name": "filesystem", "transport": "stdio", "command": "mcp-fs"},
            ],
        )
    """

    SUPPORTS_ATIF = True  # OpenHandsSDK produces ATIF trajectories

    @staticmethod
    def name() -> str:
        return "openhands-sdk"

    def __init__(
        self,
        *args: Any,
        model_name: str,
        version: str | None = None,
        skills_dir: str | None = None,
        load_skills: bool = True,
        reasoning_effort: str = "high",
        mcp_servers: list[dict[str, Any]] | None = None,
        mcp_dir: str | None = None,
        prompt_template_path: Path | str | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(*args, model_name=model_name, **kwargs)

        # Store local skills_dir for uploading to container in setup()
        self._local_skills_dir = skills_dir

        # Convert skills_dir to the container path for Harbor's skill_paths
        effective_skill_paths = [_CONTAINER_SKILLS_DIR] if skills_dir else None

        self._harbor_agent = HarborOpenHandsSDK(
            logs_dir=self.logs_dir,
            logger=self.logger,
            model_name=model_name,
            version=version,
            skills_dir=skills_dir,
            skill_paths=effective_skill_paths,
            load_skills=load_skills,
            reasoning_effort=reasoning_effort,
            mcp_servers=self._convert_mcp_servers(mcp_servers),
            prompt_template_path=prompt_template_path,
        )
        if mcp_dir is not None:
            self._harbor_agent.mcp_dir = mcp_dir

    async def setup(self, environment: "BaseEnvironment") -> None:
        """Upload local skills to the container, then run Harbor's setup.

        Other harness agents (codex, goose, opencode) use
        _build_register_skills_command() to copy skills from a container-local
        path. OpenHands-SDK is different: skills_dir in arena.yaml is a local
        host path, so we upload the files before Harbor's setup installs the
        SDK.
        """
        if self._local_skills_dir:
            local_path = Path(self._local_skills_dir)
            if local_path.is_dir():
                await environment.exec(
                    command=f"mkdir -p {_CONTAINER_SKILLS_DIR}",
                )
                for skill_dir in local_path.iterdir():
                    if skill_dir.is_dir():
                        skill_file = skill_dir / "SKILL.md"
                        if skill_file.exists():
                            container_skill_dir = (
                                f"{_CONTAINER_SKILLS_DIR}/{skill_dir.name}"
                            )
                            await environment.exec(
                                command=f"mkdir -p {container_skill_dir}",
                            )
                            await environment.upload_file(
                                source_path=skill_file,
                                target_path=f"{container_skill_dir}/SKILL.md",
                            )

        await self._harbor_agent.setup(environment)

        await self._setup_mcp_servers(environment)
