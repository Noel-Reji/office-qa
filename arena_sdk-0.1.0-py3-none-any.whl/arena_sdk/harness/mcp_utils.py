"""MCP server discovery, configuration, and dependency installation.

Scans mcp/ subdirectories for mcp.toml manifests, validates server names
and entrypoints, builds the server config list, and installs per-server
dependencies in isolated venvs inside the container.
"""

from __future__ import annotations

import asyncio
import logging
import re
import tomllib
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from harbor.environments.base import BaseEnvironment

logger = logging.getLogger(__name__)

# Container path where mcp/ contents are uploaded
_CONTAINER_MCP_DIR = "/competitor-mcp"

# Directories to skip during server discovery
_SKIP_DIRS = frozenset({"__pycache__", ".git", ".venv", "node_modules"})

# Server directory name validation: lowercase, starts with letter, max 32 chars
_NAME_RE = re.compile(r"^[a-z][a-z0-9_-]{0,31}$")

# Dependency name: PEP 508 package name (letters, digits, -, _, ., optional extras)
_DEP_NAME_RE = re.compile(r"^[A-Za-z0-9]([A-Za-z0-9._-]*[A-Za-z0-9])?(\[[A-Za-z0-9_,-]+\])?$")

# Dependency version: * or operator + version string
_DEP_VERSION_RE = re.compile(r"^(\*|(==|>=|<=|!=|~=|>|<|===)[A-Za-z0-9.*+-]+)$")


@dataclass(frozen=True)
class MCPTomlConfig:
    """Parsed result of a server's mcp.toml."""

    entrypoint: str  # e.g. "server.py:mcp" (filename:symbol)
    filename: str  # e.g. "server.py"
    symbol: str  # e.g. "mcp"
    dependencies: dict[str, str] = field(default_factory=dict)  # e.g. {"fastmcp": "*"}
    has_dependencies: bool = False


def format_dep(name: str, version: str) -> str:
    """Format a dependency for pip/uv install.

    Examples:
        format_dep("pandas", "*")      → "pandas"
        format_dep("httpx", ">=0.27")  → "httpx>=0.27"
        format_dep("numpy", "==1.24")  → "numpy==1.24"
    """
    if version == "*":
        return name
    return f"{name}{version}"


def reject_symlinks(mcp_dir: Path) -> None:
    """Reject any symlinks under mcp_dir.

    Symlinks in a submitted tarball could point to files on the executor
    host (e.g., mcp/example/leak -> /etc/passwd). upload_dir follows
    symlinks, so this would leak host files into the container.

    Raises ValueError if any symlink is found.
    """
    for path in mcp_dir.rglob("*"):
        if path.is_symlink():
            raise ValueError(
                f"Symlink found in mcp_dir: {path.relative_to(mcp_dir)}. "
                f"Symlinks are not allowed in MCP server directories for security."
            )


def _validate_server_name(name: str) -> None:
    """Validate MCP server directory name.

    Must be lowercase, start with a letter, max 32 chars,
    only a-z, 0-9, underscore, hyphen.

    Raises ValueError if invalid.
    """
    if not _NAME_RE.match(name):
        raise ValueError(
            f"MCP server directory '{name}' has invalid name. "
            f"Must be lowercase, start with a letter, max 32 chars, "
            f"only a-z 0-9 _ - allowed."
        )


def parse_mcp_toml(server_dir: Path) -> MCPTomlConfig:
    """Parse server_dir/mcp.toml and return an MCPTomlConfig.

    Raises FileNotFoundError if mcp.toml is missing.
    Raises ValueError if the file is invalid or entrypoint is missing/bad.
    """
    toml_path = server_dir / "mcp.toml"

    if not toml_path.exists():
        raise FileNotFoundError(
            f"MCP server directory '{server_dir.name}' is missing mcp.toml. "
            f"Every server under mcp/ must have a mcp.toml file.\n"
        )

    try:
        data = tomllib.loads(toml_path.read_text(encoding="utf-8"))
    except tomllib.TOMLDecodeError as exc:
        raise ValueError(
            f"Invalid TOML in {server_dir.name}/mcp.toml: {exc}"
        ) from exc

    server_section = data.get("server", {})

    # entrypoint is REQUIRED
    entrypoint = server_section.get("entrypoint")
    if not entrypoint:
        raise ValueError(
            f"{server_dir.name}/mcp.toml is missing required field: "
            f"[server] entrypoint"
        )

    # Validate entrypoint format: must be "filename.py:symbol"
    if ":" not in entrypoint:
        raise ValueError(
            f"{server_dir.name}/mcp.toml: entrypoint must be 'filename.py:symbol', "
            f"got '{entrypoint}'. Example: entrypoint = \"server.py:mcp\""
        )
    filename, symbol = entrypoint.rsplit(":", 1)
    if not filename or not symbol:
        raise ValueError(
            f"{server_dir.name}/mcp.toml: entrypoint must have both filename and symbol, "
            f"got '{entrypoint}'. Example: entrypoint = \"server.py:mcp\""
        )
    if not symbol.isidentifier():
        raise ValueError(
            f"{server_dir.name}/mcp.toml: symbol must be a valid Python identifier, "
            f"got '{symbol}'"
        )
    if not filename.endswith(".py"):
        raise ValueError(
            f"{server_dir.name}/mcp.toml: entrypoint filename must end with .py, "
            f"got '{entrypoint}'"
        )
    # Reject path traversal: /, \, .. segments
    if "/" in filename or "\\" in filename or ".." in filename:
        raise ValueError(
            f"{server_dir.name}/mcp.toml: entrypoint must be a filename, "
            f"not a path. Got '{entrypoint}'"
        )
    # Enforce strict filename pattern
    stem = filename.removesuffix(".py")
    if not re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", stem):
        raise ValueError(
            f"{server_dir.name}/mcp.toml: entrypoint filename must be a valid "
            f"Python module name (letters, digits, underscores). Got '{filename}'"
        )

    # Validate entrypoint file exists and is within server_dir (no symlink escape)
    resolved = (server_dir / filename).resolve()
    if not resolved.is_relative_to(server_dir.resolve()):
        raise ValueError(
            f"{server_dir.name}/mcp.toml: entrypoint resolves outside server directory"
        )
    if not resolved.exists():
        raise ValueError(
            f"{server_dir.name}/mcp.toml: entrypoint file '{filename}' "
            f"not found in {server_dir}"
        )

    # Dependencies are optional — validate names and versions against strict regex
    dependencies = dict(server_section.get("dependencies", {}))
    for dep_name, dep_version in dependencies.items():
        if not isinstance(dep_name, str) or not _DEP_NAME_RE.match(dep_name):
            raise ValueError(
                f"{server_dir.name}/mcp.toml: invalid dependency name '{dep_name}'. "
                f"Must be a valid PEP 508 package name (letters, digits, -, _, .)"
            )
        if not isinstance(dep_version, str) or not _DEP_VERSION_RE.match(dep_version):
            raise ValueError(
                f"{server_dir.name}/mcp.toml: invalid version spec '{dep_version}' "
                f"for package '{dep_name}'. Must be '*' or operator+version "
                f"(e.g., '>=2.0', '==1.5.3')"
            )

    return MCPTomlConfig(
        entrypoint=entrypoint,
        filename=filename,
        symbol=symbol,
        dependencies=dependencies,
        has_dependencies=bool(dependencies),
    )


def discover_mcp_servers(mcp_dir: Path) -> list[dict]:
    """Scan mcp_dir for subdirectories with mcp.toml and build server configs.

    Each subdirectory under mcp_dir MUST have a mcp.toml file with an
    entrypoint field. Servers are returned sorted alphabetically by name.

    Args:
        mcp_dir: Path to the mcp/ directory on the host.

    Returns:
        List of server config dicts, each with:
            name, transport, command, dependencies,
            has_dependencies, entrypoint, filename, symbol.

    Raises:
        FileNotFoundError: If a subdirectory is missing mcp.toml.
        ValueError: If mcp.toml is invalid, entrypoint missing, or
            directory name is invalid.
    """
    if not mcp_dir.is_dir():
        return []

    servers = []

    for server_dir in sorted(mcp_dir.iterdir()):
        # Skip non-directories, hidden dirs, and known noise
        if not server_dir.is_dir():
            continue
        if server_dir.name.startswith(".") or server_dir.name in _SKIP_DIRS:
            continue

        # Validate directory name
        _validate_server_name(server_dir.name)

        # Parse mcp.toml (raises if missing or invalid)
        config = parse_mcp_toml(server_dir)

        servers.append(
            {
                "name": server_dir.name,
                "transport": "stdio",
                "command": "python3",  # may be rewritten to venv python later
                "dependencies": config.dependencies,
                "has_dependencies": config.has_dependencies,
                "entrypoint": config.entrypoint,
                "filename": config.filename,
                "symbol": config.symbol,
            }
        )

    return servers


# ---------------------------------------------------------------------------
# Dependency installation (async — runs commands inside the container)
# ---------------------------------------------------------------------------

# uv is installed by the agent harness (e.g. Goose's setup installs it to
# ~/.local/bin/uv). Use the full path since ~/.local/bin may not be on PATH
# in all exec() contexts. Containers run as root so $HOME is /root.
_UV_CMD = "/root/.local/bin/uv"


async def install_single_mcp_server(
    environment: "BaseEnvironment",
    server: dict,
) -> list[str]:
    """Create venv and install deps for one MCP server. Returns log lines.

    On failure, cleans up the partial venv to avoid stale state on retry.
    """
    lines: list[str] = []
    name = server["name"]
    deps = server["dependencies"]
    venv_path = f"{_CONTAINER_MCP_DIR}/{name}/.venv"
    dep_str = " ".join(format_dep(k, v) for k, v in deps.items())

    try:
        # Create venv
        result = await environment.exec(f"{_UV_CMD} venv {venv_path}")
        lines.append(f"[{name}] venv: exit={result.return_code}")
        if result.return_code != 0:
            raise RuntimeError(
                f"Failed to create venv for MCP server '{name}': "
                f"stdout={result.stdout}, stderr={result.stderr}"
            )

        # Install deps
        result = await environment.exec(
            f"{_UV_CMD} pip install --python {venv_path}/bin/python {dep_str}"
        )
        lines.append(
            f"[{name}] install: exit={result.return_code} deps={dep_str}\n"
            f"  stdout: {(result.stdout or '').strip()}\n"
            f"  stderr: {(result.stderr or '').strip()}"
        )
        if result.return_code != 0:
            raise RuntimeError(
                f"Failed to install dependencies for MCP server '{name}': "
                f"stdout={result.stdout}, stderr={result.stderr}\n"
                f"Dependencies: {deps}\n"
                f"Ensure the container has internet access (environment.network: sandbox)"
            )
    except Exception:
        # Clean up partial venv to avoid stale state on retry
        await environment.exec(f"rm -rf {venv_path}")
        raise

    return lines


async def install_mcp_dependencies(
    environment: "BaseEnvironment",
    servers: list[dict],
    logs_dir: Path | None = None,
) -> None:
    """Create per-server venvs and install dependencies inside the container.

    Requires uv to be installed by the agent harness setup (e.g. Goose
    installs it to ~/.local/bin/uv via the astral.sh install script).
    Installs servers in parallel when there are 2+ servers.
    Captures all install output to {logs_dir}/mcp/install.log for debugging.
    """
    if not servers:
        return

    install_log_lines: list[str] = []

    # Install servers — parallel when 2+, sequential when 1
    if len(servers) > 1:
        results = await asyncio.gather(
            *[install_single_mcp_server(environment, s) for s in servers]
        )
        for lines in results:
            install_log_lines.extend(lines)
    else:
        lines = await install_single_mcp_server(environment, servers[0])
        install_log_lines.extend(lines)

    # Best-effort: write install log for debugging
    try:
        if logs_dir:
            mcp_log_dir = Path(logs_dir) / "mcp"
            mcp_log_dir.mkdir(parents=True, exist_ok=True)
            (mcp_log_dir / "install.log").write_text(
                "\n".join(install_log_lines), encoding="utf-8"
            )
    except Exception:
        pass  # best-effort — don't fail the trial
