"""BaseHarnessAgent — abstract base class for agents using external harness systems.

Delegates to Harbor for execution and trajectory writing. Harbor's
populate_context_post_run() handles converting logs to ATIF trajectory,
writing trajectory.json, and populating context with metrics.
"""

from __future__ import annotations

import contextvars
import logging
from pathlib import Path
from typing import TYPE_CHECKING, Any

from harbor.agents.installed.skills import build_skills_section
from harbor.models.task.config import MCPServerConfig
from harbor.models.trial.paths import EnvironmentPaths

from arena_sdk.agent import ArenaAgent
from arena_sdk.harness.mcp_utils import (
    _CONTAINER_MCP_DIR as _MCP_CONTAINER_DIR,
)
from arena_sdk.harness.mcp_utils import (
    discover_mcp_servers,
    install_mcp_dependencies,
    reject_symlinks,
)
from arena_sdk.pricing import calculate_cost

logger = logging.getLogger(__name__)

# Task-local context for concurrent run() safety
_run_context: contextvars.ContextVar["AgentContext | None"] = contextvars.ContextVar("_run_context", default=None)

_CONTAINER_SKILLS_DIR = "/competitor-skills"

if TYPE_CHECKING:
    from harbor.agents.installed.base import BaseInstalledAgent
    from harbor.environments.base import BaseEnvironment
    from harbor.models.agent.context import AgentContext


class BaseHarnessAgent(ArenaAgent):
    """Abstract base class for agents using external harness systems.

    Provides common functionality for Harbor-based agents:
    - MCP server configuration conversion
    - Default solve() implementation that delegates to Harbor

    Subclasses should:
    1. Call super().__init__() in their __init__
    2. Override name() as a @staticmethod returning the agent identifier
    3. Set self._harbor_agent to the Harbor agent instance

    Example:
        class MyAgent(BaseHarnessAgent):
            @staticmethod
            def name() -> str:
                return "my-agent"

            def __init__(self, *, model: str, **kwargs):
                super().__init__(**kwargs)
                self._harbor_agent = HarborMyAgent(
                    logs_dir=self.logs_dir,
                    model_name=model,
                )
    """

    _harbor_agent: "BaseInstalledAgent"
    _cached_skills_section: str | None = None

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)

    @staticmethod
    def _convert_mcp_servers(
        mcp_servers: list[dict[str, Any]] | None,
    ) -> "list[MCPServerConfig] | None":
        """Convert MCP server dicts to MCPServerConfig objects.

        Args:
            mcp_servers: List of MCP server configuration dicts, or None.

        Returns:
            List of MCPServerConfig objects, or None if input was None.
        """
        if not mcp_servers:
            return None

        return [MCPServerConfig(**s) if isinstance(s, dict) else s for s in mcp_servers]

    def version(self) -> str | None:
        """Return the version from the inner Harbor agent.

        Delegates to the Harbor agent so that version info passed to the
        harness agent constructor is correctly reported in trial results.
        """
        return self._harbor_agent.version()

    async def setup(self, environment: "BaseEnvironment") -> None:
        """Setup the Harbor agent in the environment.

        Called by Harbor Trial with a dedicated 360s timeout before run().

        If skills_dir points to a directory on the host (from the extracted
        submission tarball), reads SKILL.md content, uploads the files into
        the container, and swaps skills_dir to the container path so that
        Harbor's ``_build_register_skills_command()`` copies from the right
        location inside the container.

        If mcp_dir points to a directory on the host, uploads all files to
        /competitor-mcp/ in the container and rewrites mcp_servers args paths
        from host-relative (e.g., "mcp/server.py") to container-absolute
        (e.g., "/competitor-mcp/server.py").
        """
        skills_dir = self._harbor_agent.skills_dir
        if skills_dir:
            host_path = Path(skills_dir)
            if host_path.is_dir():
                self._cached_skills_section = build_skills_section(skills_dir)
                logger.info("Uploading skills from %s to %s", host_path, _CONTAINER_SKILLS_DIR)
                await environment.upload_dir(host_path, _CONTAINER_SKILLS_DIR)
                self._harbor_agent.skills_dir = _CONTAINER_SKILLS_DIR

        # Harbor agent setup runs first — it installs the agent binary and
        # tools like uv/node into the container (e.g. Goose's setup installs
        # uv to ~/.local/bin/uv). MCP dep installation needs uv, so it must
        # run after the harbor agent setup.
        await self._harbor_agent.setup(environment)

        await self._setup_mcp_servers(environment)

    async def _setup_mcp_servers(self, environment: "BaseEnvironment") -> None:
        """Auto-discover local MCP servers, install deps, and wire up for the agent.

        Reads mcp_dir from the Harbor agent, scans for mcp/*/mcp.toml on the host,
        uploads sources to the container, creates per-server venvs for servers with
        dependencies, and builds the final mcp_servers list (local + remote merged).

        Shared by BaseHarnessAgent.setup() and OpenHandsSDKAgent.setup().
        """
        mcp_dir = getattr(self._harbor_agent, "mcp_dir", None)
        if not mcp_dir:
            return

        host_mcp_path = Path(mcp_dir)
        if not host_mcp_path.is_dir():
            return

        # Step 1: Auto-discover servers from mcp/*/mcp.toml
        discovered = discover_mcp_servers(host_mcp_path)
        if not discovered:
            logger.warning("mcp_dir '%s' has no server subdirectories", mcp_dir)
            return

        # Step 2: Reject symlinks (prevents leaking executor host files)
        reject_symlinks(host_mcp_path)

        # Step 3: Upload entire mcp/ to container
        logger.info("Uploading mcp_dir from %s to %s", host_mcp_path, _MCP_CONTAINER_DIR)
        await environment.upload_dir(host_mcp_path, _MCP_CONTAINER_DIR)

        # Step 3: Create per-server venvs and install deps
        servers_with_deps = [s for s in discovered if s["has_dependencies"]]
        if servers_with_deps:
            logs_dir = getattr(self._harbor_agent, "logs_dir", None)
            await install_mcp_dependencies(environment, servers_with_deps, logs_dir)

        # Step 4: Write per-server launcher scripts and build mcp_servers list
        mcp_servers = []
        for server in discovered:
            if server["has_dependencies"]:
                command = f"{_MCP_CONTAINER_DIR}/{server['name']}/.venv/bin/python"
            else:
                command = "python3"

            # Write a launcher script that imports the server module and runs
            # it in stdio mode. Using upload_file (not heredoc) avoids shell
            # injection via symbol names and quoting issues across agent configs.
            server_dir = f"{_MCP_CONTAINER_DIR}/{server['name']}"
            module_name = server["filename"].removesuffix(".py")
            symbol = server["symbol"]
            launcher_path = f"{server_dir}/_run.py"
            launcher_code = (
                f"import sys\n"
                f"sys.path.insert(0, '{server_dir}')\n"
                f"from {module_name} import {symbol}\n"
                f"{symbol}.run(transport='stdio')\n"
            )
            # Write launcher to a temp file on host, upload to container.
            # upload_file raises on failure, so we never register a broken server.
            import tempfile
            with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
                f.write(launcher_code)
                tmp_launcher = f.name
            try:
                await environment.upload_file(tmp_launcher, launcher_path)
            except Exception as e:
                raise RuntimeError(
                    f"Failed to write launcher for MCP server '{server['name']}': {e}"
                ) from e
            finally:
                Path(tmp_launcher).unlink(missing_ok=True)

            mcp_servers.append({
                "name": server["name"],
                "transport": "stdio",
                "command": command,
                "args": [launcher_path],
            })

        # Merge with any remote/packaged servers from mcp_servers
        existing = self._harbor_agent.mcp_servers or []
        if existing:
            mcp_servers.extend(
                s if isinstance(s, dict) else s.model_dump(exclude_none=True)
                for s in existing
            )

        # Check for duplicate server names (would break agent configs like TOML)
        names = [s["name"] for s in mcp_servers]
        duplicates = [n for n in set(names) if names.count(n) > 1]
        if duplicates:
            raise ValueError(
                f"Duplicate MCP server names: {sorted(duplicates)}. "
                f"Local servers (from mcp_dir) and remote servers (from mcp_servers) "
                f"must have unique names. Rename one of the duplicates."
            )

        self._harbor_agent.mcp_servers = self._convert_mcp_servers(mcp_servers)
        self._harbor_agent.mcp_dir = _MCP_CONTAINER_DIR

    async def solve(
        self,
        instruction: str,
        environment: "BaseEnvironment",
    ) -> dict[str, Any]:
        """Execute the harness via Harbor.

        Delegates to the Harbor agent's run() which executes the agent
        and populates context with metrics/trajectory.

        If skills were uploaded in setup(), the cached skills section is
        injected into the instruction here. Harbor's build_skills_section()
        in create_run_agent_commands() will return None (the container path
        doesn't exist on the host), so this is the only source of skills
        content in the instruction.

        Args:
            instruction: The task instruction.
            environment: The execution environment.

        Returns:
            Empty dict (metadata comes from context via _run_context ContextVar).

        Raises:
            RuntimeError: If called directly without going through run().
        """
        context = _run_context.get()
        if context is None:
            raise RuntimeError(
                "solve() must be called through run(), not directly. "
                "Use agent.run(instruction, environment, context) instead."
            )

        if self._cached_skills_section:
            instruction = instruction + self._cached_skills_section

        await self._harbor_agent.run(instruction, environment, context)

        return {}

    async def run(
        self,
        instruction: str,
        environment: "BaseEnvironment",
        context: "AgentContext",
    ) -> None:
        """Harbor entry point.

        Overrides ArenaAgent.run() because harness agents:
        1. Don't use TracedEnvironment (Harbor handles tracing)
        2. Don't write their own trajectory (Harbor does via populate_context_post_run)
        3. Store context in self._run_context for solve() to access

        Uses try/finally to ensure trajectory extraction even on timeout.
        Harbor's Trial fallback (_maybe_populate_agent_context) won't work here
        because it checks isinstance(agent, BaseInstalledAgent), but Trial sees
        BaseHarnessAgent (an ArenaAgent subclass), not the internal _harbor_agent.

        Uses contextvars.ContextVar for context storage to support concurrent
        run() calls on the same agent instance (e.g., asyncio.gather).
        """
        token = _run_context.set(context)
        try:
            await self.solve(instruction, environment)
        finally:
            # If context is still empty (timeout/crash before populate_context_post_run),
            # download agent logs and populate metrics from them.
            #
            # Harbor Trial downloads logs AFTER agent.run() returns, but its
            # _maybe_populate_agent_context() checks isinstance(BaseInstalledAgent)
            # which fails for BaseHarnessAgent.  We must download here ourselves
            # so populate_context_post_run() can read them from disk.
            if context.is_empty():
                await self._download_and_populate(environment, context)

            # Calculate cost from OpenRouter pricing using token counts
            self._calculate_cost(context)

            _run_context.reset(token)  # Restore previous value (thread-safe cleanup)

    async def _download_and_populate(
        self,
        environment: "BaseEnvironment",
        context: "AgentContext",
    ) -> None:
        """Download agent logs from the environment and populate context metrics.

        For non-mounted environments (Daytona) the session files live inside the
        container and must be downloaded before populate_context_post_run() can
        parse them.  Mounted environments (Docker) already have them on disk.
        """
        if not getattr(environment, "is_mounted", True):
            try:
                await environment.download_dir(
                    source_dir=EnvironmentPaths.agent_dir.as_posix(),
                    target_dir=self._harbor_agent.logs_dir,
                )
            except Exception:
                logger.debug(
                    "Failed to download agent logs for %s (best-effort)",
                    self.name(),
                )

        try:
            self._harbor_agent.populate_context_post_run(context)
        except Exception:
            pass  # Best effort - don't mask the original exception

    def _calculate_cost(self, context: "AgentContext") -> None:
        """Calculate cost_usd from token counts using OpenRouter model pricing.

        Always overwrites context.cost_usd when pricing is available.
        """
        model = self.model_name

        if not model or not context.n_input_tokens or not context.n_output_tokens:
            return

        try:
            cost = calculate_cost(model, context.n_input_tokens, context.n_output_tokens)
            if cost is not None:
                context.cost_usd = cost
        except Exception as e:
            logger.warning("Failed to calculate cost for model %s: %s", model, e)
