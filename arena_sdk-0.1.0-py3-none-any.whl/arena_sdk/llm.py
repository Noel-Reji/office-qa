"""Traced LLM client for ATIF recording.

Wraps litellm.completion() / acompletion() with automatic ATIF step recording.
Each call records a step with source, message, model info, tool calls,
token metrics, and cost. Accumulates rollout details (token IDs, logprobs)
for Harbor's context.rollout_details.
"""

from __future__ import annotations

import json
import time
from typing import Any, Callable

import litellm

from arena_core.enums import StepSource
from arena_sdk._trajectory import annotate_component


class TracedLLMClient:
    """LLM client that records every completion as an ATIF trajectory step.

    Usage in agent's solve():
        response = self.llm.completion(model="gpt-4o", messages=[...])
        response = await self.llm.acompletion(model="anthropic/claude-sonnet-4", messages=[...])
    """

    def __init__(
        self,
        steps: list[dict[str, Any]],
        get_current_component: Callable[[], str | None],
        model_name: str | None = None,
    ) -> None:
        self._steps = steps
        self._get_current_component = get_current_component
        self._default_model = model_name

        # Rollout detail accumulators (for context.rollout_details)
        self._prompt_token_ids_list: list[list[int]] = []
        self._completion_token_ids_list: list[list[int]] = []
        self._logprobs_list: list[list[float]] = []

    def completion(self, **kwargs: Any) -> Any:
        """Sync completion via litellm. Records an ATIF step."""
        model, messages = self._prepare_call(kwargs)

        start = time.monotonic()
        try:
            response = litellm.completion(**kwargs)
        except Exception as exc:
            latency_ms = (time.monotonic() - start) * 1000
            self._record_error_step(model, messages, exc, latency_ms)
            raise
        latency_ms = (time.monotonic() - start) * 1000

        self._record_step(model, messages, response, latency_ms)
        return response

    async def acompletion(self, **kwargs: Any) -> Any:
        """Async completion via litellm. Records an ATIF step."""
        model, messages = self._prepare_call(kwargs)

        start = time.monotonic()
        try:
            response = await litellm.acompletion(**kwargs)
        except Exception as exc:
            latency_ms = (time.monotonic() - start) * 1000
            self._record_error_step(model, messages, exc, latency_ms)
            raise
        latency_ms = (time.monotonic() - start) * 1000

        self._record_step(model, messages, response, latency_ms)
        return response

    @property
    def rollout_details(self) -> list[dict[str, Any]]:
        """Build rollout details matching Harbor's RolloutDetail format.

        Returns a single-element list containing one RolloutDetail dict with
        nested lists (one inner list per turn). Empty list if no data collected.

        Harbor's RolloutDetail TypedDict:
            prompt_token_ids: list[list[int]]
            completion_token_ids: list[list[int]]
            logprobs: list[list[float]]
        """
        has_data = (
            any(ids for ids in self._prompt_token_ids_list)
            or any(ids for ids in self._completion_token_ids_list)
            or any(lp for lp in self._logprobs_list)
        )
        if not has_data:
            return []

        detail: dict[str, Any] = {}
        if any(ids for ids in self._prompt_token_ids_list):
            detail["prompt_token_ids"] = [list(ids) for ids in self._prompt_token_ids_list]
        if any(ids for ids in self._completion_token_ids_list):
            detail["completion_token_ids"] = [list(ids) for ids in self._completion_token_ids_list]
        if any(lp for lp in self._logprobs_list):
            detail["logprobs"] = [list(lp) for lp in self._logprobs_list]
        return [detail]

    def reset(self) -> None:
        """Reset rollout accumulators for a new run."""
        self._prompt_token_ids_list.clear()
        self._completion_token_ids_list.clear()
        self._logprobs_list.clear()

    def _prepare_call(self, kwargs: dict[str, Any]) -> tuple[str | None, list[dict[str, Any]]]:
        """Prepare kwargs for a litellm call: inject rollout params, resolve model."""
        self._inject_rollout_params(kwargs)
        model = kwargs.get("model") or self._default_model
        if model and "model" not in kwargs:
            kwargs["model"] = model
        return model, kwargs.get("messages", [])

    def _inject_rollout_params(self, kwargs: dict[str, Any]) -> None:
        """Inject logprobs and token ID request params into litellm kwargs."""
        kwargs.setdefault("logprobs", True)
        extra_body = dict(kwargs.get("extra_body", {}))
        extra_body.setdefault("return_token_ids", True)
        kwargs["extra_body"] = extra_body

    def _record_error_step(
        self,
        model: str | None,
        messages: list[dict[str, Any]],
        exception: Exception,
        latency_ms: float,
    ) -> None:
        """Record an ATIF step for a failed LLM call."""
        last_user_msg = ""
        for msg in reversed(messages):
            if msg.get("role") == "user":
                content = msg.get("content", "")
                last_user_msg = content if isinstance(content, str) else str(content)
                break

        step: dict[str, Any] = {
            "source": StepSource.AGENT,
            "message": last_user_msg,
            "model_name": model,
            "observation": {
                "results": [{"type": "text", "content": str(exception)}],
            },
            "extra": {
                "error": True,
                "error_type": type(exception).__name__,
                "latency_ms": round(latency_ms, 2),
            },
        }
        annotate_component(step["extra"], self._get_current_component)
        self._steps.append(step)

    def _record_step(
        self,
        model: str | None,
        messages: list[dict[str, Any]],
        response: Any,
        latency_ms: float,
    ) -> None:
        """Extract data from litellm ModelResponse and append an ATIF step."""
        choice = response.choices[0] if response.choices else None
        assistant_message = ""
        reasoning_content = None
        raw_tool_calls = None

        if choice and choice.message:
            assistant_message = choice.message.content or ""
            reasoning_content = getattr(choice.message, "reasoning_content", None)
            raw_tool_calls = choice.message.tool_calls

        # Extract usage
        usage = response.usage
        prompt_tokens = getattr(usage, "prompt_tokens", None) if usage else None
        completion_tokens = getattr(usage, "completion_tokens", None) if usage else None
        cached_tokens = None
        if usage:
            cache_info = getattr(usage, "prompt_tokens_details", None)
            if cache_info:
                cached_tokens = getattr(cache_info, "cached_tokens", None)

        # Compute cost — try _hidden_params first (litellm caches cost there),
        # then fall back to litellm.completion_cost()
        cost_usd = None
        try:
            hidden = getattr(response, "_hidden_params", None)
            if hidden and isinstance(hidden, dict):
                cost_usd = hidden.get("response_cost")
            if cost_usd is None:
                cost_usd = litellm.completion_cost(completion_response=response)
        except Exception:
            pass

        # Last user message becomes the step message field
        last_user_msg = ""
        for msg in reversed(messages):
            if msg.get("role") == "user":
                content = msg.get("content", "")
                last_user_msg = content if isinstance(content, str) else str(content)
                break

        # Build step using StepSource enum
        step: dict[str, Any] = {
            "source": StepSource.AGENT,
            "message": last_user_msg,
            "model_name": model,
        }

        if reasoning_content:
            step["reasoning_content"] = reasoning_content

        tool_calls = self._normalize_tool_calls(raw_tool_calls)
        if tool_calls:
            step["tool_calls"] = tool_calls

        # Metrics — StepMetrics-compatible fields (including rollout fields)
        metrics: dict[str, Any] = {}
        if prompt_tokens is not None:
            metrics["prompt_tokens"] = prompt_tokens
        if completion_tokens is not None:
            metrics["completion_tokens"] = completion_tokens
        if cached_tokens is not None:
            metrics["cached_tokens"] = cached_tokens
        if cost_usd is not None:
            metrics["cost_usd"] = cost_usd

        # Rollout data also goes into per-step metrics (StepMetrics supports these)
        prompt_token_ids, completion_token_ids, logprobs = self._extract_rollout(response, choice)
        if prompt_token_ids:
            metrics["prompt_token_ids"] = prompt_token_ids
        if completion_token_ids:
            metrics["completion_token_ids"] = completion_token_ids
        if logprobs:
            metrics["logprobs"] = logprobs

        if metrics:
            step["metrics"] = metrics

        # Extra
        extra: dict[str, Any] = {"latency_ms": round(latency_ms, 2)}
        if assistant_message:
            extra["assistant_response"] = assistant_message
        annotate_component(extra, self._get_current_component)
        step["extra"] = extra

        self._steps.append(step)

        # Also accumulate rollout data for context.rollout_details
        self._prompt_token_ids_list.append(prompt_token_ids)
        self._completion_token_ids_list.append(completion_token_ids)
        self._logprobs_list.append(logprobs)

    def _normalize_tool_calls(self, raw_tool_calls: Any) -> list[dict[str, Any]] | None:
        """Normalize LLM tool calls to ATIF ToolCall shape.

        ATIF requires arguments as dict[str, Any], but LLM providers return
        arguments as JSON strings. Explicitly parse them.
        """
        if not raw_tool_calls:
            return None

        normalized = []
        for tc in raw_tool_calls:
            args = tc.function.arguments
            if isinstance(args, str):
                try:
                    args = json.loads(args)
                except (json.JSONDecodeError, TypeError):
                    args = {"_raw": args}
            normalized.append(
                {
                    "tool_call_id": tc.id,
                    "function_name": tc.function.name,
                    "arguments": args if isinstance(args, dict) else {},
                }
            )
        return normalized

    def _extract_rollout(self, response: Any, choice: Any) -> tuple[list[int], list[int], list[float]]:
        """Extract rollout detail data from a single response."""
        # Prompt token IDs
        prompt_token_ids: list[int] = getattr(response, "prompt_token_ids", None) or []

        # Completion token IDs
        completion_token_ids: list[int] = []
        if choice:
            provider_fields = getattr(choice, "provider_specific_fields", None)
            if provider_fields and isinstance(provider_fields, dict):
                completion_token_ids = provider_fields.get("token_ids", []) or []

        # Logprobs
        logprobs: list[float] = []
        if choice and choice.logprobs and hasattr(choice.logprobs, "content"):
            content_logprobs = choice.logprobs.content
            if content_logprobs:
                logprobs = [lp.logprob for lp in content_logprobs if hasattr(lp, "logprob")]

        return prompt_token_ids, completion_token_ids, logprobs
