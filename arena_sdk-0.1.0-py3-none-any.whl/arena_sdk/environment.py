"""Traced environment wrapper for ATIF recording.

Wraps a Harbor BaseEnvironment via composition — intercepts exec() to record
ATIF steps, delegates everything else transparently via __getattr__.
"""

from __future__ import annotations

import time
from typing import Any, Callable

from arena_core.enums import StepSource
from arena_sdk._trajectory import annotate_component


class TracedEnvironment:
    """Wraps a Harbor BaseEnvironment, records exec() calls as ATIF steps.

    Uses composition (not inheritance) to avoid BaseEnvironment's complex
    constructor. All non-intercepted attribute access delegates transparently
    to the wrapped environment.
    """

    def __init__(
        self,
        environment: Any,
        steps: list[dict[str, Any]],
        get_current_component: Callable[[], str | None],
    ) -> None:
        self._environment = environment
        self._steps = steps
        self._get_current_component = get_current_component

    async def exec(
        self,
        command: str,
        cwd: str | None = None,
        env: dict[str, str] | None = None,
        timeout_sec: int | None = None,
        **kwargs: Any,
    ) -> Any:
        """Execute a command and record an ATIF step.

        Delegates to the wrapped environment's exec(), records timing,
        output, and return code as an ATIF step.

        Returns the original ExecResult from the wrapped environment.
        """
        start = time.monotonic()
        try:
            result = await self._environment.exec(command, cwd=cwd, env=env, timeout_sec=timeout_sec, **kwargs)
        except Exception as exc:
            latency_ms = (time.monotonic() - start) * 1000
            error_step: dict[str, Any] = {
                "source": StepSource.AGENT,
                "message": command,
                "observation": {
                    "results": [{"type": "text", "content": str(exc)}],
                },
                "extra": {
                    "error": True,
                    "error_type": type(exc).__name__,
                    "latency_ms": round(latency_ms, 2),
                },
            }
            annotate_component(error_step["extra"], self._get_current_component)
            self._steps.append(error_step)
            raise

        latency_ms = (time.monotonic() - start) * 1000

        # Build output content from stdout/stderr
        output_parts = []
        if result.stdout:
            output_parts.append(result.stdout)
        if result.stderr:
            output_parts.append(result.stderr)
        content = "\n".join(output_parts) if output_parts else ""

        step: dict[str, Any] = {
            "source": StepSource.AGENT,
            "message": command,
            "observation": {
                "results": [{"type": "text", "content": content}],
            },
            "extra": {
                "return_code": result.return_code,
                "latency_ms": round(latency_ms, 2),
            },
        }

        annotate_component(step["extra"], self._get_current_component)

        self._steps.append(step)
        return result

    def __getattr__(self, name: str) -> Any:
        """Delegate all other attribute access to the wrapped environment."""
        return getattr(self._environment, name)
