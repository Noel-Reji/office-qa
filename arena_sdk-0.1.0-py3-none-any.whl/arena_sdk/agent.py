"""ArenaAgent — base class for Arena agent development.

Extends Harbor's BaseAgent with automatic ATIF trajectory recording.
Developers subclass ArenaAgent, implement solve(), and get tracing for free.
"""

from __future__ import annotations

import contextvars
import json
import logging
from abc import abstractmethod
from contextlib import contextmanager
from pathlib import Path
from typing import Any

from harbor.agents.base import BaseAgent
from harbor.models.agent.context import AgentContext

from arena_core.enums import StepSource
from arena_core.models.trajectory import Observation, StepMetrics, ToolCall
from arena_sdk._trajectory import aggregate_step_metrics, annotate_component, build_trajectory
from arena_sdk.environment import TracedEnvironment
from arena_sdk.llm import TracedLLMClient

# Task-scoped component tracking — safe for asyncio.gather() concurrency
_current_component: contextvars.ContextVar[str | None] = contextvars.ContextVar("_current_component", default=None)


class ArenaAgent(BaseAgent):
    """Base class for Arena agents with automatic ATIF trajectory recording.

    Subclass this and implement:
        - name() -> str: Agent identifier (static)
        - solve(instruction, environment) -> dict: Your agent logic

    Optional overrides:
        - version() -> str | None: Agent version (default: None)
        - setup(environment) -> None: Pre-run setup (default: no-op)

    Usage:
        class MyAgent(ArenaAgent):
            @staticmethod
            def name() -> str:
                return "my-agent"

            async def solve(self, instruction: str, environment) -> dict:
                response = self.llm.completion(
                    model="gpt-4o",
                    messages=[{"role": "user", "content": instruction}],
                )
                return {"metadata": {"answer": response.choices[0].message.content}}
    """

    SUPPORTS_ATIF = True

    def __init__(
        self,
        logs_dir: Path,
        model_name: str | None = None,
        logger: logging.Logger | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(logs_dir, model_name=model_name, logger=logger, **kwargs)

        self._steps: list[dict[str, Any]] = []
        self._get_component = lambda: _current_component.get(None)

        self.llm = TracedLLMClient(
            steps=self._steps,
            get_current_component=self._get_component,
            model_name=model_name,
        )

    # --- Abstract methods for agent developers ---

    @abstractmethod
    async def solve(
        self,
        instruction: str,
        environment: Any,
    ) -> dict[str, Any]:
        """Implement your agent logic here.

        Args:
            instruction: The task instruction from Harbor.
            environment: TracedEnvironment wrapping Harbor's BaseEnvironment.

        Returns:
            Dict with optional keys:
                - metadata: dict — arbitrary metadata for AgentContext
                - n_input_tokens: int — override auto-calculated tokens
                - n_output_tokens: int — override auto-calculated tokens
                - n_cache_tokens: int — override auto-calculated tokens
                - cost_usd: float — override auto-calculated cost
        """

    # --- Concrete overrides of BaseAgent abstract methods ---

    def version(self) -> str | None:
        """Agent version. Override to return a version string."""
        return None

    async def setup(self, environment: Any) -> None:
        """Pre-run setup. Override for custom initialization."""

    async def run(
        self,
        instruction: str,
        environment: Any,
        context: AgentContext,
    ) -> None:
        """Harbor entry point. Wraps environment, calls solve(), populates context.

        Do NOT override this method. Implement solve() instead.
        """
        # Reset state for this run
        self._steps.clear()
        self.llm.reset()
        _current_component.set(None)

        # Wrap environment for tracing
        traced_env = TracedEnvironment(
            environment=environment,
            steps=self._steps,
            get_current_component=self._get_component,
        )

        try:
            result = await self.solve(instruction, traced_env)
            self._populate_context(context, result or {})
            self._write_trajectory()
        except Exception:
            try:
                self._write_trajectory()
            except Exception:
                self.logger.warning("Failed to write partial trajectory", exc_info=True)
            raise  # Bare raise preserves original traceback

    @contextmanager
    def component(self, name: str):
        """Annotate trace steps with a component name.

        Safe for concurrent use with asyncio.gather() — each Task gets
        its own ContextVar copy.

        Usage:
            with self.component("planner"):
                response = self.llm.completion(...)
        """
        token = _current_component.set(name)
        try:
            yield
        finally:
            _current_component.reset(token)

    def log_step(
        self,
        source: str | StepSource,
        message: str = "",
        model_name: str | None = None,
        reasoning_content: str | None = None,
        tool_calls: list[dict[str, Any]] | None = None,
        observation: str | dict | None = None,
        metrics: dict[str, Any] | None = None,
        extra: dict[str, Any] | None = None,
    ) -> None:
        """Manually record an ATIF step.

        For custom steps not captured by TracedLLMClient or TracedEnvironment.

        Args:
            source: Step source — validated against StepSource enum.
            message: Step message (default empty string).
            observation: String auto-wrapped to ATIF Observation shape.
        """
        # Validate source against StepSource enum
        if isinstance(source, str):
            source = StepSource(source)

        step: dict[str, Any] = {
            "source": source,
            "message": message,
        }

        if model_name is not None:
            step["model_name"] = model_name
        if reasoning_content is not None:
            step["reasoning_content"] = reasoning_content
        if tool_calls is not None:
            for tc in tool_calls:
                ToolCall.model_validate(tc)
            step["tool_calls"] = tool_calls

        # Auto-wrap string observation to ATIF shape
        if observation is not None:
            if isinstance(observation, str):
                observation = {"results": [{"type": "text", "content": observation}]}
            Observation.model_validate(observation)
            step["observation"] = observation

        if metrics is not None:
            StepMetrics.model_validate(metrics)
            step["metrics"] = metrics

        step_extra = dict(extra) if extra else {}
        annotate_component(step_extra, self._get_component)
        if step_extra:
            step["extra"] = step_extra

        self._steps.append(step)

    # --- Internal methods ---

    def _populate_context(self, context: AgentContext, result: dict[str, Any]) -> None:
        """Populate Harbor AgentContext from solve() result and recorded data."""
        totals = aggregate_step_metrics(self._steps)

        total_prompt = totals["total_prompt_tokens"]
        total_completion = totals["total_completion_tokens"]
        total_cached = totals["total_cached_tokens"]
        total_cost = totals["total_cost_usd"]

        # Allow solve() result to override auto-calculated values
        context.n_input_tokens = result.get("n_input_tokens", total_prompt or None)
        context.n_output_tokens = result.get("n_output_tokens", total_completion or None)
        context.n_cache_tokens = result.get("n_cache_tokens", total_cached or None)
        context.cost_usd = result.get("cost_usd", total_cost or None)
        context.metadata = result.get("metadata")
        context.rollout_details = self.llm.rollout_details or None

    def _write_trajectory(self) -> None:
        """Write ATIF trajectory JSON to logs directory."""
        trajectory = build_trajectory(
            steps=self._steps,
            agent_name=self.name(),
            agent_version=self.version() or "0.0.0",
            model_name=self.model_name,
        )

        self.logs_dir.mkdir(parents=True, exist_ok=True)
        output_path = self.logs_dir / "trajectory.json"

        with open(output_path, "w") as f:
            json.dump(trajectory, f, indent=2, default=str)
