"""Arena SDK — developer tools for building Arena agents.

Core exports:
    ArenaAgent — base class for all Arena agents (extends Harbor's BaseAgent)
    BaseHarnessAgent — base class for agents using external harness systems

Usage:
    from arena_sdk import ArenaAgent

    # For harness-based agents:
    from arena_sdk.harness import CodexAgent
"""

from arena_sdk.agent import ArenaAgent
from arena_sdk.arena_environment import ArenaEnvironment
from arena_sdk.harness import BaseHarnessAgent

__all__ = ["ArenaAgent", "ArenaEnvironment", "BaseHarnessAgent"]

# Optional harness implementations
try:
    from arena_sdk.harness import CodexAgent

    __all__.append("CodexAgent")
except (ImportError, RuntimeError):
    CodexAgent = None  # type: ignore[misc, assignment]

try:
    from arena_sdk.harness import GooseAgent

    __all__.append("GooseAgent")
except (ImportError, RuntimeError):
    GooseAgent = None  # type: ignore[misc, assignment]

try:
    from arena_sdk.harness import OpenHandsAgent

    __all__.append("OpenHandsAgent")
except (ImportError, RuntimeError):
    OpenHandsAgent = None  # type: ignore[misc, assignment]

try:
    from arena_sdk.harness import OpenCodeAgent

    __all__.append("OpenCodeAgent")
except (ImportError, RuntimeError):
    OpenCodeAgent = None  # type: ignore[misc, assignment]
