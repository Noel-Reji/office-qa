"""ArenaEnvironment - Context manager for easy environment lifecycle management.

Wraps Harbor's BaseEnvironment with automatic start/stop and simplified configuration.
"""

from __future__ import annotations

import tempfile
import uuid
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

from harbor.environments.factory import EnvironmentFactory
from harbor.models.environment_type import EnvironmentType
from harbor.models.task.config import EnvironmentConfig
from harbor.models.trial.paths import TrialPaths

if TYPE_CHECKING:
    from harbor.environments.base import BaseEnvironment


def _get_environment_aliases() -> dict[str, Any]:
    return {
        "local": EnvironmentType.DOCKER,
        "docker": EnvironmentType.DOCKER,
        "daytona": EnvironmentType.DAYTONA,
        "e2b": EnvironmentType.E2B,
        "modal": EnvironmentType.MODAL,
        "runloop": EnvironmentType.RUNLOOP,
        "gke": EnvironmentType.GKE,
    }


class ArenaEnvironment:
    def __init__(
        self,
        environment_type: str,
        docker_image: str,
        *,
        output_dir: Path | str | None = None,
        force_build: bool = True,
        cleanup: bool = True,
        cpus: int | None = None,
        memory_mb: int | None = None,
        storage_mb: int | None = None,
        allow_internet: bool | None = None,
    ) -> None:
        """Initialize an Arena environment.

        Args:
            environment_type: Environment backend - "local", "docker", "daytona",
                "e2b", "modal", "runloop", or "gke".
            docker_image: Docker image to use (e.g., "python:3.11-slim").
            output_dir: Trial output directory. Auto-generated if None.
            force_build: Force rebuild of Docker image. Default True.
            cleanup: Delete environment after exit. Default True.
            cpus: Override CPU count.
            memory_mb: Override memory limit in MB.
            storage_mb: Override storage limit in MB.
            allow_internet: Override internet access setting.
        """
        self._env_type = environment_type
        self._docker_image = docker_image
        self._output_dir = Path(output_dir) if output_dir else None
        self._force_build = force_build
        self._cleanup = cleanup
        self._config_overrides = {
            "cpus": cpus,
            "memory_mb": memory_mb,
            "storage_mb": storage_mb,
            "allow_internet": allow_internet,
        }
        self._environment: BaseEnvironment | None = None
        self._trial_paths: TrialPaths | None = None
        self._temp_dir: tempfile.TemporaryDirectory[str] | None = None

    async def __aenter__(self) -> "BaseEnvironment":
        # 1. Resolve environment type
        aliases = _get_environment_aliases()
        env_type = aliases.get(self._env_type.lower())
        if env_type is None:
            valid_types = list(aliases.keys())
            raise ValueError(f"Unknown environment type: '{self._env_type}'. " f"Valid options: {valid_types}")

        # 2. Create trial paths
        if self._output_dir:
            trial_dir = self._output_dir
        else:
            timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            run_id = uuid.uuid4().hex[:8]
            trial_dir = Path(f"./trials/run-{timestamp}-{run_id}")

        self._trial_paths = TrialPaths(trial_dir=trial_dir)
        self._trial_paths.mkdir()

        # 3. Build environment config
        env_config = EnvironmentConfig()
        for key, val in self._config_overrides.items():
            if val is not None:
                setattr(env_config, key, val)

        # 4. Create a temporary directory with Dockerfile
        self._temp_dir = tempfile.TemporaryDirectory(prefix="arena_env_")
        environment_dir = Path(self._temp_dir.name)
        dockerfile_path = environment_dir / "Dockerfile"
        dockerfile_path.write_text(f"FROM {self._docker_image}\n")
        environment_name = self._docker_image.replace("/", "_").replace(":", "_")

        session_id = f"arena-{uuid.uuid4().hex[:8]}"

        self._environment = EnvironmentFactory.create_environment(
            type=env_type,
            environment_dir=environment_dir,
            environment_name=environment_name,
            session_id=session_id,
            trial_paths=self._trial_paths,
            task_env_config=env_config,
        )

        # 5. Start environment
        await self._environment.start(force_build=self._force_build)
        return self._environment

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any,
    ) -> None:
        """Stop and optionally cleanup environment."""
        try:
            if self._environment:
                await self._environment.stop(delete=self._cleanup)
        finally:
            # Clean up temporary directory even if stop() raises
            if self._temp_dir:
                self._temp_dir.cleanup()
                self._temp_dir = None

    @property
    def trial_paths(self) -> "TrialPaths | None":
        """Access trial paths for trajectory and log locations."""
        return self._trial_paths
