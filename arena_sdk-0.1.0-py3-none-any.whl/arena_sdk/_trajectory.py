"""Internal ATIF trajectory builder.

Constructs trajectory JSON conforming to ATIF v1.5 from accumulated step dicts.
Output is validatable against arena_core.models.trajectory.Trajectory but produced
as raw dicts for performance.
"""

from __future__ import annotations

import time
import uuid
from typing import Any, Callable

from arena_core.enums import StepSource


def aggregate_step_metrics(steps: list[dict[str, Any]]) -> dict[str, int | float]:
    """Sum token counts and cost across steps with metrics."""
    total_prompt = total_completion = total_cached = 0
    total_cost = 0.0
    for step in steps:
        m = step.get("metrics")
        if m:
            total_prompt += m.get("prompt_tokens") or 0
            total_completion += m.get("completion_tokens") or 0
            total_cached += m.get("cached_tokens") or 0
            total_cost += m.get("cost_usd") or 0.0
    return {
        "total_prompt_tokens": total_prompt,
        "total_completion_tokens": total_completion,
        "total_cached_tokens": total_cached,
        "total_cost_usd": total_cost,
    }


def annotate_component(
    extra: dict[str, Any], get_component: Callable[[], str | None]
) -> None:
    """Add arena_component to extra dict if a component is active."""
    component = get_component()
    if component:
        extra["arena_component"] = component


def build_trajectory(
    steps: list[dict[str, Any]],
    agent_name: str,
    agent_version: str | None = None,
    model_name: str | None = None,
) -> dict[str, Any]:
    """Build a complete ATIF v1.5 trajectory dict.

    If steps is empty, injects a synthetic system step to satisfy
    ATIF's min_length=1 requirement on Trajectory.steps.
    """
    if not steps:
        steps = [
            {
                "step_id": 1,
                "timestamp": _iso_now(),
                "source": StepSource.SYSTEM,
                "message": "Agent terminated before recording any steps",
            }
        ]

    normalized_steps = []
    for i, step in enumerate(steps, start=1):
        normalized = dict(step)
        normalized["step_id"] = i
        normalized_steps.append(normalized)

    totals = aggregate_step_metrics(normalized_steps)

    return {
        "schema_version": "ATIF-v1.5",
        "session_id": str(uuid.uuid4()),
        "agent": {
            "name": agent_name,
            "version": agent_version,
            "model_name": model_name,
        },
        "steps": normalized_steps,
        "final_metrics": {
            **totals,
            "total_steps": len(normalized_steps),
        },
        "extra": {
            "arena_sdk_version": "0.1.0",
        },
    }


def _iso_now() -> str:
    """ISO 8601 timestamp string."""
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
