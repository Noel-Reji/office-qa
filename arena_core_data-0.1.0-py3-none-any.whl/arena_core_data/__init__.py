"""Vendored Unicode security data for arena_core.

This package ships the UTS #39 confusables.txt as a separate workspace
member so the 745 KB file does not bloat the arena_core wheel. The data
is loaded by ``arena_core.security.unicode_skeleton`` via
``importlib.resources.files("arena_core_data") / "confusables.txt"``.
"""

from __future__ import annotations

__version__ = "0.1.0"
