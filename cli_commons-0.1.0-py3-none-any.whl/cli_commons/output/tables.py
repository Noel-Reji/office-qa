from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from arena_core.enums import TaskStatus
from cli_commons.output.console import get_console

if TYPE_CHECKING:
    from arena_core.models.competition import CompetitionDetail
    from arena_core.models.leaderboard import LeaderboardResponse
    from arena_core.models.results import RunResults, ScoreSummary
    from arena_core.models.submission import Submission, SubmissionComparison, SubmissionListResponse
    from arena_core.models.team import QuotaResponse
    from arena_core.models.trajectory import TrajectoryDetail, TrajectoryListResponse


_MEDALS = {1: "\U0001f947", 2: "\U0001f948", 3: "\U0001f949"}


def format_task_status(status: TaskStatus | str) -> str:
    """Format pass/fail status with Rich markup."""
    if status == TaskStatus.PASSED:
        return "[green]PASS[/green]"
    return "[red]FAIL[/red]"


def _format_score(score: float, fmt: str = ".3f") -> str:
    """Return a plain formatted score string (no color styling)."""
    return f"{score:{fmt}}"


def _medal(rank: int) -> str:
    """Return medal emoji for ranks 1-3, empty string otherwise."""
    return _MEDALS.get(rank, "")


def _relative_time(dt: datetime | str | None, *, now: datetime | None = None) -> str:
    """Format a datetime as a human-readable relative time string."""
    if dt is None:
        return "-"
    if isinstance(dt, str):
        dt = datetime.fromisoformat(dt)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    if now is None:
        now = datetime.now(timezone.utc)
    seconds = int((now - dt).total_seconds())
    if seconds < 60:
        return "just now"
    if seconds < 3600:
        return f"{seconds // 60}m ago"
    if seconds < 86400:
        return f"{seconds // 3600}h ago"
    if seconds < 604800:
        return f"{seconds // 86400}d ago"
    return dt.strftime("%Y-%m-%d")


def _score_summary_lines(stats: ScoreSummary) -> list[str]:
    """Return formatted score summary lines for any ScoreSummary-like object."""
    return [
        f"Score: [bold]{_format_score(stats.score)}[/bold]",
        f"Tasks: {stats.tasks_passed} passed, {stats.tasks_failed} failed ({stats.tasks_total} total)",
        f"Avg latency: {stats.avg_latency_sec:.1f}s",
        f"Total cost: ${stats.total_cost_usd:.2f}",
    ]


def _print_score_summary(stats: ScoreSummary, console: Console) -> None:
    """Print score summary lines to the console."""
    for i, line in enumerate(_score_summary_lines(stats)):
        prefix = "\n  " if i == 0 else "  "
        console.print(f"{prefix}{line}")


def print_run_results(results: RunResults, console: Console | None = None):
    """Print local run results as a Rich table."""
    if console is None:
        console = get_console()

    _print_score_summary(results, console)

    if results.tasks:
        table = Table(title="Task Results")
        table.add_column("Task")
        table.add_column("Status")
        table.add_column("Reward", justify="right")
        table.add_column("Latency", justify="right")
        table.add_column("Cost", justify="right")

        for task in results.tasks:
            table.add_row(
                task.task_id,
                format_task_status(task.status),
                f"{task.reward:.2f}",
                f"{task.latency_sec:.1f}s",
                f"${task.cost_usd:.3f}",
            )

        console.print(table)


def print_submission_results(submission: Submission, console: Console):
    """Print full submission results."""
    lines = [
        f"Submission: {submission.id}",
        f"Status: {submission.status}",
    ]

    ex = submission.stages.execute if submission.stages else None
    if ex is not None:
        lines.extend(_score_summary_lines(ex))

    console.print(Panel("\n".join(lines), title="Submission Results", border_style="green"))

    if ex is not None and ex.categories:
        table = Table(title="Category Scores")
        table.add_column("Category")
        table.add_column("Score", justify="right")
        for cat, score in ex.categories.items():
            table.add_row(cat, _format_score(score))
        console.print(table)


def print_local_comparison(data: tuple[RunResults, RunResults], console: Console):
    """Print comparison between two local runs."""
    a, b = data
    console.print(f"  Score: {a.score:.3f} vs {b.score:.3f}")


def print_server_comparison(data: SubmissionComparison, console: Console):
    """Print comparison between two server submissions."""
    console.print(f"\n  Baseline: {data.baseline.agent_name} ({data.baseline.score:.3f})")
    console.print(f"  Comparison: {data.comparison.agent_name} ({data.comparison.score:.3f})")
    console.print(f"  Delta: {data.delta.score:+.3f}")

    if data.categories:
        table = Table(title="Category Comparison")
        table.add_column("Category")
        table.add_column("Baseline", justify="right")
        table.add_column("Comparison", justify="right")
        table.add_column("Delta", justify="right")
        for cat, comp in data.categories.items():
            table.add_row(cat, f"{comp.baseline:.3f}", f"{comp.comparison:.3f}", f"{comp.delta:+.3f}")
        console.print(table)

    if data.task_changes:
        tc = data.task_changes
        console.print(
            f"\n  Fixed: {tc.fixed} | Regressed: {tc.regressed} | Unchanged: {tc.unchanged_pass + tc.unchanged_fail}"
        )


def print_submission_list(data: SubmissionListResponse, console: Console):
    """Print submission list."""
    table = Table(title="Submissions")
    table.add_column("ID")
    table.add_column("Agent")
    table.add_column("Competition")
    table.add_column("Status")
    table.add_column("Score", justify="right")
    table.add_column("Submitted", justify="right")

    now = datetime.now(timezone.utc)
    for item in data.items:
        agent_str = "-"
        if item.agent is not None:
            version_part = f" v{item.agent.version}" if item.agent.version is not None else ""
            agent_str = f"{item.agent.name}{version_part}"

        score_val = None
        if item.stages and item.stages.execute is not None:
            score_val = item.stages.execute.score

        score_str = _format_score(score_val) if score_val is not None else "-"

        table.add_row(
            str(item.id),
            agent_str,
            item.competition or "-",
            item.status,
            score_str,
            _relative_time(item.submitted_at, now=now),
        )

    console.print(table)


def print_leaderboard(data: LeaderboardResponse, console: Console):
    """Print leaderboard."""
    table = Table(title=f"Leaderboard \u2014 {data.competition_name or ''}")
    table.add_column("Rank", justify="right")
    table.add_column("Team")
    table.add_column("Agent")
    table.add_column("Score", justify="right")
    table.add_column("Submitted", justify="right")

    now = datetime.now(timezone.utc)
    for entry in data.items:
        medal = _medal(entry.rank)
        rank_str = f"{entry.rank} {medal}" if medal else str(entry.rank)
        table.add_row(
            rank_str,
            entry.team_name or "-",
            entry.agent_name or "-",
            _format_score(entry.score),
            _relative_time(entry.submitted_at, now=now),
        )

    console.print(table)


def print_competition_detail(comp: CompetitionDetail, console: Console):
    """Print competition details."""
    lines = [
        f"[bold]{comp.name}[/bold]",
        f"Slug: {comp.slug or '-'}",
        f"Description: {comp.description or '-'}",
        f"Sponsor: {comp.sponsor.name if comp.sponsor else '-'}",
        f"Status: {comp.status}",
        f"Start: {comp.start_at}",
        f"End: {comp.end_at}",
        f"Registration deadline: {comp.registration_deadline}",
    ]
    console.print(Panel("\n".join(lines), title="Competition", border_style="blue"))


def print_quota(quota: QuotaResponse, console: Console):
    """Print quota info."""
    lines = [
        f"Team: {quota.team_id}",
        f"Competition: {quota.competition}",
        f"Submissions today: {quota.used_today}/{quota.daily_limit}",
        f"Remaining: [bold]{quota.remaining}[/bold]",
        f"Resets at: {quota.resets_at}",
    ]
    console.print(Panel("\n".join(lines), title="Quota", border_style="cyan"))


def print_trajectory_list(data: TrajectoryListResponse, console: Console):
    """Print trajectory list."""
    if data.message and not data.items:
        console.print(f"\n  [yellow]{data.message}[/yellow]\n")
        return

    table = Table(title="Traces")
    table.add_column("Trace ID")
    table.add_column("Task")
    table.add_column("Status")
    table.add_column("Reward", justify="right")
    table.add_column("Latency", justify="right")

    for item in data.items:
        table.add_row(
            item.trajectory_id,
            item.task_id,
            format_task_status(item.status),
            f"{item.reward:.2f}",
            f"{item.latency_sec:.1f}s" if item.latency_sec is not None else "-",
        )

    console.print(table)


def print_trajectory_detail(traj: TrajectoryDetail, console: Console):
    """Print full trajectory detail."""
    console.print(f"\n  Trajectory: {traj.trajectory_id}")
    console.print(f"  Task: {traj.task_id}")
    console.print(f"  Status: {traj.status}")
    console.print(f"  Reward: {traj.reward}")

    if traj.trajectory and traj.trajectory.steps:
        console.print(f"\n  Steps ({len(traj.trajectory.steps)}):")
        for step in traj.trajectory.steps:
            source = step.source.upper()
            console.print(f"\n    [bold][{source}] Step {step.step_id}[/bold]")
            if step.message:
                truncated = step.message[:200]
                suffix = "..." if len(step.message) > 200 else ""
                console.print(f"    Message: {truncated}{suffix}")
            if step.tool_calls:
                for tc in step.tool_calls:
                    console.print(f"    Tool: {tc.function_name}({tc.arguments})")
            if step.observation:
                for result in step.observation.results:
                    content = result.content or ""
                    truncated = content[:200]
                    suffix = "..." if len(content) > 200 else ""
                    console.print(f"    Output: {truncated}{suffix}")
            if step.metrics:
                console.print(
                    f"    Metrics: tokens={step.metrics.prompt_tokens or 0}+{step.metrics.completion_tokens or 0}, cost=${step.metrics.cost_usd or 0:.4f}"
                )


def print_local_history(runs_dir: Path, limit: int, console: Console):
    """Show local run history from .arena/runs/."""
    if not runs_dir.exists():
        console.print("No local runs found.")
        return

    run_dirs = sorted(runs_dir.iterdir(), reverse=True)[:limit]
    if not run_dirs:
        console.print("No local runs found.")
        return

    table = Table(title="Local Runs")
    table.add_column("Run ID")
    table.add_column("Tag")
    table.add_column("Score", justify="right")
    table.add_column("Tasks", justify="right")
    table.add_column("Timestamp")

    for run_dir in run_dirs:
        meta_path = run_dir / "meta.json"
        results_path = run_dir / "results.json"
        if not meta_path.exists():
            continue

        meta = json.loads(meta_path.read_text())
        score = "-"
        tasks_total = "-"
        if results_path.exists():
            results_data = json.loads(results_path.read_text())
            score = f"{results_data.get('score', 0):.3f}"
            tasks_total = str(results_data.get("tasks_total", 0))

        table.add_row(
            meta.get("run_id", run_dir.name),
            meta.get("tag", "-") or "-",
            score,
            tasks_total,
            meta.get("timestamp", "-"),
        )

    console.print(table)
