import functools

from rich.console import Console


@functools.lru_cache(maxsize=1)
def get_console() -> Console:
    return Console()
