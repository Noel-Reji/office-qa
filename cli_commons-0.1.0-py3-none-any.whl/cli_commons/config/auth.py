from __future__ import annotations

import configparser
import os
from configparser import ConfigParser
from pathlib import Path

from arena_core.constants import CREDENTIALS_SECTION, TOKEN_ENV_VAR
from arena_core.errors import AuthError


def resolve_token(token_flag: str | None = None, *, credentials_path: str) -> str:
    """Resolve token with priority: flag > env var > credentials file."""
    if token_flag:
        return token_flag

    env_token = os.environ.get(TOKEN_ENV_VAR)
    if env_token:
        return env_token

    creds_path = Path(credentials_path).expanduser()
    try:
        raw = creds_path.read_text().strip()
    except FileNotFoundError:
        raise AuthError("Not authenticated. Run 'arena auth login'") from None

    config = ConfigParser()
    try:
        config.read_string(raw)
        if config.has_option(CREDENTIALS_SECTION, "token"):
            return config.get(CREDENTIALS_SECTION, "token")
    except configparser.Error:
        pass

    if raw and "\n" not in raw:
        save_token(raw, credentials_path=credentials_path)
        return raw

    raise AuthError(
        f"Credentials file is missing expected data: {creds_path}\n" "Run 'arena auth login' to re-authenticate."
    )


def save_token(token: str, *, credentials_path: str) -> Path:
    creds_path = Path(credentials_path).expanduser()
    creds_path.parent.mkdir(parents=True, exist_ok=True)

    config = ConfigParser()
    if creds_path.exists():
        try:
            config.read(creds_path)
        except configparser.Error:
            pass

    if not config.has_section(CREDENTIALS_SECTION):
        config.add_section(CREDENTIALS_SECTION)
    config.set(CREDENTIALS_SECTION, "token", token)

    with open(creds_path, "w") as f:
        config.write(f)

    creds_path.chmod(0o600)
    return creds_path


def clear_token(*, credentials_path: str) -> None:
    creds_path = Path(credentials_path).expanduser()
    if creds_path.exists():
        creds_path.unlink()
