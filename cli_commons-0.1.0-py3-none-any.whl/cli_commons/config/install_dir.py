"""Install roots for bundled CLIs (venv, env.json, updater cache).

User arena-cli uses ARENA_INSTALL_DIR (default ~/.arena).
Admin arena-admin-cli uses ARENA_ADMIN_CLI_INSTALL_DIR (default ~/.arena-admin) only —
it does not read ARENA_INSTALL_DIR so both CLIs can coexist on one machine.
"""

from __future__ import annotations

import os
from pathlib import Path

USER_INSTALL_DIR_ENV = "ARENA_INSTALL_DIR"
ADMIN_INSTALL_DIR_ENV = "ARENA_ADMIN_CLI_INSTALL_DIR"


def user_install_dir() -> Path:
    """Root where arena-cli install.sh / updater place venv and env.json."""
    return Path(os.environ.get(USER_INSTALL_DIR_ENV, Path.home() / ".arena"))


def admin_install_dir() -> Path:
    """Root where arena-admin-cli install.sh / updater place venv and env.json."""
    return Path(os.environ.get(ADMIN_INSTALL_DIR_ENV, Path.home() / ".arena-admin"))
