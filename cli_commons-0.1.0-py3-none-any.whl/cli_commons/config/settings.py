from __future__ import annotations

from pathlib import Path
from typing import Self

from pydantic import BaseModel, computed_field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class ArenaPaths(BaseModel):
    """Internal path configuration for CLI directories. Not exposed to developers."""

    arena_dir: Path = Path(".arena")

    @computed_field  # type: ignore[prop-decorator]
    @property
    def samples_dir(self) -> Path:
        return self.arena_dir / "samples"

    @computed_field  # type: ignore[prop-decorator]
    @property
    def runs_dir(self) -> Path:
        return self.arena_dir / "runs"

    @computed_field  # type: ignore[prop-decorator]
    @property
    def traces_dir(self) -> Path:
        return self.arena_dir / "traces"

    @computed_field  # type: ignore[prop-decorator]
    @property
    def manifest_path(self) -> Path:
        return self.samples_dir / "manifest.json"

    def ensure_dirs(self) -> None:
        """Create directory structure if it doesn't exist."""
        self.samples_dir.mkdir(parents=True, exist_ok=True)
        self.runs_dir.mkdir(parents=True, exist_ok=True)


_ENV_URLS: dict[str, dict[str, str]] = {
    "dev": {
        "api_base_url": "https://arena-api.dev.sentient.xyz",
        "auth_url": "https://arena.dev.sentient.xyz/cli/login",
        "dashboard_base_url": "https://arena.dev.sentient.xyz/dashboard",
    },
    "uat": {
        "api_base_url": "https://arena-api.uat.sentient.xyz",
        "auth_url": "https://arena.uat.sentient.xyz/cli/login",
        "dashboard_base_url": "https://arena.uat.sentient.xyz/dashboard",
    },
    "prod": {
        "api_base_url": "https://arena-api.sentient.xyz",
        "auth_url": "https://arena.sentient.xyz/cli/login",
        "dashboard_base_url": "https://arena.sentient.xyz/dashboard",
    },
}


class ArenaSettingsBase(BaseSettings):
    """Shared API / dashboard URL settings for Arena CLIs (subclass per app)."""

    model_config = SettingsConfigDict(env_prefix="ARENA_")

    env: str | None = None  # "dev", "uat", "prod" — switches all URLs at once
    api_base_url: str = "https://arena-api.sentient.xyz"
    api_version: str = "v1"
    auth_url: str = "https://arena.sentient.xyz/cli/login"
    dashboard_base_url: str = "https://arena.sentient.xyz/dashboard"

    @model_validator(mode="after")
    def _apply_env_urls(self) -> Self:
        """When env is set (e.g. ARENA_ENV=dev), apply env-specific URLs as defaults.

        Only overrides fields that still hold their hardcoded prod defaults —
        explicit ARENA_API_BASE_URL / env.json values take precedence.
        """
        if self.env and self.env in _ENV_URLS:
            urls = _ENV_URLS[self.env]
            prod = _ENV_URLS["prod"]
            for field, url in urls.items():
                if getattr(self, field) == prod[field]:
                    setattr(self, field, url)
        return self

    @computed_field  # type: ignore[prop-decorator]
    @property
    def api_url(self) -> str:
        return f"{self.api_base_url}/api/{self.api_version}"
