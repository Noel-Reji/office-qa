"""Centralized CLI error handling. Eliminates repeated try/except ArenaError blocks."""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable, Coroutine
from contextlib import contextmanager
from typing import Any, TypeVar

import pydantic
import typer
from rich.console import Console

from arena_core.errors import ArenaError, ConfigError
from cli_commons.client.base import BaseArenaClient
from cli_commons.config.auth import resolve_token

T = TypeVar("T")
C = TypeVar("C", bound=BaseArenaClient)


def resolve_slug(slug: str | None) -> str | None:
    """Resolve competition slug from --slug option or arena.yaml in CWD."""
    if slug:
        return slug
    try:
        from arena_core import load_arena_config
        from arena_core.errors import ConfigError

        config = load_arena_config()
        return config.competition
    except (FileNotFoundError, ConfigError):
        return None


def require_slug(slug: str | None, console: Console) -> str:
    """Resolve slug or exit with error. Use in CLI commands that require a competition slug."""
    resolved = resolve_slug(slug)
    if resolved is None:
        console.print(
            "[red]Error:[/red] Competition slug required. Pass --slug or run from a project directory with arena.yaml."
        )
        raise typer.Exit(1)
    return resolved


@contextmanager
def handle_errors(console: Console):
    """Context manager that catches ArenaError/FileNotFoundError/ValidationError and raises typer.Exit."""
    try:
        yield
    except FileNotFoundError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(ConfigError.exit_code) from None
    except ArenaError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(exc.exit_code) from None
    except pydantic.ValidationError as exc:
        console.print(f"[red]Error:[/red] Invalid data format: {exc.error_count()} validation error(s)")
        for err in exc.errors():
            loc = " → ".join(str(part) for part in err["loc"])
            console.print(f"  {loc}: {err['msg']}")
        raise typer.Exit(1) from None


def run_async(fn: Callable[[], Coroutine[Any, Any, T]], console: Console) -> T:
    """Run async function with ArenaError -> typer.Exit translation.

    Usage:
        result = run_async(lambda: api_call(client, args), console)
    """
    with handle_errors(console):
        try:
            return asyncio.run(fn())
        except KeyboardInterrupt:
            console.print("\n[yellow]Interrupted.[/yellow]")
            raise typer.Exit(130) from None


def api_call(
    token: str | None,
    fn: Callable[[C, str], Awaitable[T]],
    console: Console | None = None,
    *,
    credentials_path: str,
    api_url: str,
    client_factory: Callable[[str, str], C],
    token_resolver: Callable[[str | None], str] | None = None,
) -> T:
    """Resolve token, open ArenaClient, run async fn(client, token), handle errors."""
    if console is None:
        from cli_commons.output.console import get_console

        console = get_console()
    if token_resolver is None:

        def _default_token_resolver(token_value: str | None) -> str:
            return resolve_token(token_value, credentials_path=credentials_path)

        token_resolver = _default_token_resolver
    with handle_errors(console):
        resolved_token = token_resolver(token)

    async def _run():
        async with client_factory(resolved_token, api_url) as client:
            return await fn(client, resolved_token)

    return run_async(_run, console)
