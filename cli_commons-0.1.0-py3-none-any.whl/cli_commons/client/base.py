from __future__ import annotations

import asyncio
import json
from contextlib import asynccontextmanager
from datetime import datetime

import httpx

from arena_core.constants import ERROR_CODE_QUOTA_EXCEEDED, ERROR_CODE_TEAM_SUSPENDED
from arena_core.errors import (
    ApiError,
    AuthError,
    NetworkError,
    QuotaExceededError,
    RateLimitedError,
    TeamSuspendedError,
)

_RETRY_STATUSES = {502, 503, 504, 520, 524}
_GATEWAY_TIMEOUT_MESSAGE = "Download timed out at the gateway. If artifacts are large, retry with --force."
_MAX_RETRIES = 2
_RETRY_DELAYS = [0.5, 1.5]
_IDEMPOTENT_METHODS = frozenset({"GET", "HEAD", "OPTIONS", "PUT", "DELETE"})


def _parse_iso_datetime(value: object) -> datetime | None:
    """Best-effort parse of an ISO 8601 timestamp; tolerates ``Z`` suffix. Returns None on failure."""
    if not isinstance(value, str):
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


class BaseArenaClient:
    """Async HTTP client for the Arena backend API."""

    def __init__(self, token: str, base_url: str, *, auth_hint: str):
        self._token = token
        self._base_url = base_url
        self._auth_hint = auth_hint
        self._client: httpx.AsyncClient | None = None

    async def __aenter__(self) -> BaseArenaClient:
        self._client = httpx.AsyncClient(
            base_url=self._base_url,
            headers={
                "Authorization": f"Bearer {self._token}",
            },
            timeout=90.0,
        )
        return self

    async def __aexit__(self, *args) -> None:
        if self._client:
            await self._client.aclose()

    @property
    def client(self) -> httpx.AsyncClient:
        if self._client is None:
            raise RuntimeError("Client not initialized. Use 'async with ArenaClient()'.")
        return self._client

    async def get(self, path: str, **kwargs) -> httpx.Response:
        return await self._request("GET", path, **kwargs)

    async def post(self, path: str, **kwargs) -> httpx.Response:
        return await self._request("POST", path, **kwargs)

    async def delete(self, path: str, **kwargs) -> httpx.Response:
        return await self._request("DELETE", path, **kwargs)

    async def post_multipart(self, path: str, *, files: dict, **kwargs) -> httpx.Response:
        """POST multipart/form-data through centralized error handling."""
        return await self._request("POST", path, files=files, **kwargs)

    def check_status(self, response: httpx.Response) -> None:
        """Raise typed errors for non-success HTTP status codes.

        Also used in stream_sse() where response.json() may not be available
        (body unread in streaming mode) -- the try/except handles that gracefully.
        """
        if response.status_code == 401:
            raise AuthError(f"Invalid or expired token. Run '{self._auth_hint}'.")
        if response.status_code == 429:
            body: dict = {}
            try:
                parsed = response.json()
                if isinstance(parsed, dict):
                    body = parsed
            except (ValueError, httpx.ResponseNotRead):
                # ValueError covers JSONDecodeError; ResponseNotRead covers streaming mode.
                pass
            error_code = body.get("code", "")
            detail = body.get("detail", "Rate limited")
            if error_code == ERROR_CODE_QUOTA_EXCEEDED or "daily_limit" in body:
                raise QuotaExceededError(
                    detail,
                    daily_limit=body.get("daily_limit"),
                    used_today=body.get("used_today"),
                    resets_at=body.get("resets_at"),
                )
            raise RateLimitedError(detail)

    async def _raise_api_error(self, response: httpx.Response, error: httpx.HTTPStatusError) -> None:
        body: dict = {}
        try:
            await response.aread()
            parsed = response.json()
            if isinstance(parsed, dict):
                body = parsed
        except (ValueError, httpx.ResponseNotRead):
            pass
        detail = body.get("detail")

        # Dispatch to typed error subclasses based on structured ``code`` markers
        # before falling through to the generic ApiError. Currently only used
        # for 403 TEAM_SUSPENDED; extend here as new typed errors are added.
        if response.status_code == 403 and isinstance(detail, dict) and detail.get("code") == ERROR_CODE_TEAM_SUSPENDED:
            raise TeamSuspendedError(
                message=detail.get("message"),
                reason=detail.get("reason"),
                suspended_until=_parse_iso_datetime(detail.get("suspended_until")),
                request_id=body.get("request_id"),
            ) from error

        if isinstance(detail, dict) and isinstance(detail.get("message"), str):
            message = detail["message"]
        else:
            message = detail if isinstance(detail, str) else str(error)
        if response.status_code in _RETRY_STATUSES and not detail:
            if response.status_code == 524:
                message = _GATEWAY_TIMEOUT_MESSAGE
            else:
                message = f"Gateway error ({response.status_code}). Please retry."
        raise ApiError(
            message=message,
            status_code=response.status_code,
            error_code=body.get("code"),
            request_id=body.get("request_id"),
        ) from error

    @asynccontextmanager
    async def stream_get(self, path: str, **kwargs):
        """Stream a GET response with centralized auth/status translation."""
        for attempt in range(_MAX_RETRIES + 1):
            try:
                async with self.client.stream("GET", path, **kwargs) as response:
                    self.check_status(response)
                    try:
                        response.raise_for_status()
                    except httpx.HTTPStatusError as error:
                        if response.status_code in _RETRY_STATUSES and attempt < _MAX_RETRIES:
                            await asyncio.sleep(_RETRY_DELAYS[attempt])
                            continue
                        await self._raise_api_error(response, error)
                    yield response
                    return
            except httpx.TransportError as e:
                if attempt < _MAX_RETRIES:
                    await asyncio.sleep(_RETRY_DELAYS[attempt])
                    continue
                raise NetworkError(
                    f"Arena backend is not reachable at {self._base_url}\n"
                    "Local commands (arena test, arena doctor) work without the backend."
                ) from e
        raise NetworkError(f"Arena backend is not reachable at {self._base_url}")

    async def _request(self, method: str, path: str, **kwargs) -> httpx.Response:
        is_idempotent = method.upper() in _IDEMPOTENT_METHODS
        for attempt in range(_MAX_RETRIES + 1):
            try:
                response = await self.client.request(method, path, **kwargs)
            except httpx.TransportError as e:
                if attempt < _MAX_RETRIES and is_idempotent:
                    await asyncio.sleep(_RETRY_DELAYS[attempt])
                    continue
                raise NetworkError(
                    f"Arena backend is not reachable at {self._base_url}\n"
                    "Local commands (arena test, arena doctor) work without the backend."
                ) from e

            if response.status_code in _RETRY_STATUSES and attempt < _MAX_RETRIES and is_idempotent:
                await asyncio.sleep(_RETRY_DELAYS[attempt])
                continue

            self.check_status(response)
            try:
                response.raise_for_status()
            except httpx.HTTPStatusError as e:
                await self._raise_api_error(response, e)
            return response
        # Unreachable, but satisfies type checker
        raise NetworkError(f"Arena backend is not reachable at {self._base_url}")

    async def stream_sse(self, path: str):
        """Yield SSE events from a streaming endpoint.

        Yields tuples of (event_type: str, data: dict).
        """
        try:
            async with self.stream_get(path) as response:
                event_type = ""
                async for line in response.aiter_lines():
                    if line.startswith("event:"):
                        event_type = line[6:].strip()
                    elif line.startswith("data:"):
                        data = json.loads(line[5:].strip())
                        yield event_type, data
                    elif line == "":
                        event_type = ""
        except httpx.TimeoutException as e:
            raise NetworkError(f"Stream timed out: {e}") from e
        except httpx.TransportError as e:
            raise NetworkError(
                f"Arena backend is not reachable at {self._base_url}\n"
                "Local commands (arena test, arena doctor) work without the backend."
            ) from e
