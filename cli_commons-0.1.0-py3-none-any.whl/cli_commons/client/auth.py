from __future__ import annotations

from arena_core.models.auth import AuthVerifyResponse
from cli_commons.client import routes
from cli_commons.client.base import BaseArenaClient


async def verify_token(client: BaseArenaClient, token: str) -> AuthVerifyResponse:
    """POST /api/v1/auth/verify"""
    response = await client.post(routes.AUTH_VERIFY, json={"token": token})
    return AuthVerifyResponse(**response.json())
