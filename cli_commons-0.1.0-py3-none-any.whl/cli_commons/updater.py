"""Shared auto-update engine for Arena CLI applications."""

from __future__ import annotations

import hashlib
import logging
import os
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

import httpx
from packaging.version import InvalidVersion, Version

from cli_commons.output.console import get_console

logger = logging.getLogger(__name__)

_UPDATE_TIMEOUT = 15.0
_VERSION_CACHE_TTL = 3600  # 1 hour
_IS_WINDOWS = sys.platform == "win32"
_VENV_BIN = "Scripts" if _IS_WINDOWS else "bin"
_PYTHON_NAME = "python.exe" if _IS_WINDOWS else "python"


@dataclass(frozen=True)
class UpdaterConfig(ABC):
    """Shared auto-update configuration. Subclasses define how the install root is resolved."""

    api_base_url: str
    app_label: str
    module_entrypoint: str
    bundle_prefix: str
    token_resolver: Callable[[], str]
    current_version: str
    update_fail_message: str

    @abstractmethod
    def resolve_install_dir(self) -> Path:
        """Bundle root containing venv, env.json, bin wrappers, and .update_check."""
        ...


_CONFIG: UpdaterConfig | None = None


def configure(config: UpdaterConfig) -> None:
    global _CONFIG
    _CONFIG = config


def _config() -> UpdaterConfig:
    if _CONFIG is None:
        raise RuntimeError("Updater is not configured")
    return _CONFIG


def _install_dir() -> Path:
    return _config().resolve_install_dir()


def _wrapper_name() -> str:
    return _config().app_label.replace("-cli", "")


def _version_url() -> str:
    cfg = _config()
    return f"{cfg.api_base_url}/{cfg.bundle_prefix}/version.json"


def _bundle_url() -> str:
    cfg = _config()
    return f"{cfg.api_base_url}/{cfg.bundle_prefix}/{cfg.app_label}-latest.tar.gz"


def _fix_shebangs(venv_dir: Path, old_path: Path, new_path: Path) -> None:
    """Rewrite shebangs in venv scripts after an atomic directory swap.

    Only touches the first line (shebang) to avoid corrupting script bodies.
    No-op on Windows where scripts use .exe launchers, not shebangs.
    """
    if _IS_WINDOWS:
        return
    old_prefix = str(old_path).encode()
    new_prefix = str(new_path).encode()
    bin_dir = venv_dir / _VENV_BIN
    if not bin_dir.exists():
        return
    for script in bin_dir.iterdir():
        if not script.is_file() or script.is_symlink():
            continue
        try:
            with open(script, "rb") as fh:
                first_line = fh.readline(1024)
                if not (first_line[:2] == b"#!" and old_prefix in first_line):
                    continue
                rest = fh.read()
            fixed_line = first_line.rstrip(b"\n").replace(old_prefix, new_prefix, 1)
            script.write_bytes(fixed_line + b"\n" + rest)
        except OSError:
            pass


def _create_compat_symlink(staging_dir: Path, venv_dir: Path) -> None:
    """Create venv.new -> venv symlink so stale shebangs from older updaters resolve.

    Symlinks require no special privileges on macOS/Linux.
    On Windows, symlinks may require admin — skip silently if it fails.
    """
    try:
        if staging_dir.is_symlink():
            staging_dir.unlink()
        elif staging_dir.is_dir():
            # Leftover staging dir from a failed update — safe to remove
            shutil.rmtree(staging_dir, ignore_errors=True)
        staging_dir.symlink_to(venv_dir)
    except OSError:
        pass


def _migrate_bin_wrapper(install_dir: Path) -> None:
    """Replace legacy symlink wrapper with a bash wrapper."""
    wrapper = install_dir / "bin" / _wrapper_name()
    # Only migrate symlinks (valid or broken). Regular files (already a
    # wrapper) and nonexistent paths are skipped. is_symlink() returns
    # True for broken symlinks — exists() does not.
    if not wrapper.is_symlink():
        return
    try:
        venv_python = install_dir / "venv" / _VENV_BIN / _PYTHON_NAME
        wrapper.unlink()
        wrapper.write_text(f'#!/usr/bin/env bash\nexec "{venv_python}" -m {_config().module_entrypoint} "$@"\n')
        wrapper.chmod(0o755)
    except OSError:
        pass


def _copy_bundle_env_config(tmpdir: str) -> None:
    """Copy env.json from extracted bundle to the install directory if present."""
    env_json = Path(tmpdir) / "env.json"
    if env_json.exists():
        shutil.copy2(str(env_json), str(_install_dir() / "env.json"))


def _get_cache_path() -> Path:
    return _install_dir() / ".update_check"


def _is_cache_fresh() -> bool:
    try:
        return (time.time() - _get_cache_path().stat().st_mtime) < _VERSION_CACHE_TTL
    except OSError:
        return False


def _touch_cache():
    try:
        _get_cache_path().touch()
    except OSError:
        pass


def fetch_latest_version(token: str) -> Version | None:
    """Fetch the latest CLI version from the version manifest."""
    try:
        response = httpx.get(
            _version_url(),
            auth=("__token__", token),
            timeout=_UPDATE_TIMEOUT,
            follow_redirects=True,
        )
        if response.status_code != 200:
            return None
        data = response.json()
        return Version(data["version"])
    except Exception:
        logger.debug("Update check failed", exc_info=True)
        return None


def do_upgrade(token: str) -> bool:
    """Download the latest bundle and reinstall. Returns True on success."""
    try:
        # Fetch version.json first for checksum
        expected_sha256 = None
        try:
            ver_resp = httpx.get(
                _version_url(),
                auth=("__token__", token),
                timeout=_UPDATE_TIMEOUT,
                follow_redirects=True,
            )
            if ver_resp.status_code != 200:
                logger.warning(
                    "Could not fetch version.json for checksum (status=%s) — aborting upgrade",
                    ver_resp.status_code,
                )
                return False
            expected_sha256 = ver_resp.json().get("sha256")
        except Exception:
            logger.warning("Could not fetch version.json for checksum — aborting upgrade")
            return False
        if not expected_sha256:
            logger.warning("Missing bundle checksum in version.json — aborting upgrade")
            return False

        with tempfile.TemporaryDirectory() as tmpdir:
            # Stream download with incremental checksum (avoid second file pass)
            tar_path = os.path.join(tmpdir, "bundle.tar.gz")
            download_hash = hashlib.sha256()
            with httpx.stream(
                "GET",
                _bundle_url(),
                auth=("__token__", token),
                timeout=120,
                follow_redirects=True,
            ) as stream:
                if stream.status_code != 200:
                    return False
                with open(tar_path, "wb") as f:
                    for chunk in stream.iter_bytes(chunk_size=8192):
                        f.write(chunk)
                        download_hash.update(chunk)

            # Verify checksum
            if download_hash.hexdigest() != expected_sha256:
                logger.warning("Bundle checksum mismatch — aborting upgrade")
                return False

            # Extract with security filter (Python 3.12+)
            with tarfile.open(tar_path, "r:gz") as tar:
                tar.extractall(tmpdir, filter="data")

            wheels = sorted(Path(tmpdir).glob("*.whl"))
            if not wheels:
                return False

            # Atomic upgrade: install to staging venv, then swap
            install_dir = _install_dir()
            venv_dir = install_dir / "venv"
            staging_dir = install_dir / "venv.new"
            backup_dir = install_dir / "venv.bak"

            # Fall back to in-place upgrade if bundle venv doesn't exist (e.g. pip install)
            if not venv_dir.exists():
                install_cmd = [sys.executable, "-m", "pip", "install", "--force-reinstall", "--quiet"]
                result = subprocess.run(
                    install_cmd + [str(w) for w in wheels],
                    capture_output=True,
                    timeout=120,
                )
                if result.returncode == 0:
                    _copy_bundle_env_config(tmpdir)
                return result.returncode == 0

            # Create staging venv and install wheels
            if staging_dir.is_symlink():
                staging_dir.unlink()
            elif staging_dir.exists():
                shutil.rmtree(staging_dir)
            subprocess.run(
                ["uv", "venv", str(staging_dir), "--python", ">=3.13", "--quiet"],
                check=True,
                capture_output=True,
                timeout=30,
            )
            python_path = str(staging_dir / _VENV_BIN / _PYTHON_NAME)
            result = subprocess.run(
                ["uv", "pip", "install", "--python", python_path, "--quiet"] + [str(w) for w in wheels],
                capture_output=True,
                timeout=120,
            )
            if result.returncode != 0:
                shutil.rmtree(staging_dir, ignore_errors=True)
                return False

            # Atomic swap: old -> backup, staging -> live
            if backup_dir.exists():
                shutil.rmtree(backup_dir)
            venv_dir.rename(backup_dir)
            try:
                staging_dir.rename(venv_dir)
            except OSError:
                # Rollback: restore backup
                backup_dir.rename(venv_dir)
                return False
            shutil.rmtree(backup_dir, ignore_errors=True)

            # Fix shebangs (Unix only): scripts reference the staging path after rename
            _fix_shebangs(venv_dir, staging_dir, venv_dir)
            # Compat symlink: older updaters leave shebangs pointing to venv.new
            _create_compat_symlink(staging_dir, venv_dir)
            # Migrate legacy symlink wrapper to bash wrapper
            _migrate_bin_wrapper(install_dir)

            _copy_bundle_env_config(tmpdir)
            return True
    except Exception:
        logger.debug("Bundle upgrade failed", exc_info=True)
        return False


def check_and_update() -> None:
    """Check for updates and auto-upgrade if a newer version is available.

    Designed to be called from the Typer root callback. Never raises —
    the CLI must never fail due to update logic.
    """
    install_dir = _install_dir()
    # Always migrate legacy symlink wrapper on startup — this is the only
    # way to fix installs that were broken by an old updater's venv swap.
    # The check is cheap (one is_symlink call) and no-ops if already migrated.
    try:
        _migrate_bin_wrapper(install_dir)
    except Exception:
        pass

    if os.environ.get("_ARENA_UPDATED") == "1":
        return
    if os.environ.get("ARENA_NO_AUTO_UPDATE", "").strip().lower() in ("1", "true", "yes"):
        return
    if _is_cache_fresh():
        return

    try:
        token = _config().token_resolver()
    except Exception:
        return

    latest = fetch_latest_version(token)
    if latest is None:
        return
    _touch_cache()

    try:
        current = Version(_config().current_version)
    except InvalidVersion:
        return
    if latest <= current:
        return

    console = get_console()
    console.print(f"[dim]Updating {_config().app_label} {current} → {latest}...[/dim]")
    if do_upgrade(token):
        _migrate_bin_wrapper(install_dir)
        console.print(f"[green]Updated to {_config().app_label} {latest}[/green]")
        os.environ["_ARENA_UPDATED"] = "1"
        try:
            python = str(install_dir / "venv" / _VENV_BIN / _PYTHON_NAME)
            args = [python, "-m", _config().module_entrypoint] + sys.argv[1:]
            os.execvp(python, args)
        except OSError:
            logger.debug("Re-exec failed", exc_info=True)
    else:
        console.print(f"[yellow]{_config().update_fail_message}[/yellow]")
