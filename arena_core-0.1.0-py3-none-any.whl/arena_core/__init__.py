"""arena-core: Shared models and schemas for the Arena platform.

Quick imports:
    from arena_core import ArenaConfig, load_arena_config
    from arena_core import ArenaError, ConfigError, AuthError
    from arena_core.models import Submission, CompetitionDetail, Trajectory
"""

from arena_core import constants
from arena_core.config import (
    AgentConfig,
    ArenaConfig,
    EnvironmentConfig,
    load_arena_config,
)
from arena_core.enums import (
    AgentType,
    ApplicationStatus,
    CompetitionStatus,
    ExecutionStatus,
    GateCheckStatus,
    GateMode,
    NetworkMode,
    PipelineState,
    StepSource,
    SubmissionEventType,
    SubmissionStatus,
    TaskStatus,
)
from arena_core.errors import (
    ApiError,
    ArenaError,
    AuthError,
    CompetitionNotFoundError,
    ConfigError,
    HarborError,
    NetworkError,
    QuotaExceededError,
    RateLimitedError,
    SubmissionNotFoundError,
    SubmitError,
    TeamSuspendedError,
    ValidationError,
)
from arena_core.leaderboard import LeaderboardManager
from arena_core.models.auth import AuthVerifyResponse, TokenUser, TokenValidationResult
from arena_core.models.leaderboard import LeaderboardEntry, LeaderboardResponse
from arena_core.models.team import QuotaResponse
from arena_core.settings import DatabaseSettings

__all__ = [
    # --- Enums ---
    "AgentType",
    "ApplicationStatus",
    "CompetitionStatus",
    "ExecutionStatus",
    "GateCheckStatus",
    "GateMode",
    "NetworkMode",
    "PipelineState",
    "StepSource",
    "SubmissionEventType",
    "SubmissionStatus",
    "TaskStatus",
    # --- Constants ---
    "constants",
    # --- Models (API responses) ---
    "AuthVerifyResponse",
    "TokenUser",
    "TokenValidationResult",
    "LeaderboardEntry",
    "LeaderboardResponse",
    "QuotaResponse",
    # --- Leaderboard ---
    "LeaderboardManager",
    # --- Settings ---
    "DatabaseSettings",
    # --- Config ---
    "AgentConfig",
    "ArenaConfig",
    "EnvironmentConfig",
    "load_arena_config",
    # --- Errors ---
    "ApiError",
    "ArenaError",
    "AuthError",
    "CompetitionNotFoundError",
    "ConfigError",
    "HarborError",
    "NetworkError",
    "QuotaExceededError",
    "RateLimitedError",
    "SubmissionNotFoundError",
    "SubmitError",
    "TeamSuspendedError",
    "ValidationError",
]
