"""Reusable environment checks for the Arena platform.

Each function returns ``None`` on success or an error message string.
"""

from __future__ import annotations

import importlib
import shutil
from pathlib import Path


def check_import_path(module: str, class_name: str) -> str | None:
    """Verify that *module* can be imported and contains *class_name*."""
    try:
        mod = importlib.import_module(module)
        if not hasattr(mod, class_name):
            return f"Class '{class_name}' not found in module '{module}'"
    except ImportError as e:
        return f"Cannot import '{module}': {e}"
    return None


def check_docker() -> str | None:
    """Verify that the ``docker`` CLI is on *PATH*."""
    if not shutil.which("docker"):
        return "Docker not found in PATH"
    return None


def check_samples_dir(path: Path) -> str | None:
    """Verify that *path* exists as a directory."""
    if not path.is_dir():
        return f"Samples directory not found: {path}"
    return None


def check_harbor_sdk() -> str | None:
    """Verify that the Harbor SDK is installed."""
    from arena_core.constants import HARBOR_SDK_MODULE

    try:
        importlib.import_module(HARBOR_SDK_MODULE)
    except ImportError:
        return "Harbor SDK not installed — needed for 'arena test'"
    return None
