import functools
import logging
import time
from typing import Optional, Self


class Timer:
    def __init__(
        self,
        enable_logging: bool = False,
        prefix: Optional[str] = None,
        reusable: bool = False,
        logger: Optional[logging.Logger] = None,
        log_level: Optional[int] = None,
    ) -> None:
        super().__init__()
        self.enable_logging = enable_logging
        self.prefix = prefix
        self.reusable = reusable
        self.logger = logger or logging.getLogger(__name__)
        self.log_level = log_level or logging.INFO
        self.start_time: Optional[float] = None

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, *exc_info):
        self.stop()

    def start(self) -> Self:
        if self.start_time:
            raise RuntimeError("Timer has already been started")
        self.start_time = time.perf_counter()
        return self

    def stop(self) -> float:
        if not self.start_time:
            raise RuntimeError("Timer has not been started yet")
        elapsed_time = time.perf_counter() - self.start_time
        if self.enable_logging:
            self.logger.log(self.log_level, "%s::Total elapsed time %.2f seconds", self.prefix, elapsed_time)
        if self.reusable:
            self.start_time = None
        return elapsed_time


def log_time(prefix, log_level):
    def decorator(function):
        @functools.wraps(function)
        def wrapper(*args, **kwargs):
            with Timer(enable_logging=True, prefix=prefix, log_level=log_level):
                return function(*args, **kwargs)

        return wrapper

    return decorator
