"""Team-related response models."""

from typing import Optional

from pydantic import BaseModel


class QuotaResponse(BaseModel):
    """Response from team quota endpoints."""

    team_id: str
    team_code: Optional[str] = None
    competition: str
    daily_limit: int
    used_today: int
    remaining: int
    resets_at: str
