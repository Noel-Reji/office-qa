"""Leaderboard response models."""

from __future__ import annotations

import uuid
from datetime import datetime

from pydantic import BaseModel, Field


class LeaderboardEntry(BaseModel):
    """Single leaderboard row (rank, team/user, score, submission)."""

    rank: int = Field(..., description="1-based rank")
    user_id: str | None = Field(None, description="User ID from server")
    team_name: str | None = Field(None, description="Team name")
    agent_name: str | None = Field(None, description="Agent name from the submission")
    score: float = Field(..., description="Team's best score")
    submission_id: uuid.UUID | None = Field(None, description="Submission that achieved this score")
    submitted_at: datetime | None = Field(
        None,
        description="When the scoring submission was created",
    )


class LeaderboardResponse(BaseModel):
    """Leaderboard for a competition (top N entries)."""

    items: list[LeaderboardEntry] = Field(..., description="Top leaderboard entries")
    top: int = Field(..., description="Requested number of top entries")
    competition_name: str | None = Field(
        None,
        description="Competition name",
    )
    updated_at: datetime | None = Field(
        None,
        description="When the leaderboard was last updated",
    )
