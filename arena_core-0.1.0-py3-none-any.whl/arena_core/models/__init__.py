"""Arena core models.

Usage:
    from arena_core.models import Submission, CompetitionDetail, Trajectory
    from arena_core.models import TrajectoryStep, Agent, StepMetrics
    from arena_core.enums import SubmissionStatus, TaskStatus
"""

from __future__ import annotations

from arena_core.models.auth import AuthVerifyResponse, TokenUser, TokenValidationResult
from arena_core.models.competition import (
    BenchmarkSummary,
    CompetitionConstraints,
    CompetitionDefaults,
    CompetitionDetail,
    CompetitionListResponse,
    CompetitionScoring,
    SponsorSummary,
    TagSummary,
)
from arena_core.models.leaderboard import LeaderboardEntry, LeaderboardResponse
from arena_core.models.results import RunMeta, RunResults, ScoreSummary, TaskOutcome, TaskResult
from arena_core.models.submission import (
    CategoryComparison,
    ComparisonDelta,
    ComparisonSide,
    ExecuteStageResult,
    FailedTask,
    GateStatus,
    Submission,
    SubmissionAgent,
    SubmissionAgentConfig,
    SubmissionCancelResponse,
    SubmissionComparison,
    SubmissionCompletedEvent,
    SubmissionCreateResponse,
    SubmissionFailedEvent,
    SubmissionListResponse,
    SubmissionObservability,
    SubmissionProgress,
    SubmissionRunningEvent,
    SubmissionStages,
    TaskChanges,
    TrialCompletedEvent,
)
from arena_core.models.team import QuotaResponse
from arena_core.models.trajectory import (
    Agent,
    FinalMetrics,
    Observation,
    ObservationResult,
    StepMetrics,
    SubagentTrajectoryRef,
    ToolCall,
    ToolDefinition,
    Trajectory,
    TrajectoryDetail,
    TrajectoryListItem,
    TrajectoryListResponse,
    TrajectoryStep,
)

__all__ = [
    # --- Submission ---
    "CategoryComparison",
    "ComparisonDelta",
    "ComparisonSide",
    "ExecuteStageResult",
    "FailedTask",
    "GateStatus",
    "Submission",
    "SubmissionAgent",
    "SubmissionAgentConfig",
    "SubmissionCancelResponse",
    "SubmissionComparison",
    "SubmissionCompletedEvent",
    "SubmissionCreateResponse",
    "SubmissionFailedEvent",
    "SubmissionListResponse",
    "SubmissionObservability",
    "SubmissionProgress",
    "SubmissionRunningEvent",
    "SubmissionStages",
    "TaskChanges",
    "TrialCompletedEvent",
    # --- Auth ---
    "AuthVerifyResponse",
    "TokenUser",
    "TokenValidationResult",
    # --- Leaderboard ---
    "LeaderboardEntry",
    "LeaderboardResponse",
    # --- Results ---
    "RunMeta",
    "RunResults",
    "ScoreSummary",
    "TaskOutcome",
    "TaskResult",
    # --- Team ---
    "QuotaResponse",
    # --- Competition ---
    "BenchmarkSummary",
    "CompetitionConstraints",
    "CompetitionDefaults",
    "CompetitionDetail",
    "CompetitionListResponse",
    "CompetitionScoring",
    "SponsorSummary",
    "TagSummary",
    # --- Trajectory (ATIF v1.5) ---
    "Agent",
    "FinalMetrics",
    "Observation",
    "ObservationResult",
    "StepMetrics",
    "SubagentTrajectoryRef",
    "ToolCall",
    "ToolDefinition",
    "Trajectory",
    "TrajectoryDetail",
    "TrajectoryListItem",
    "TrajectoryListResponse",
    "TrajectoryStep",
]
