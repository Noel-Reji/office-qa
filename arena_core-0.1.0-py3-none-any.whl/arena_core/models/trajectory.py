"""ATIF v1.5 trajectory models.

Implements the complete Arena Trajectory Interchange Format (ATIF) v1.5 as
specified in SYSTEM_DESIGN_V5.md. This is Harbor's native trajectory format.

ATIF records *what the agent did* (messages, reasoning, tool calls,
observations, token metrics). Evaluation metadata (reward, pass/fail, task_id)
lives in Harbor's TrialResult, not in ATIF.

All ATIF models use extra="forbid" for strict validation, matching Harbor's
released implementation.

Validation rules:
  - Step IDs must be sequential starting from 1
  - source_call_id in observations must reference a valid tool_call_id in the
    same step
  - Agent-only fields (model_name, reasoning_effort, reasoning_content,
    tool_calls, metrics) are rejected for non-agent steps
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, model_validator

from arena_core.enums import StepSource, TaskStatus

# ---------------------------------------------------------------------------
# Agent configuration
# ---------------------------------------------------------------------------


class ToolDefinition(BaseModel):
    """Tool definition — accepts both flat and OpenAI function-calling wrapper formats.

    Flat (ATIF native):  {"name": "foo", "description": "...", "parameters": {...}}
    OpenAI wrapper:      {"type": "function", "function": {"name": "foo", ...}}
    """

    model_config = ConfigDict(extra="forbid")

    name: str
    description: str | None = None
    parameters: dict[str, Any] = {}

    @model_validator(mode="before")
    @classmethod
    def unwrap_openai_function_format(cls, data: Any) -> Any:
        """Unwrap OpenAI function-calling wrapper if present."""
        if isinstance(data, dict) and "function" in data and "name" not in data:
            fn = data["function"]
            if isinstance(fn, dict):
                return fn
        return data


class Agent(BaseModel):
    """Agent configuration recorded in the trajectory.

    Captures the agent identity and optional configuration at the time
    of execution.
    """

    model_config = ConfigDict(extra="forbid")

    name: str
    version: str | None = None
    model_name: str | None = None
    tool_definitions: list[ToolDefinition] | None = None
    extra: dict[str, Any] = {}


# ---------------------------------------------------------------------------
# Per-step metrics
# ---------------------------------------------------------------------------


class StepMetrics(BaseModel):
    """Token and cost metrics for a single agent step.

    Attributes:
        prompt_tokens: Total input tokens (cached + non-cached).
        completion_tokens: Tokens generated in this step.
        cached_tokens: Subset of prompt_tokens served from cache.
        cost_usd: Cost in USD for this step.
        prompt_token_ids: Token IDs for input (for analysis/debugging).
        completion_token_ids: Token IDs for output (for RL training).
        logprobs: Log probabilities per completion token (for RL training).
        extra: Provider-specific metrics.
    """

    model_config = ConfigDict(extra="forbid")

    prompt_tokens: int | None = None
    completion_tokens: int | None = None
    cached_tokens: int | None = None
    cost_usd: float | None = None
    prompt_token_ids: list[int] | None = None
    completion_token_ids: list[int] | None = None
    logprobs: list[float] | None = None
    extra: dict[str, Any] = {}


# ---------------------------------------------------------------------------
# Tool calls and observations
# ---------------------------------------------------------------------------


class ToolCall(BaseModel):
    """A single tool invocation within a step.

    Attributes:
        tool_call_id: Unique ID for correlation with observation results.
        function_name: Name of the tool/function called.
        arguments: Arguments passed to the tool. Can be empty {}.
    """

    model_config = ConfigDict(extra="forbid")

    tool_call_id: str
    function_name: str
    arguments: dict[str, Any] = {}


class SubagentTrajectoryRef(BaseModel):
    """Reference to a delegated subagent's trajectory.

    Used when an agent delegates work to a subagent. The subagent's full
    trajectory can be retrieved via the session_id or trajectory_path.
    """

    model_config = ConfigDict(extra="forbid")

    session_id: str
    trajectory_path: str | None = None
    extra: dict[str, Any] = {}


class ObservationResult(BaseModel):
    """A single result within an observation.

    Each result corresponds to one tool call (linked via source_call_id)
    and contains the textual output and/or subagent trajectory references.
    """

    model_config = ConfigDict(extra="forbid")

    type: str | None = None  # e.g., "text" — present in API/SDK payloads
    source_call_id: str | None = None
    content: str | None = None
    subagent_trajectory_ref: list[SubagentTrajectoryRef] | None = None


class Observation(BaseModel):
    """Environment feedback after tool execution.

    Contains a list of results, each corresponding to a tool call in the
    same step.
    """

    model_config = ConfigDict(extra="forbid")

    results: list[ObservationResult] = []


# ---------------------------------------------------------------------------
# Trajectory step
# ---------------------------------------------------------------------------


class TrajectoryStep(BaseModel):
    """A single step in the trajectory.

    Steps are sequential and represent the full history of an agent
    execution: system prompts, user messages, agent reasoning, tool calls,
    and environment observations.
    """

    model_config = ConfigDict(extra="forbid")

    step_id: int = Field(..., ge=1)
    timestamp: datetime | None = None
    source: StepSource
    message: str  # Required, can be empty string

    # --- Optional step fields ---
    is_copied_context: bool | None = None  # Marks prior context

    # --- Agent-only fields ---
    model_name: str | None = None
    reasoning_effort: str | float | None = None
    reasoning_content: str | None = None
    tool_calls: list[ToolCall] | None = None
    observation: Observation | None = None
    metrics: StepMetrics | None = None

    # --- Extensibility ---
    extra: dict[str, Any] = {}

    @model_validator(mode="after")
    def validate_agent_only_fields(self) -> TrajectoryStep:
        """Agent-only fields must not appear on non-agent steps."""
        if self.source != StepSource.AGENT:
            agent_only_fields = {
                "model_name": self.model_name,
                "reasoning_effort": self.reasoning_effort,
                "reasoning_content": self.reasoning_content,
                "tool_calls": self.tool_calls,
                "observation": self.observation,
                "metrics": self.metrics,
            }
            set_fields = [name for name, value in agent_only_fields.items() if value is not None]
            if set_fields:
                raise ValueError(f"Agent-only fields {set_fields} cannot be set on source='{self.source}' steps")
        return self


# ---------------------------------------------------------------------------
# Final metrics (trajectory-level aggregates)
# ---------------------------------------------------------------------------


class FinalMetrics(BaseModel):
    """Trajectory-level aggregate metrics.

    Summarizes token usage and cost across all steps.
    """

    model_config = ConfigDict(extra="forbid")

    total_prompt_tokens: int | None = None
    total_completion_tokens: int | None = None
    total_cached_tokens: int | None = None
    total_cost_usd: float | None = None
    total_steps: int | None = None
    extra: dict[str, Any] = {}


# ---------------------------------------------------------------------------
# Trajectory (root)
# ---------------------------------------------------------------------------


class Trajectory(BaseModel):
    """Full ATIF v1.5 trajectory.

    The root object for an agent execution trace. Contains the agent
    configuration, sequential steps, and aggregate metrics.

    Validation:
      - schema_version is required
      - session_id is required
      - agent is required
      - steps must have at least 1 entry
      - step_ids must be sequential starting from 1
      - source_call_id in observations must reference a valid tool_call_id
    """

    model_config = ConfigDict(extra="forbid")

    schema_version: str = "ATIF-v1.5"
    session_id: str
    agent: Agent
    notes: str | None = None
    continued_trajectory_ref: str | None = None
    extra: dict[str, Any] = {}

    steps: list[TrajectoryStep] = Field(..., min_length=1)
    final_metrics: FinalMetrics | None = None

    @model_validator(mode="after")
    def validate_steps(self) -> Trajectory:
        """Validate step sequencing and observation references."""
        # Check step IDs are sequential starting from 1
        for i, step in enumerate(self.steps):
            expected_id = i + 1
            if step.step_id != expected_id:
                raise ValueError(
                    f"Step IDs must be sequential starting from 1. "
                    f"Expected step_id={expected_id}, got step_id={step.step_id}"
                )

        # Check source_call_id references valid tool_call_id in same step
        for step in self.steps:
            if step.observation and step.observation.results:
                tool_call_ids = set()
                if step.tool_calls:
                    tool_call_ids = {tc.tool_call_id for tc in step.tool_calls}

                for result in step.observation.results:
                    if result.source_call_id is not None and result.source_call_id not in tool_call_ids:
                        raise ValueError(
                            f"Step {step.step_id}: observation source_call_id "
                            f"'{result.source_call_id}' does not reference a "
                            f"valid tool_call_id in this step. "
                            f"Available: {tool_call_ids}"
                        )

        return self


# ---------------------------------------------------------------------------
# API response wrappers (NOT strict — allow extra fields for forward compat)
# ---------------------------------------------------------------------------


class TrajectoryListItem(BaseModel):
    """Summary from GET /api/v1/trajectories."""

    trajectory_id: str
    task_id: str
    execution_id: str
    task_description: str | None = None
    status: TaskStatus
    reward: float
    steps_count: int | None = None
    latency_sec: float
    cost_usd: float
    langfuse_url: str | None = None


class TrajectoryDetail(BaseModel):
    """Full trajectory from GET /api/v1/trajectories/{id}."""

    trajectory_id: str
    task_id: str
    execution_id: str
    status: TaskStatus
    reward: float
    trajectory: Trajectory


class TrajectoryListResponse(BaseModel):
    """Paginated response from GET /api/v1/trajectories."""

    items: list[TrajectoryListItem]
    total: int
    limit: int
    offset: int
    message: str | None = None
