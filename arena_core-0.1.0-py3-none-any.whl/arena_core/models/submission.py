"""Submission models matching the Arena backend API.

Covers:
  - POST /api/v1/submissions/submissions       -> SubmissionCreateResponse
  - GET  /api/v1/submissions/submissions        -> SubmissionListResponse
  - GET  /api/v1/submissions/submissions/{id}   -> Submission
  - DELETE /api/v1/submissions/submissions/{id} -> SubmissionCancelResponse
  - GET  /api/v1/submissions/submissions/{id}/stream -> SSE events
  - GET  /api/v1/submissions/compare            -> SubmissionComparison
"""

from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

from arena_core.enums import AgentType, GateCheckStatus, GateMode, SubmissionStatus, TaskStatus
from arena_core.models.results import ScoreSummary, TaskOutcome

# ---------------------------------------------------------------------------
# Submission detail sub-models
# ---------------------------------------------------------------------------


class SubmissionAgentConfig(BaseModel):
    """Agent config as returned inside a submission detail response."""

    import_path: str | None = Field(
        None,
        description="Agent entrypoint e.g. agent.main:OfficeQAAgent",
    )
    harness_name: str | None = Field(None, description="Harness agent name (codex, goose, etc.)")
    model: str | None = Field(None, description="LLM model for harness agent")
    harness_config: dict[str, Any] | None = Field(None, description="Harness kwargs passthrough")
    python_version: str | None = Field(
        None,
        description="Python version used by the agent",
    )
    memory: str | None = Field(
        None,
        description="Memory limit for the agent",
    )
    timeout_per_task: int | None = Field(
        None,
        description="Timeout per task in seconds",
    )


class SubmissionAgent(BaseModel):
    """Agent info as returned inside a submission detail or list response."""

    name: str = Field(..., description="Submission/agent name")
    version: str = Field(..., description="Agent version string e.g. 0.3.1")
    type: AgentType = Field(
        AgentType.HARNESS,
        description="Agent implementation type",
    )
    config: SubmissionAgentConfig = Field(
        ...,
        description="Agent configuration used for this submission",
    )


class ExecuteStageResult(ScoreSummary):
    """Results from the execute stage of a submission."""


class SubmissionStages(BaseModel):
    """All submission stages. In v1 only execute is active."""

    execute: ExecuteStageResult | None = None
    analyze: dict | None = None  # v2-deferred
    optimize: dict | None = None  # v2-deferred


class GateStatus(BaseModel):
    """Status of a quality gate checkpoint."""

    status: GateCheckStatus
    mode: GateMode


class SubmissionProgress(BaseModel):
    """Real-time progress of a running submission."""

    tasks_total: int
    tasks_completed: int
    tasks_passed: int
    tasks_failed: int
    current_task: str | None = None


class FailedTask(TaskOutcome):
    """Summary of a single failed task within a submission."""

    description: str | None = None


class SubmissionObservability(BaseModel):
    """Observability info attached to a submission."""

    langfuse_trace_url: str | None = None
    total_tokens: int | None = None
    total_cost_usd: float | None = None
    total_duration_sec: float | None = None


# ---------------------------------------------------------------------------
# Submission responses
# ---------------------------------------------------------------------------


class Submission(BaseModel):
    """Submission detail response from GET /api/v1/submissions/{submission_id}."""

    model_config = ConfigDict(populate_by_name=True)

    id: UUID = Field(..., description="Submission id")
    status: str = Field(..., description="Submission status")
    # Server sends "topic" for backward compatibility. This field can be
    # accessed as .competition in Python. Both names work for construction
    # thanks to populate_by_name=True.
    competition: str | None = Field(
        None,
        alias="topic",
        description="Competition slug for this submission",
    )
    submitted_at: datetime = Field(
        ...,
        description="When the submission was created",
    )
    status_updated_at: datetime = Field(
        ...,
        description="When the submission status last changed",
    )
    agent: SubmissionAgent | None = Field(
        None,
        description="Agent information for this submission",
    )
    stages: SubmissionStages | None = Field(
        None,
        description="Execution stages for this submission",
    )


class SubmissionListResponse(BaseModel):
    """Paginated list of submissions from GET /api/v1/submissions."""

    items: list[Submission] = Field(
        ...,
        description="Page of submissions",
    )
    total: int = Field(
        ...,
        description="Total number of submissions",
    )
    limit: int = Field(
        ...,
        description="Requested page size",
    )
    offset: int = Field(
        ...,
        description="Requested offset",
    )


class SubmissionCreateResponse(BaseModel):
    """Response from POST /api/v1/submissions/submissions.

    Matches server SubmissionCreatedResponse: id, name, version, status.
    """

    id: UUID = Field(..., description="Submission ID")
    name: str | None = Field(None, description="Submission name")
    version: str | None = Field(None, description="Submission version")
    status: str = Field(..., description="Submission status")
    submitted_at: datetime | None = None


class SubmissionCancelResponse(BaseModel):
    """Response from DELETE /api/v1/submissions/{id}."""

    submission_id: str
    status: SubmissionStatus


# ---------------------------------------------------------------------------
# Comparison models
# ---------------------------------------------------------------------------


class ComparisonSide(BaseModel):
    """One side of a submission comparison (baseline or comparison)."""

    submission_id: str
    agent_name: str
    score: float
    tags: list[str] = []


class ComparisonDelta(BaseModel):
    """Score/latency/cost deltas between two submissions."""

    score: float
    avg_latency_sec: float | None = None
    avg_cost_usd: float | None = None


class CategoryComparison(BaseModel):
    """Per-category comparison between two submissions."""

    baseline: float
    comparison: float
    delta: float


class TaskChanges(BaseModel):
    """Task-level diff between two submission runs."""

    fixed: int
    regressed: int
    unchanged_pass: int
    unchanged_fail: int
    fixed_tasks: list[str] = []
    regressed_tasks: list[str] = []


class SubmissionComparison(BaseModel):
    """Response from GET /api/v1/submissions/compare."""

    baseline: ComparisonSide
    comparison: ComparisonSide
    delta: ComparisonDelta
    categories: dict[str, CategoryComparison] = {}
    task_changes: TaskChanges | None = None


# ---------------------------------------------------------------------------
# SSE event models
# ---------------------------------------------------------------------------


class SubmissionRunningEvent(BaseModel):
    """Data from SSE event: running. First trial started."""

    submission_id: str
    tasks_total: int


class TrialCompletedEvent(BaseModel):
    """Data from SSE event: trial_completed. Each task finishes."""

    task_id: str
    status: TaskStatus
    reward: float
    latency_sec: float
    cost_usd: float
    tasks_completed: int
    tasks_total: int


class SubmissionCompletedEvent(BaseModel):
    """Data from SSE event: completed. Final results ready."""

    submission_id: str
    status: SubmissionStatus
    score: float
    tasks_passed: int
    tasks_failed: int


class SubmissionFailedEvent(BaseModel):
    """Data from SSE event: failed. Submission error."""

    submission_id: str
    error: str
    stage: str | None = None
