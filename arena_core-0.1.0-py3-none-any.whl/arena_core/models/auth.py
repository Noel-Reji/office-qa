"""Authentication response models."""

from __future__ import annotations

import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class AuthVerifyResponse(BaseModel):
    """Response from POST /api/v1/auth/verify."""

    user_id: str
    email: str
    roles: list[str]


class TokenUser(BaseModel):
    """User info returned by the tRPC validateToken endpoint."""

    id: uuid.UUID
    email: str
    role: str


class TokenValidationResult(BaseModel):
    """Parsed ``result.data`` from the tRPC validateToken response."""

    model_config = ConfigDict(populate_by_name=True)

    valid: bool
    reason: str
    user: TokenUser | None = None
    expires_at: datetime | None = Field(default=None, alias="expiresAt")
    scope: str | None = None
