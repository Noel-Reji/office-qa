"""Competition models matching the Arena backend API.

Covers:
  - GET /api/v1/competitions         -> CompetitionListResponse
  - GET /api/v1/competitions/{slug}  -> CompetitionDetail
"""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field

from arena_core.enums import CompetitionStatus, NetworkMode


class CompetitionDefaults(BaseModel):
    """Default environment settings for a competition."""

    timeout_per_task: int = 300
    memory: str = "8G"
    python_version: str = "3.11"


class CompetitionConstraints(BaseModel):
    """Hard limits imposed by the competition."""

    max_timeout: int = 600
    max_memory: str = "32G"
    daily_submission_quota: int = 10
    network: NetworkMode = NetworkMode.PROXY_ONLY


class CompetitionScoring(BaseModel):
    """Scoring configuration for a competition."""

    aggregate: str = "mean"
    categories: list[str] = []


class SponsorSummary(BaseModel):
    """Sponsor information for a competition."""

    id: uuid.UUID = Field(..., description="Sponsor identifier")
    name: str = Field(..., description="Sponsor name")


class BenchmarkSummary(BaseModel):
    """Benchmark linked to a competition."""

    id: uuid.UUID = Field(..., description="Benchmark identifier")
    name: str = Field(..., description="Benchmark name")
    description: str | None = Field(None, description="Benchmark description")
    config: dict[str, Any] | None = Field(None, description="Benchmark configuration (JSON object)")
    dataset_path: str | None = Field(None, description="Benchmark dataset path, if applicable")
    task_count: int = Field(..., description="Number of tasks in the benchmark")
    bench_metadata: dict[str, Any] = Field(default_factory=dict, description="Additional benchmark metadata")


class TagSummary(BaseModel):
    """Tag associated with a competition."""

    id: uuid.UUID = Field(..., description="Tag identifier")
    name: str = Field(..., description="Tag name")


class CompetitionDetail(BaseModel):
    """Competition detail from GET /api/v1/competitions/{slug}.

    Also used as items in CompetitionListResponse (the list endpoint returns
    the same shape plus pagination fields).
    """

    id: uuid.UUID = Field(..., description="Competition identifier")
    name: str = Field(..., description="Competition name")
    slug: str | None = Field(None, description="URL-friendly slug")
    description: str | None = Field(None, description="Competition description")
    sponsor: SponsorSummary | None = Field(None, description="Competition sponsor")
    allowed_models: list[str] | None = Field(None, description="Optional allowlist of model identifiers")
    config: dict[str, Any] | None = Field(None, description="Competition configuration (JSON object)")
    status: CompetitionStatus = Field(..., description="Current competition status")
    arena_url: str | None = Field(None, description="Public Arena URL for this competition, if any")
    start_at: datetime = Field(..., description="Competition start time")
    end_at: datetime = Field(..., description="Competition end time")
    registration_deadline: datetime = Field(..., description="Registration deadline")
    prize_pool: str | None = Field(None, description="Prize pool description, if any")
    benchmarks: list[BenchmarkSummary] = Field(
        default_factory=list, description="Benchmarks linked to this competition"
    )
    tags: list[TagSummary] = Field(default_factory=list, description="Tags associated with this competition")


class CompetitionListResponse(BaseModel):
    """Paginated response from GET /api/v1/competitions."""

    items: list[CompetitionDetail] = Field(..., description="Page of competitions")
    total: int = Field(..., description="Total number of competitions")
    limit: int = Field(..., description="Requested page size")
    offset: int = Field(..., description="Requested offset")
