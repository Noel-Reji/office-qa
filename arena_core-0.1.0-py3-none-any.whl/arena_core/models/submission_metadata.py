"""Shared submission metadata models for the Arena wire format.

Used by both CLI (submit.py) and API server to build/parse the
multipart form payload for submission creation.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class AgentMetadata(BaseModel):
    """Agent config metadata for submission wire format."""

    type: str  # "python" | "harness"
    import_path: str | None = None  # resolved_import_path for harness
    harness_name: str | None = None  # Harness only (server needs this)
    model: str | None = None  # Harness only (LLM model)
    harness_config: dict[str, Any] | None = None
    env: dict[str, str] | None = None


class SubmissionPayload(BaseModel):
    """Top-level submission metadata (JSON Form field).

    Competition slug is a separate Form field per server API.
    """

    name: str
    version: str = "0.1.0"
    description: str | None = None
    agent: AgentMetadata
    environment: dict[str, Any] = Field(default_factory=dict)
    tags: list[str] = []
