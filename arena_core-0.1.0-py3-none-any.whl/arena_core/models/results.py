"""Local run result models.

Stored in .arena/runs/<run-id>/:
  - meta.json    -> RunMeta
  - results.json -> RunResults
"""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, Field, model_validator

from arena_core.enums import TaskStatus


class ScoreSummary(BaseModel):
    """Aggregate scoring metrics shared by local runs and submission stages."""

    score: float
    tasks_total: int = Field(ge=0)
    tasks_passed: int = Field(ge=0)
    tasks_failed: int = Field(ge=0)
    avg_latency_sec: float = Field(ge=0)
    avg_cost_usd: float = Field(ge=0)
    total_cost_usd: float = Field(ge=0)
    categories: dict[str, float] = {}

    @model_validator(mode="after")
    def _check_task_counts(self):
        if self.tasks_passed + self.tasks_failed != self.tasks_total:
            raise ValueError(
                f"tasks_passed ({self.tasks_passed}) + tasks_failed ({self.tasks_failed}) "
                f"!= tasks_total ({self.tasks_total})"
            )
        return self


class TaskOutcome(BaseModel):
    """Core fields for a single task's execution outcome."""

    task_id: str
    reward: float
    latency_sec: float
    cost_usd: float
    error: str | None = None


class TaskResult(TaskOutcome):
    """Result for a single task in a local run."""

    status: TaskStatus


class RunMeta(BaseModel):
    """Metadata for a local run stored in .arena/runs/<run-id>/meta.json."""

    run_id: str
    tag: str | None = None
    agent_name: str
    agent_version: str | None = None
    competition: str
    timestamp: datetime
    n_tasks: int
    config_snapshot: dict | None = None  # Serialized ArenaConfig at time of run


class RunResults(ScoreSummary):
    """Aggregated results for a local run stored in .arena/runs/<run-id>/results.json."""

    run_id: str
    tasks: list[TaskResult] = []
