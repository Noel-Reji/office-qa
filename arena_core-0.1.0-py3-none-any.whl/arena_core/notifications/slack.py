"""Fire-and-forget Slack webhook transport.

Never raises — failures are logged at ERROR and bumped on the
``SLACK_WEBHOOK_FAILURES`` Prometheus counter so ops can alert. Domain
formatters compose ``text`` + Block Kit ``blocks`` and call
``post_webhook``; they should not talk to aiohttp themselves.
"""

from __future__ import annotations

import logging
from typing import Any

import aiohttp
from prometheus_client import Counter

logger = logging.getLogger(__name__)

# Counter per-host so ops can tell apart a broken incoming-webhook URL
# from a flaky Slack outage. An alert rule on a non-zero delta over 15
# minutes catches silent degradation of the "park + notify admin" path
# — without this counter a post failure is invisible until a human
# checks the DB.
SLACK_WEBHOOK_FAILURES = Counter(
    "slack_webhook_failures_total",
    "Slack webhook POST failures",
    ["host"],
)


async def post_webhook(
    webhook_url: str,
    text: str,
    *,
    blocks: list[dict[str, Any]] | None = None,
    timeout_seconds: float = 10.0,
) -> None:
    """POST to Slack webhook. Catches all exceptions; never raises.

    ``blocks`` is the optional Block Kit payload; when given, it takes
    precedence visually and ``text`` is the fallback/notification string.
    """
    payload: dict[str, Any] = {"text": text}
    if blocks is not None:
        payload["blocks"] = blocks

    try:
        async with aiohttp.ClientSession() as session:
            resp = await session.post(
                webhook_url,
                json=payload,
                timeout=aiohttp.ClientTimeout(total=timeout_seconds),
            )
            if resp.status >= 400:
                logger.error("Slack webhook returned %d for %s", resp.status, _redact_host(webhook_url))
                SLACK_WEBHOOK_FAILURES.labels(host=_extract_host(webhook_url)).inc()
    except Exception:
        logger.exception("Failed to send Slack webhook to %s", _redact_host(webhook_url))
        SLACK_WEBHOOK_FAILURES.labels(host=_extract_host(webhook_url)).inc()


def _extract_host(webhook_url: str) -> str:
    """hooks.slack.com etc. — used as a metric label so incoming-webhook URLs
    don't pollute the label space."""
    try:
        from urllib.parse import urlparse

        return urlparse(webhook_url).hostname or "unknown"
    except Exception:
        return "unknown"


def _redact_host(webhook_url: str) -> str:
    """Log the host (never the secret path) of a webhook URL."""
    return _extract_host(webhook_url)
