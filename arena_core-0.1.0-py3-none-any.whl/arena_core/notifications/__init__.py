"""Shared notification transports (Slack, etc.).

Domain-specific formatters (e.g., quarantine alerts) compose text + Block
Kit payloads in their own packages and call the transport functions here.
"""

from .slack import SLACK_WEBHOOK_FAILURES, post_webhook

__all__ = ["post_webhook", "SLACK_WEBHOOK_FAILURES"]
