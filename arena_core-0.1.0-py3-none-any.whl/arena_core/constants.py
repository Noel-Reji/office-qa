"""Platform-wide constants. Single source of truth for magic strings."""

# Authentication
TOKEN_PREFIX = ""
TOKEN_ENV_VAR = "ARENA_TOKEN"
CREDENTIALS_SECTION = "default"

# API error codes (used in backend error envelopes)
ERROR_CODE_QUOTA_EXCEEDED = "QUOTA_EXCEEDED"
ERROR_CODE_TEAM_SUSPENDED = "TEAM_SUSPENDED"

# Harbor SDK
HARBOR_SDK_MODULE = "harbor.sdk"

# Default timeout baseline (used by Harbor timeout multiplier)
DEFAULT_TIMEOUT_PER_TASK = 300

# User-facing copy for submission lifecycle emails (SES template var daily_quota_refresh)
DAILY_QUOTA_REFRESH = "11:59 PM PDT"
