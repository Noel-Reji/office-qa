"""Shared enumerations for the Arena platform.

StrEnum values serialize as plain strings in JSON and compare naturally
with string literals, so they are fully backward-compatible.
"""

from enum import StrEnum


class TaskStatus(StrEnum):
    """Outcome of a single task evaluation."""

    PASSED = "passed"
    FAILED = "failed"


class GateCheckStatus(StrEnum):
    """Status of a quality gate checkpoint."""

    APPROVED = "approved"
    REJECTED = "rejected"
    PENDING = "pending"


class GateMode(StrEnum):
    """Behavior mode for a quality gate."""

    NOTIFY = "notify"
    PAUSE = "pause"


class StepSource(StrEnum):
    """Source of a trajectory step."""

    SYSTEM = "system"
    USER = "user"
    AGENT = "agent"


class NetworkMode(StrEnum):
    """Network access mode for agent execution."""

    SANDBOX = "sandbox"
    RESTRICTED = "restricted"
    PROXY_ONLY = "proxy_only"


class AgentType(StrEnum):
    """Type of agent submission."""

    PYTHON = "python"
    HARNESS = "harness"


class SubmissionEventType(StrEnum):
    """SSE event types for submission streaming."""

    RUNNING = "running"
    TRIAL_COMPLETED = "trial_completed"
    COMPLETED = "completed"
    FAILED = "failed"


class ApplicationStatus(StrEnum):
    """Status of a user's competition application."""

    IN_REVIEW = "in_review"
    ACCEPTED = "accepted"
    REJECTED = "rejected"


class CompetitionStatus(StrEnum):
    """Status of a challenge/competition lifecycle (mirrors DB challenge_status)."""

    DRAFT = "draft"
    ACTIVE = "active"
    COMPLETED = "completed"


class ExecutionStatus(StrEnum):
    """Status of a submission execution in the eval pipeline."""

    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class SubmissionStatus(StrEnum):
    """Broad, user-facing submission lifecycle status.

    Security and queue detail live in :class:`PipelineState`; this enum is
    intentionally coarse for APIs and UI.
    """

    SUBMITTED = "submitted"
    UNDER_REVIEW = "under_review"
    APPROVED = "approved"
    IN_PROGRESS = "in_progress"
    REJECTED = "rejected"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class SecurityReviewStatus(StrEnum):
    """Status of a security review for a submission."""

    PENDING_REVIEW = "pending_review"
    APPROVED = "approved"
    QUARANTINED = "quarantined"
    ADMIN_APPROVED = "admin_approved"
    ADMIN_REJECTED = "admin_rejected"
    REVIEW_FAILED = "review_failed"
    QUARANTINE_OVERSIZE = "quarantine_oversize"
    REVIEW_DEFERRED_OVER_BUDGET = "review_deferred_over_budget"
    REVIEW_DEGRADED = "review_degraded"
    REVIEW_LOW_CONFIDENCE = "review_low_confidence"


class PipelineState(StrEnum):
    """Internal pipeline state: security-review granularity plus eval queue lifecycle."""

    # Upload / pre-eval surface
    SUBMITTED = "submitted"
    UNDER_REVIEW = "under_review"
    L1_REVIEW_COMPLETED = "l1_review_completed"
    L1_REVIEW_FAILED = "l1_review_failed"
    L2_REVIEW_COMPLETED = "l2_review_completed"
    L2_REVIEW_FAILED = "l2_review_failed"
    REVIEW_COMPLETED = "review_completed"
    # Post-review admin gate (string values match SubmissionStatus.approved / rejected)
    APPROVED = "approved"
    REJECTED = "rejected"
    # Eval queue / executor lifecycle (existing)
    QUEUED = "queued"
    QUEUE_WORKER = "queue_worker"
    EXECUTOR = "executor"
    ATTEMPTING_CANCELLATION = "attempting_cancellation"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class SubmissionStage(StrEnum):
    """Stage of a submission evaluation."""

    EXECUTE = "execute"
    ANALYZE = "analyze"
    OPTIMIZE = "optimize"


# ---------------------------------------------------------------------------
# Submission status transitions
# ---------------------------------------------------------------------------

VALID_TRANSITIONS: dict[SubmissionStatus, set[SubmissionStatus]] = {
    SubmissionStatus.SUBMITTED: {
        SubmissionStatus.APPROVED,
        SubmissionStatus.IN_PROGRESS,  # migration / legacy rows only
        SubmissionStatus.FAILED,
        SubmissionStatus.CANCELLED,
        SubmissionStatus.UNDER_REVIEW,
    },
    SubmissionStatus.UNDER_REVIEW: {
        SubmissionStatus.APPROVED,  # security cleared; eligible for eval queue
        SubmissionStatus.REJECTED,
        SubmissionStatus.CANCELLED,
    },
    SubmissionStatus.APPROVED: {
        SubmissionStatus.IN_PROGRESS,  # eval worker starts execution
        SubmissionStatus.CANCELLED,
    },
    SubmissionStatus.IN_PROGRESS: {
        SubmissionStatus.COMPLETED,
        SubmissionStatus.FAILED,
        SubmissionStatus.CANCELLED,
    },
    # Admin re-run only: return submission to the eval-eligible pool.
    SubmissionStatus.COMPLETED: {SubmissionStatus.APPROVED},
    SubmissionStatus.FAILED: {SubmissionStatus.IN_PROGRESS, SubmissionStatus.APPROVED},  # retry or admin re-queue
    SubmissionStatus.CANCELLED: set(),  # terminal
    SubmissionStatus.REJECTED: set(),  # terminal — no admin-override in this PR
}

# IMPORTANT: The Postgres function is_valid_submission_status_transition mirrors
# these edges (initially in security_review_state_machine_trigger.sql; later
# deltas e.g. submission_status_transition_in_progress_cancelled.sql and
# submission_status_transition_approved.sql).
# Keep SQL and Python in sync. projects/sentient-db/tests/test_trigger_python_parity.py
# asserts equality against a running database.


def is_valid_transition(current: SubmissionStatus, target: SubmissionStatus) -> bool:
    """Check if a status transition is valid according to the state machine."""
    return target in VALID_TRANSITIONS.get(current, set())
