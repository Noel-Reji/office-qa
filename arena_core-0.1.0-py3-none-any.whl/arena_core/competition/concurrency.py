"""Per-competition concurrent submission limits.

Lives under ``competition.config["concurrent_submissions"]`` (JSONB) and is
opt-in: absent or ``max_concurrent == 1`` reproduces the historical behaviour
of "one in-flight submission per team".

Only consulted for viewers that pass the API server's internal-role check; for
everyone else the existing single-active-submission guard still applies.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class ConcurrentSubmissionsConfig(BaseModel):
    """Configuration parsed from ``competition.config["concurrent_submissions"]``.

    ``extra="ignore"`` matches the rest of the competition-config models so that
    forward-compatible additions don't break older API servers.
    """

    model_config = ConfigDict(extra="ignore")

    max_concurrent: int = Field(default=1, ge=1)


def extract_concurrent_submissions_config(
    competition_config: dict[str, Any] | None,
) -> ConcurrentSubmissionsConfig:
    """Build ``ConcurrentSubmissionsConfig`` from a competition row's ``config`` JSONB."""
    section = (competition_config or {}).get("concurrent_submissions") or {}
    return ConcurrentSubmissionsConfig(**section)
