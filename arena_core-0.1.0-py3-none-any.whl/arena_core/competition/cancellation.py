"""Per-competition submission cancellation behavior."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict


class SubmissionCancellationConfig(BaseModel):
    """Configuration parsed from ``competition.config["submission_cancellation"]``."""

    model_config = ConfigDict(extra="ignore")

    refund_quota_on_cancel: bool = True


def extract_submission_cancellation_config(
    competition_config: dict[str, Any] | None,
) -> SubmissionCancellationConfig:
    """Build ``SubmissionCancellationConfig`` from a competition row's ``config`` JSONB."""
    section = (competition_config or {}).get("submission_cancellation") or {}
    return SubmissionCancellationConfig(**section)
