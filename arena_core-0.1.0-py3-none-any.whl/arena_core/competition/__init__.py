"""Competition-level configuration models."""

from arena_core.competition.cancellation import (
    SubmissionCancellationConfig,
    extract_submission_cancellation_config,
)
from arena_core.competition.concurrency import (
    ConcurrentSubmissionsConfig,
    extract_concurrent_submissions_config,
)
from arena_core.competition.daily_quota import (
    DailyTeamSubmissionLimitConfig,
    extract_daily_team_submission_limit_config,
    resolve_daily_team_submission_limit,
)

__all__ = [
    "SubmissionCancellationConfig",
    "extract_submission_cancellation_config",
    "ConcurrentSubmissionsConfig",
    "extract_concurrent_submissions_config",
    "DailyTeamSubmissionLimitConfig",
    "extract_daily_team_submission_limit_config",
    "resolve_daily_team_submission_limit",
]
