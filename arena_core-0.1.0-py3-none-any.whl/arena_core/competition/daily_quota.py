"""Per-competition daily team submission limits.

Lives under ``competition.config["daily_team_submission_limit"]`` (JSONB).
When absent, API servers fall back to ``ApiServerSettings.daily_team_submission_limit``.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field, ValidationError


class DailyTeamSubmissionLimitConfig(BaseModel):
    """Configuration parsed from ``competition.config["daily_team_submission_limit"]``.

    ``limit`` is optional: ``None`` means use the server default from settings.
    """

    model_config = ConfigDict(extra="ignore")

    limit: int | None = Field(default=None, ge=1)


def extract_daily_team_submission_limit_config(
    competition_config: dict | None,
) -> DailyTeamSubmissionLimitConfig:
    """Build ``DailyTeamSubmissionLimitConfig`` from a competition row's ``config`` JSONB."""
    raw = (competition_config or {}).get("daily_team_submission_limit")
    if raw is None:
        return DailyTeamSubmissionLimitConfig()
    try:
        if isinstance(raw, int) and not isinstance(raw, bool):
            return DailyTeamSubmissionLimitConfig(limit=raw)
        if isinstance(raw, dict):
            return DailyTeamSubmissionLimitConfig(**raw)
    except ValidationError:
        pass
    return DailyTeamSubmissionLimitConfig()


def resolve_daily_team_submission_limit(
    competition_config: dict | None,
    *,
    default: int,
) -> int:
    """Return the effective per-team daily submission limit for a competition."""
    cfg = extract_daily_team_submission_limit_config(competition_config)
    return cfg.limit if cfg.limit is not None else default
