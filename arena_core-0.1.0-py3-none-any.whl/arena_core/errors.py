"""Arena error hierarchy.

All Arena exceptions inherit from ArenaError. Each carries an exit_code
that the CLI uses as the process exit code.

Exit code assignments:
  1 — General / submission errors
  2 — Configuration errors (bad arena.yaml)
  3 — Authentication errors
  4 — Network / connectivity errors
  5 — Harbor / local execution errors
"""

from __future__ import annotations

from datetime import UTC, datetime


class ArenaError(Exception):
    """Base exception for all Arena errors."""

    exit_code: int = 1

    def __init__(self, message: str = "") -> None:
        self.message = message
        super().__init__(message)


class ConfigError(ArenaError):
    """Bad arena.yaml, missing fields, or invalid values."""

    exit_code: int = 2


class AuthError(ArenaError):
    """Invalid/expired token or login required."""

    exit_code: int = 3


class NetworkError(ArenaError):
    """Backend unreachable or connection error."""

    exit_code: int = 4


class HarborError(ArenaError):
    """Wraps Harbor SDK errors (Docker not running, agent crash, container failure)."""

    exit_code: int = 5


class SubmitError(ArenaError):
    """Upload failure, packaging error, or build failure."""

    exit_code: int = 1


class ApiError(ArenaError):
    """Structured error from the Arena backend API.

    Carries the HTTP status code, Arena error code, and optional request_id
    for debugging.

    Attributes:
        status_code: HTTP status code (e.g., 400, 401, 404, 429).
        error_code: Arena error code string (e.g., "QUOTA_EXCEEDED").
        request_id: Server-assigned request ID for support debugging.
    """

    exit_code: int = 1

    def __init__(
        self,
        message: str,
        status_code: int,
        error_code: str | None = None,
        request_id: str | None = None,
    ) -> None:
        self.status_code = status_code
        self.error_code = error_code
        self.request_id = request_id
        super().__init__(message)


class QuotaExceededError(ApiError):
    """Daily submission quota exceeded (HTTP 429, code QUOTA_EXCEEDED).

    Attributes:
        daily_limit: Maximum submissions per day (None if not provided).
        used_today: Number of submissions already used today (None if not provided).
        resets_at: ISO 8601 timestamp when the quota resets (None if not provided).
    """

    exit_code: int = 1

    def __init__(
        self,
        message: str,
        daily_limit: int | None = None,
        used_today: int | None = None,
        resets_at: str | None = None,
        request_id: str | None = None,
    ) -> None:
        self.daily_limit = daily_limit
        self.used_today = used_today
        self.resets_at = resets_at
        super().__init__(
            message=message,
            status_code=429,
            error_code="QUOTA_EXCEEDED",
            request_id=request_id,
        )


class RateLimitedError(ApiError):
    """Too many requests (HTTP 429, code RATE_LIMITED).

    Distinct from QuotaExceededError — this is a transient rate limit,
    not a daily quota exhaustion.
    """

    exit_code: int = 1

    def __init__(self, message: str = "Too many requests", request_id: str | None = None) -> None:
        super().__init__(
            message=message,
            status_code=429,
            error_code="RATE_LIMITED",
            request_id=request_id,
        )


class CompetitionNotFoundError(ApiError):
    """Competition slug not found (HTTP 404)."""

    exit_code: int = 1

    def __init__(self, slug: str, request_id: str | None = None) -> None:
        self.slug = slug
        super().__init__(
            message=f"Competition not found: {slug}",
            status_code=404,
            error_code="NOT_FOUND",
            request_id=request_id,
        )


class SubmissionNotFoundError(ApiError):
    """Submission ID not found (HTTP 404)."""

    exit_code: int = 1

    def __init__(self, submission_id: str, request_id: str | None = None) -> None:
        self.submission_id = submission_id
        super().__init__(
            message=f"Submission not found: {submission_id}",
            status_code=404,
            error_code="NOT_FOUND",
            request_id=request_id,
        )


class ValidationError(ApiError):
    """Server-side validation error (HTTP 400, code VALIDATION_ERROR)."""

    exit_code: int = 2

    def __init__(self, message: str, request_id: str | None = None) -> None:
        super().__init__(
            message=message,
            status_code=400,
            error_code="VALIDATION_ERROR",
            request_id=request_id,
        )


class TeamSuspendedError(ApiError):
    """Team is suspended and cannot perform the requested action (HTTP 403, code TEAM_SUSPENDED).

    The exception ``message`` is auto-formatted from the structured fields so
    that ``str(exc)`` is suitable for direct display to end users. Callers
    that need to inspect the suspension programmatically can read the
    ``reason`` and ``suspended_until`` attributes.

    Attributes:
        reason: Admin-entered reason for the suspension (free-form text).
        suspended_until: When the suspension expires; ``None`` for permanent.
    """

    exit_code: int = 1

    _DEFAULT_MESSAGE = "Your team is suspended and cannot submit."

    def __init__(
        self,
        message: str | None = None,
        *,
        reason: str | None = None,
        suspended_until: datetime | None = None,
        request_id: str | None = None,
    ) -> None:
        self.reason = reason
        self.suspended_until = suspended_until
        super().__init__(
            message=self._format_message(message or self._DEFAULT_MESSAGE, reason, suspended_until),
            status_code=403,
            error_code="TEAM_SUSPENDED",
            request_id=request_id,
        )

    @staticmethod
    def _format_message(message: str, reason: str | None, suspended_until: datetime | None) -> str:
        lines = [message]
        reason_line = ""
        if reason and reason.strip():
            reason_line = f"Reason: {reason.strip()}"
        if suspended_until is not None:
            utc = suspended_until.astimezone(UTC) if suspended_until.tzinfo else suspended_until.replace(tzinfo=UTC)
            suffix = f"Suspended until {utc.strftime('%Y-%m-%d %H:%M UTC')}."
            if reason_line:
                reason_line = reason_line.rstrip()
                if not reason_line.endswith("."):
                    reason_line += "."
                reason_line += f" {suffix}"
            else:
                reason_line = suffix
        if reason_line:
            lines.append(reason_line)
        return "\n".join(lines)
