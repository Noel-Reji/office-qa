"""Email service interface and AWS SES implementation."""

from __future__ import annotations

import json
from abc import ABC, abstractmethod
from typing import Any

import aioboto3
from botocore.exceptions import ClientError


class EmailServiceError(Exception):
    """Raised when sending email fails."""


class EmailService(ABC):
    """Abstract interface for sending email."""

    @abstractmethod
    async def send(
        self,
        to_addresses: list[str] | str,
        subject: str,
        body_text: str,
        *,
        body_html: str | None = None,
        source: str | None = None,
        reply_to: list[str] | None = None,
        cc_addresses: list[str] | None = None,
        bcc_addresses: list[str] | None = None,
    ) -> str:
        """Send an email. Returns message ID."""
        ...

    @abstractmethod
    async def send_templated(
        self,
        to_addresses: list[str] | str,
        template_name: str,
        template_data: dict[str, Any],
        *,
        source: str | None = None,
        reply_to: list[str] | None = None,
        cc_addresses: list[str] | None = None,
        bcc_addresses: list[str] | None = None,
    ) -> str:
        """Send an email using a template. Returns message ID."""
        ...


class SesEmailService(EmailService):
    """Send email via AWS SES (async via aioboto3)."""

    def __init__(
        self,
        *,
        region_name: str | None = None,
        source: str | None = None,
        session: Any = None,
    ) -> None:
        """Create an email service.

        Uses an aioboto3 Session and the default AWS credential chain.

        Args:
            region_name: AWS region for SES (e.g. 'us-east-1'). Uses default region if None.
            source: Default From address. Required by SES; can be overridden per send.
            session: Optional ``aioboto3.Session`` (or test double implementing ``.client()``).
        """
        self._session = session if session is not None else aioboto3.Session(region_name=region_name)
        self._default_source = source

    def _resolve_source(self, source: str | None) -> str:
        """Resolve From address from override or default; raise if missing."""
        from_addr = source or self._default_source
        if not from_addr:
            raise EmailServiceError("Email source (From) is required; set source= or pass at send()")
        return from_addr

    def _build_destination(
        self,
        to_addresses: list[str] | str,
        cc_addresses: list[str] | None = None,
        bcc_addresses: list[str] | None = None,
    ) -> dict[str, list[str]]:
        """Build SES Destination dict from to/cc/bcc."""
        to_list = [to_addresses] if isinstance(to_addresses, str) else list(to_addresses)
        destination: dict[str, list[str]] = {"ToAddresses": to_list}
        if cc_addresses:
            destination["CcAddresses"] = cc_addresses
        if bcc_addresses:
            destination["BccAddresses"] = bcc_addresses
        return destination

    @staticmethod
    def _ses_content(data: str) -> dict[str, str]:
        """SES content dict: Data + Charset UTF-8."""
        return {"Data": data, "Charset": "UTF-8"}

    def _base_params(
        self,
        from_addr: str,
        destination: dict[str, list[str]],
        reply_to: list[str] | None = None,
    ) -> dict[str, Any]:
        """Build common SES params: Source, Destination, optional ReplyToAddresses."""
        params: dict[str, Any] = {
            "Source": from_addr,
            "Destination": destination,
        }
        if reply_to:
            params["ReplyToAddresses"] = reply_to
        return params

    async def _call_ses_and_get_message_id(self, method_name: str, error_prefix: str, **params: Any) -> str:
        """Call SES client method and return MessageId; raise EmailServiceError on failure."""
        try:
            async with self._session.client("ses") as client:
                response = await getattr(client, method_name)(**params)
            return response.get("MessageId", "")
        except ClientError as e:
            raise EmailServiceError(f"{error_prefix}: {e}") from e

    async def send(
        self,
        to_addresses: list[str] | str,
        subject: str,
        body_text: str,
        *,
        body_html: str | None = None,
        source: str | None = None,
        reply_to: list[str] | None = None,
        cc_addresses: list[str] | None = None,
        bcc_addresses: list[str] | None = None,
    ) -> str:
        """Send an email via SES.

        Args:
            to_addresses: Recipient(s). Single string or list.
            subject: Subject line.
            body_text: Plain-text body (required by SES).
            body_html: Optional HTML body.
            source: From address. Uses instance default if None.
            reply_to: Optional Reply-To addresses.
            cc_addresses: Optional CC addresses.
            bcc_addresses: Optional BCC addresses.

        Returns:
            SES MessageId from the send response.

        Raises:
            EmailServiceError: If source is missing or SES returns an error.
        """
        from_addr = self._resolve_source(source)
        destination = self._build_destination(to_addresses, cc_addresses, bcc_addresses)

        message: dict = {
            "Subject": self._ses_content(subject),
            "Body": {"Text": self._ses_content(body_text)},
        }
        if body_html is not None:
            message["Body"]["Html"] = self._ses_content(body_html)

        params = {**self._base_params(from_addr, destination, reply_to), "Message": message}
        return await self._call_ses_and_get_message_id("send_email", "SES send failed", **params)

    async def send_templated(
        self,
        to_addresses: list[str] | str,
        template_name: str,
        template_data: dict[str, Any],
        *,
        source: str | None = None,
        reply_to: list[str] | None = None,
        cc_addresses: list[str] | None = None,
        bcc_addresses: list[str] | None = None,
    ) -> str:
        """Send an email using an SES template.

        The template must already exist in SES. Template variable placeholders
        (e.g. {{name}}) are filled from template_data.

        Args:
            to_addresses: Recipient(s). Single string or list.
            template_name: Name of the SES template.
            template_data: Key-value data for template variables (must be JSON-serializable).
            source: From address. Uses instance default if None.
            reply_to: Optional Reply-To addresses.
            cc_addresses: Optional CC addresses.
            bcc_addresses: Optional BCC addresses.

        Returns:
            SES MessageId from the send response.

        Raises:
            EmailServiceError: If source is missing or SES returns an error.
        """
        from_addr = self._resolve_source(source)
        destination = self._build_destination(to_addresses, cc_addresses, bcc_addresses)

        params = {
            **self._base_params(from_addr, destination, reply_to),
            "Template": template_name,
            "TemplateData": json.dumps(template_data),
        }
        return await self._call_ses_and_get_message_id("send_templated_email", "SES send_templated failed", **params)
