"""Email service interface and AWS SES implementation."""

from .email_service import EmailService, EmailServiceError, SesEmailService
from .submission_scope import (
    SUBMISSION_EMAIL_SCOPE_ALL,
    SUBMISSION_EMAIL_SCOPE_INTERNAL_ONLY,
    SubmissionEmailScope,
    should_send_submission_lifecycle_email,
)

__all__ = [
    "EmailService",
    "EmailServiceError",
    "SesEmailService",
    "SUBMISSION_EMAIL_SCOPE_ALL",
    "SUBMISSION_EMAIL_SCOPE_INTERNAL_ONLY",
    "SubmissionEmailScope",
    "should_send_submission_lifecycle_email",
]
