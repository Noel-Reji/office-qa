"""When to send submission lifecycle emails (received / succeeded)."""

from __future__ import annotations

from typing import Literal

SubmissionEmailScope = Literal["internal_only", "all"]

SUBMISSION_EMAIL_SCOPE_INTERNAL_ONLY: SubmissionEmailScope = "internal_only"
SUBMISSION_EMAIL_SCOPE_ALL: SubmissionEmailScope = "all"


def should_send_submission_lifecycle_email(
    *,
    competition_internal_only: bool,
    scope: SubmissionEmailScope,
) -> bool:
    """Return True if lifecycle emails should be sent for this competition."""
    if scope == SUBMISSION_EMAIL_SCOPE_ALL:
        return True
    return competition_internal_only
