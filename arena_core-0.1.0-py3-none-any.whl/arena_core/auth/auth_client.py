"""Auth client interface and tRPC implementation."""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import Any

import httpx

from arena_core.models.auth import TokenValidationResult

logger = logging.getLogger(__name__)


class AuthClientError(Exception):
    """Raised when the auth service call fails."""


class AuthClient(ABC):
    """Abstract interface for validating authentication tokens."""

    @abstractmethod
    async def validate_token(self, token: str) -> TokenValidationResult:
        """Validate a bearer token and return the result.

        Args:
            token: The bearer token to validate.

        Returns:
            A TokenValidationResult with validity, user info, and metadata.

        Raises:
            AuthClientError: If the auth service is unreachable or returns
                an unexpected response.
        """
        ...

    async def close(self) -> None:  # noqa: B027 - default no-op is intentional; see docstring
        """Release any resources held by the client.

        Default no-op for implementations that hold no lifecycle state
        (e.g. test stubs). Concrete clients that own a network connection
        (e.g. :class:`ArenaAuthClient`'s ``httpx.AsyncClient``) override
        this to release them, and wrappers (e.g. ``InstrumentedAuthClient``)
        forward to their inner client.

        Not marked ``@abstractmethod`` so subclasses are not forced to
        re-declare a no-op — wrappers like ``InstrumentedAuthClient`` can
        still call ``await self._inner.close()`` against any AuthClient.
        """


class ArenaAuthClient(AuthClient):
    """Validates tokens against a tRPC auth service.

    Calls ``{base_url}/trpc/validateToken`` with the token in an
    ``Authorization: Bearer`` header and parses the nested tRPC
    response envelope.
    """

    def __init__(
        self,
        *,
        base_url: str,
        timeout: float = 10.0,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._owns_client = client is None
        self._client = client or httpx.AsyncClient(timeout=timeout)

    async def validate_token(self, token: str) -> TokenValidationResult:
        url = f"{self._base_url}/trpc/validateToken"
        try:
            response = await self._client.get(
                url,
                headers={"Authorization": f"Bearer {token}"},
            )
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            raise AuthClientError(f"Auth service returned {exc.response.status_code}") from exc
        except httpx.TransportError as exc:
            raise AuthClientError(f"Auth service unreachable at {self._base_url}: {exc}") from exc

        body: dict[str, Any] = response.json()
        try:
            data = body["result"]["data"]
        except (KeyError, TypeError) as exc:
            logger.debug("Unexpected response shape from auth service: %s", body)
            raise AuthClientError("Unexpected response shape from auth service") from exc

        return TokenValidationResult.model_validate(data)

    async def close(self) -> None:
        """Close the underlying HTTP client if we own it."""
        if self._owns_client:
            await self._client.aclose()
