"""Auth client interface and tRPC implementation."""

from .auth_client import ArenaAuthClient, AuthClient, AuthClientError

__all__ = ["ArenaAuthClient", "AuthClient", "AuthClientError"]
