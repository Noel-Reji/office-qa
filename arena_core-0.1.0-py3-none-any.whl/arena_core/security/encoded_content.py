"""Encoded content detection: base64/85, hex, URL, ascii85, uuencode,
zlib, gzip, brotli (optional) blobs, plus substitution ciphers.

Recursively decodes content up to ``encoding_max_depth`` (default 4),
re-running the answer matcher on each layer. Per-depth short-encoded
scans catch individually encoded short answers nested inside larger
blobs. Memory bounded by ``max_decoded_total_bytes``; emits
``decode_cap_reached`` flag when hit.
"""

from __future__ import annotations

import base64
import binascii
import gzip as gzip_module
import hashlib
import logging
import re
import urllib.parse
import zlib

from arena_core.security.answer_matcher import (
    _extract_fragments,
    _line_key,
    check_answer_matches,
)
from arena_core.security.models import MAX_AFFECTED_PATHS, CheckResult, is_sentinel_path
from arena_core.security.unicode_skeleton import canonicalise

try:
    import brotli  # type: ignore[import-not-found]
except ImportError:  # pragma: no cover — brotli is optional
    brotli = None

logger = logging.getLogger(__name__)

CHECK_NAME = "encoded_content"
CHECK_NAME_SUBSTITUTION = "substitution_cipher"
CHECK_NAME_DECODE_CAP = "decode_cap_reached"

# Compiled regexes for blob detection (standard + URL-safe base64 alphabet)
_BASE64_RE = re.compile(r"[A-Za-z0-9+/\-_]{40,}={0,2}")
_HEX_RE = re.compile(r"(?:0x)?[0-9a-fA-F]{40,}")
_URL_ENCODED_RE = re.compile(r"(?:%[0-9a-fA-F]{2}){50,}")
_ASCII85_RE = re.compile(r"<~[!-uz]{20,}~>")
_BASE85_RE = re.compile(r"[0-9A-Za-z!#$%&()*+\-;<=>?@^_`{|}~]{40,}")
_UUENCODE_BLOCK_RE = re.compile(
    r"begin\s+\d{3}\s+\S+\s*\n((?:[ -`\n]+\n)+?)`?\s*\nend",
    re.MULTILINE,
)

# Short encoded tokens (3-39 chars) — targeted scan for individually encoded answers
_SHORT_BASE64_RE = re.compile(r"[A-Za-z0-9+/\-_]{3,39}={0,2}")
_SHORT_HEX_RE = re.compile(r"(?:0x)?[0-9a-fA-F]{4,39}")
_SHORT_BASE32_RE = re.compile(r"[A-Z2-7]{4,}={0,6}")

# Filter: pure lowercase alpha tokens are likely English words, not encoded data
_PURE_LOWER_ALPHA_RE = re.compile(r"^[a-z]+$")

# Tokeniser for short-encoded scan: split on whitespace + delimiters that
# typically bracket encoded values in code (assignments, JSON, function calls).
_SHORT_TOKEN_SPLIT_RE = re.compile(r'[\s,;:=\[\]\(\)\{\}"\']+')

# Magic bytes for gzip / zlib / brotli sniffing in raw byte content.
_GZIP_MAGIC = b"\x1f\x8b"
_ZLIB_MAGIC = (b"\x78\x9c", b"\x78\xda", b"\x78\x01", b"\x78\x5e")


def _decode_or_decompress(raw: bytes) -> str | None:
    """Best-effort path from raw bytes to text. Try compressed-payload
    decompression first (gzip/zlib/brotli magic), fall back to UTF-8 decode
    with replacement. Returns None only if the bytes are empty.
    """
    if not raw:
        return None
    decompressed = _try_decompress(raw)
    if decompressed is not None:
        return decompressed
    return raw.decode("utf-8", errors="replace")


def _try_decode_base64(blob: str) -> str | None:
    """Attempt standard and URL-safe base64 decode. If the decoded bytes
    are gzip/zlib/brotli compressed, return the decompressed text — saves
    one depth iteration on chained ``base64(zlib(...))`` payloads.
    """
    normalized = blob.replace("-", "+").replace("_", "/")
    padded = normalized + "=" * (-len(normalized) % 4)
    try:
        raw = base64.b64decode(padded, validate=True)
    except Exception:
        return None
    return _decode_or_decompress(raw)


def _try_decode_base32(blob: str) -> str | None:
    padded = blob + "=" * (-len(blob) % 8)
    try:
        raw = base64.b32decode(padded, casefold=True)
    except Exception:
        return None
    return _decode_or_decompress(raw)


def _try_decode_hex(blob: str) -> str | None:
    clean = blob.removeprefix("0x").removeprefix("0X")
    if len(clean) % 2 != 0:
        return None
    try:
        return binascii.unhexlify(clean).decode("utf-8", errors="replace")
    except Exception:
        return None


def _try_decode_url(blob: str) -> str | None:
    try:
        decoded = urllib.parse.unquote(blob)
        return decoded if decoded != blob else None
    except Exception:
        return None


def _try_decode_base85(blob: str) -> str | None:
    try:
        return base64.b85decode(blob).decode("utf-8", errors="replace")
    except Exception:
        return None


def _try_decode_ascii85(blob: str) -> str | None:
    try:
        return base64.a85decode(blob, adobe=True).decode("utf-8", errors="replace")
    except Exception:
        return None


def _try_decode_uuencode(block: str) -> str | None:
    try:
        decoded = bytearray()
        for line in block.splitlines():
            if not line:
                continue
            try:
                decoded.extend(binascii.a2b_uu(line))
            except (binascii.Error, ValueError):
                continue
        if not decoded:
            return None
        return decoded.decode("utf-8", errors="replace")
    except Exception:
        return None


def _try_decompress(raw: bytes) -> str | None:
    """Try zlib / gzip / brotli decompression on raw bytes; return decoded text
    or None if no recognised wrapper applies."""
    if raw.startswith(_GZIP_MAGIC):
        try:
            return gzip_module.decompress(raw).decode("utf-8", errors="replace")
        except Exception:
            return None
    if any(raw.startswith(magic) for magic in _ZLIB_MAGIC):
        try:
            return zlib.decompress(raw).decode("utf-8", errors="replace")
        except Exception:
            return None
    if brotli is not None:
        try:
            return brotli.decompress(raw).decode("utf-8", errors="replace")
        except Exception:
            return None
    return None


def _check_short_encoded_answers(
    pieces_with_origin: list[tuple[str, str]],
    answer_hashes: frozenset[str] | set[str],
    min_exact_matches: int,
    *,
    max_evidence_line_len: int = 240,
    seen: set[tuple[str, int]] | None = None,
) -> tuple[set[tuple[str, str]], list[str], set[str]]:
    """Scan for individually encoded short answers (3-39 chars).

    Returns ``(matched_pairs, evidence_lines, affected_origins)`` keyed on
    ``(line_key, answer_hash)`` so the same answer leaked on N distinct
    lines counts as N — closes the multiset bypass. ``affected_origins``
    is the set of original tarball paths whose content participated in a
    match (used to populate ``CheckResult.affected_paths``).

    ``pieces_with_origin`` is a list of ``(origin_path, content)`` tuples;
    the origin path may be the same for several decoded intermediates
    produced from a single input file.

    ``seen`` is a ``(origin, hash(piece))`` set: dedup is per-origin so two
    distinct files carrying the same decoded blob both contribute their
    origin to ``affected_origins``. Without the origin dimension the
    second file's path would silently drop out of ``affected_paths``.
    """
    known = answer_hashes if isinstance(answer_hashes, frozenset) else set(answer_hashes)
    matched_pairs: set[tuple[str, str]] = set()
    evidence: list[str] = []
    affected: set[str] = set()
    if seen is None:
        seen = set()

    for origin, piece in pieces_with_origin:
        key = (origin, hash(piece))
        if key in seen:
            continue
        seen.add(key)
        # Use the piece-level line_key as a proxy: short tokens don't have
        # natural lines, so all matches in a single piece share one key.
        line_key = _line_key(piece[:1024])
        for token in _SHORT_TOKEN_SPLIT_RE.split(piece):
            token = token.strip()
            if len(token) < 3 or _PURE_LOWER_ALPHA_RE.match(token):
                continue

            candidates: list[tuple[str, str]] = []
            if _SHORT_BASE64_RE.fullmatch(token):
                d = _try_decode_base64(token)
                if d:
                    candidates.append((d.strip(), "short-base64"))
            if _SHORT_HEX_RE.fullmatch(token):
                d = _try_decode_hex(token)
                if d:
                    candidates.append((d.strip(), "short-hex"))
            if _SHORT_BASE32_RE.fullmatch(token):
                d = _try_decode_base32(token)
                if d:
                    candidates.append((d.strip(), "short-base32"))

            for candidate, encoding in candidates:
                canonical = canonicalise(candidate)
                h = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
                pair = (line_key, h)
                if h in known:
                    # Credit every originating path even when the pair was
                    # already counted — multi-file collisions otherwise drop
                    # later offenders. Synthetic sentinel keys (serialised
                    # config) never surface to admins.
                    if not is_sentinel_path(origin):
                        affected.add(origin)
                    if pair not in matched_pairs:
                        matched_pairs.add(pair)
                        evidence.append(
                            f"Short {encoding} decoded to answer: "
                            f"{token[:max_evidence_line_len]} → {candidate[:max_evidence_line_len]}"
                        )

                inner = _try_decode_base64(candidate)
                if inner:
                    inner_canonical = canonicalise(inner.strip())
                    h2 = hashlib.sha256(inner_canonical.encode("utf-8")).hexdigest()
                    inner_pair = (line_key, h2)
                    if h2 in known:
                        if not is_sentinel_path(origin):
                            affected.add(origin)
                        if inner_pair not in matched_pairs:
                            matched_pairs.add(inner_pair)
                            evidence.append(
                                f"Double {encoding} decoded to answer: "
                                f"{token[:max_evidence_line_len]} → {inner[:max_evidence_line_len]}"
                            )

    return matched_pairs, evidence, affected


# Precomputed str.translate tables for all 25 non-identity Caesar shifts (C-speed)
_CAESAR_TABLES: list[tuple[dict[int, int], int]] = []
for _shift in range(1, 26):
    _table: dict[int, int] = {}
    for _i in range(26):
        _table[ord("A") + _i] = ord("A") + (_i + _shift) % 26
        _table[ord("a") + _i] = ord("a") + (_i + _shift) % 26
    _CAESAR_TABLES.append((_table, _shift))


def check_substitution_ciphers(
    contents: dict[str, str],
    answer_hashes: frozenset[str] | list[str],
    min_exact_matches: int,
    *,
    skeleton_enabled: bool = True,
    max_evidence_line_len: int = 240,
) -> CheckResult:
    """Detect answers hidden via ROT13, Caesar (all 25 shifts), or string reversal.

    ``contents`` maps file path → body; matches record the originating
    path in ``affected_paths`` (capped at 10).
    """
    known = answer_hashes if isinstance(answer_hashes, frozenset) else set(answer_hashes)
    matched_pairs: set[tuple[str, str]] = set()
    evidence: list[str] = []
    affected: set[str] = set()

    for path, piece in contents.items():
        for line in piece.splitlines():
            stripped = line.strip()
            if not stripped:
                continue
            line_key = _line_key(stripped)
            for fragment in set(_extract_fragments(stripped)):
                fragment = fragment.strip()
                if not fragment or len(fragment) > 500:
                    continue

                candidates: list[tuple[str, str]] = []
                for table, shift in _CAESAR_TABLES:
                    candidates.append((fragment.translate(table), f"Caesar-{shift}"))
                candidates.append((fragment[::-1], "reversed"))

                for transformed, method in candidates:
                    canonical = canonicalise(transformed, skeleton_enabled=skeleton_enabled)
                    h = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
                    pair = (line_key, h)
                    if h in known:
                        # See note in check_answer_matches: credit every
                        # path, even when the pair was already counted.
                        # Synthetic sentinel keys never surface.
                        if not is_sentinel_path(path):
                            affected.add(path)
                        if pair not in matched_pairs:
                            matched_pairs.add(pair)
                            evidence.append(
                                f"{method} match: {fragment[:max_evidence_line_len]} "
                                f"→ {transformed[:max_evidence_line_len]}"
                            )

    affected_paths = sorted(affected)[:MAX_AFFECTED_PATHS]
    count = len(matched_pairs)
    if count >= min_exact_matches:
        return CheckResult(
            check_name=CHECK_NAME_SUBSTITUTION, confidence=0.95, evidence=evidence, affected_paths=affected_paths
        )
    if count > 0:
        return CheckResult(
            check_name=CHECK_NAME_SUBSTITUTION, confidence=0.3, evidence=evidence, affected_paths=affected_paths
        )
    return CheckResult(check_name=CHECK_NAME_SUBSTITUTION, confidence=0.0)


def _decode_pass(piece: str) -> list[str]:
    """Run every decoder against ``piece`` and return all decoded
    intermediates. Each match contributes one decoded string per decoder
    that successfully recognises it; duplicates are filtered upstream.
    """
    decoded: list[str] = []

    for match in _BASE64_RE.finditer(piece):
        d = _try_decode_base64(match.group())
        if d:
            decoded.append(d)
    for match in _HEX_RE.finditer(piece):
        d = _try_decode_hex(match.group())
        if d:
            decoded.append(d)
    for match in _URL_ENCODED_RE.finditer(piece):
        d = _try_decode_url(match.group())
        if d:
            decoded.append(d)
    for match in _ASCII85_RE.finditer(piece):
        d = _try_decode_ascii85(match.group())
        if d:
            decoded.append(d)
    for match in _BASE85_RE.finditer(piece):
        d = _try_decode_base85(match.group())
        if d:
            decoded.append(d)
    for match in _UUENCODE_BLOCK_RE.finditer(piece):
        d = _try_decode_uuencode(match.group(1))
        if d:
            decoded.append(d)

    # Magic-byte sniffing on the raw bytes of the entire piece. Cheaper than
    # regex for binary-prefixed payloads embedded as latin-1 / utf-8 strings.
    raw = piece.encode("latin-1", errors="ignore")
    decompressed = _try_decompress(raw)
    if decompressed:
        decoded.append(decompressed)

    return decoded


def check_encoded_content(
    contents: dict[str, str],
    answer_hashes: frozenset[str] | list[str],
    min_exact_matches: int,
    *,
    encoding_max_depth: int = 4,
    max_decoded_total_bytes: int = 20 * 1024 * 1024,
    skeleton_enabled: bool = True,
    max_evidence_line_len: int = 240,
) -> CheckResult:
    """Detect encoded blobs, decode iteratively, re-run answer matching.

    ``contents`` maps file path → body. Origin path is propagated through
    decode layers so a match at depth N is attributed to the original
    tarball file that started the chain.

    Iterates up to ``encoding_max_depth`` layers of nested encoding,
    accumulating decoded intermediates with hash-based deduplication.
    Stops early when the total decoded byte count exceeds
    ``max_decoded_total_bytes`` (emits ``decode_cap_reached`` flag).

    Returns 0.95 confidence on enough answer-hash matches across any
    depth, 0.2 when blobs were found but no match, 0.0 when nothing
    decodable was seen.
    """
    answer_hash_set = answer_hashes if isinstance(answer_hashes, frozenset) else frozenset(answer_hashes)
    evidence: list[str] = []
    # Per-origin dedup: a decoded blob seen from a different origin still
    # produces a new (origin, hash) entry so multi-file collisions don't
    # silently drop the second file's origin from ``affected_paths``.
    decoded_seen: set[tuple[str, int]] = {(origin, hash(piece)) for origin, piece in contents.items()}
    short_scan_seen: set[tuple[str, int]] = set()
    # Carry origin path through decode layers: each entry is (origin_path,
    # content). The depth-0 working set is the input contents; subsequent
    # depths preserve the original path from the parent intermediate.
    working_set: list[tuple[str, str]] = list(contents.items())
    all_decoded: list[tuple[str, str]] = []
    short_matched_pairs: set[tuple[str, str]] = set()
    short_evidence: list[str] = []
    affected: set[str] = set()
    total_decoded_bytes = 0
    cap_reached = False
    next_layer: list[tuple[str, str]] = []

    for depth in range(encoding_max_depth):
        next_layer = []
        for origin, piece in working_set:
            for decoded in _decode_pass(piece):
                key = (origin, hash(decoded))
                if key in decoded_seen:
                    continue
                decoded_seen.add(key)
                decoded_bytes = len(decoded.encode("utf-8"))
                if total_decoded_bytes + decoded_bytes > max_decoded_total_bytes:
                    cap_reached = True
                    evidence.append(f"Hit decode-byte cap ({max_decoded_total_bytes}) at depth {depth}")
                    break
                total_decoded_bytes += decoded_bytes
                next_layer.append((origin, decoded))
                all_decoded.append((origin, decoded))
                evidence.append(f"Depth {depth + 1} decoded ({decoded_bytes} bytes)")
            if cap_reached:
                break

        # Per-depth short-encoded scan: cover answers individually encoded
        # inside any layer (including the original content on depth=0).
        # `short_scan_seen` carries between depths so the same content is
        # not re-tokenised when produced by multiple decoders.
        layer_input = working_set if depth == 0 else next_layer
        layer_pairs, layer_evidence, layer_affected = _check_short_encoded_answers(
            layer_input,
            answer_hash_set,
            min_exact_matches,
            max_evidence_line_len=max_evidence_line_len,
            seen=short_scan_seen,
        )
        short_matched_pairs.update(layer_pairs)
        short_evidence.extend(layer_evidence)
        affected.update(layer_affected)
        if len(short_matched_pairs) >= min_exact_matches:
            return CheckResult(
                check_name=CHECK_NAME,
                confidence=0.95,
                evidence=evidence + short_evidence,
                affected_paths=sorted(affected)[:MAX_AFFECTED_PATHS],
            )

        if cap_reached or not next_layer:
            break
        working_set = next_layer

    if not all_decoded and not short_matched_pairs:
        if cap_reached:
            return CheckResult(
                check_name=CHECK_NAME_DECODE_CAP,
                confidence=0.2,
                evidence=evidence,
            )
        return CheckResult(check_name=CHECK_NAME, confidence=0.0)

    if all_decoded:
        # Group decoded intermediates by originating tarball path so the
        # matcher's per-call cap collapses over *origins*, not per-blob
        # synthetic keys — otherwise a prolific origin could exhaust the
        # inner cap and a late-sorting origin's single match would be
        # silently dropped from ``affected_paths`` even with cap headroom.
        per_origin: dict[str, list[str]] = {}
        for origin, piece in all_decoded:
            per_origin.setdefault(origin, []).append(piece)
        combined = {origin: "\n".join(pieces) for origin, pieces in per_origin.items()}
        inner = check_answer_matches(
            combined,
            answer_hashes,
            min_exact_matches,
            skeleton_enabled=skeleton_enabled,
            max_evidence_line_len=max_evidence_line_len,
        )
        # Propagate originals on ANY match — even sub-threshold — so the
        # advisory 0.2 result still names the offending file.
        for origin in inner.affected_paths:
            if not is_sentinel_path(origin):
                affected.add(origin)
        if inner.confidence >= 0.9:
            return CheckResult(
                check_name=CHECK_NAME,
                confidence=0.95,
                evidence=evidence + inner.evidence + short_evidence,
                affected_paths=sorted(affected)[:MAX_AFFECTED_PATHS],
            )

    return CheckResult(
        check_name=CHECK_NAME,
        confidence=0.2,
        evidence=evidence + short_evidence,
        affected_paths=sorted(affected)[:MAX_AFFECTED_PATHS],
    )
