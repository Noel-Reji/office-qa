"""SHA-256 answer hash matching check.

Hashes each line AND extracted fragments of each content piece against a set
of known answer hashes. Fragments are extracted by splitting on structural
delimiters (JSON, YAML, CSV, Python dict) so answers embedded inside
key-value pairs are detected.

Inputs are run through :func:`canonicalise` (NFKC + zero-width strip +
optional UTS#39 confusables-skeleton) so Cyrillic / Greek / NFD-decomposed
forms collapse to their Latin equivalents before hashing. Operators must
generate ``answer_hashes`` from canonicalised plaintext (see
``arena_core/scripts/build_answer_hashes.py``).

Match counting uses ``(line_hash, answer_hash)`` pairs so a leak of N
distinct lines that all match the SAME answer counts as N — closes the
"leak 100×'42'" bypass that set-based counting missed.
"""

from __future__ import annotations

import hashlib
import re

from arena_core.security.models import MAX_AFFECTED_PATHS, CheckResult, is_sentinel_path
from arena_core.security.unicode_skeleton import canonicalise

CHECK_NAME = "answer_matcher"

DEFAULT_MAX_EVIDENCE_LINE_LEN = 240

# Regex to extract values from structured content:
# - JSON/Python string values: "value" or 'value'
# - YAML/INI values: key: value or key = value
# - CSV cells between commas
_QUOTED_VALUE_RE = re.compile(r"""["']([^"']{1,500})["']""")
_KV_SEPARATOR_RE = re.compile(r"[=:]\s*")
_HTML_COMMENT_RE = re.compile(r"<!--\s*(.*?)\s*-->")
_PIPE_CELL_RE = re.compile(r"\|\s*([^|]+?)\s*(?=\|)")
_XML_TAG_VALUE_RE = re.compile(r">([^<]+)<")
_CODE_COMMENT_RE = re.compile(r"^\s*#\s*(.+)")
_C_INLINE_COMMENT_RE = re.compile(r"//\s*(.+)$")
_BLOCK_COMMENT_RE = re.compile(r"/\*\s*(.*?)\s*\*/")
_IDENTIFIER_RE = re.compile(r"[A-Za-z_]\w*")
_DIGIT_SEQUENCE_RE = re.compile(r"\d+")
_FORMATTED_NUMBER_RE = re.compile(r"\d[\d,_ ]+\d")


def _extract_fragments(line: str) -> list[str]:
    """Extract candidate answer fragments from a line.

    Returns the whole line plus any values found inside quotes,
    after key-value separators, or between commas.
    """
    fragments = [line]

    # Quoted string values: "42", 'Paris'
    for m in _QUOTED_VALUE_RE.finditer(line):
        fragments.append(m.group(1))

    # Key-value separators: "q1: 42" → "42", "A1=42" → "42"
    # Split on ALL separators to handle "Q: question? A: 42"
    kv_parts = _KV_SEPARATOR_RE.split(line)
    for part in kv_parts[1:]:  # skip the first segment (the key)
        val = part.strip().rstrip(",")
        if len(val) >= 2 and val[0] in "\"'" and val[-1] == val[0]:
            val = val[1:-1]
        if val:
            fragments.append(val)

    # CSV cells: split on commas
    if "," in line:
        for cell in line.split(","):
            cell = cell.strip().strip("\"'")
            if cell:
                fragments.append(cell)

    # HTML/XML comments: <!-- value -->
    for m in _HTML_COMMENT_RE.finditer(line):
        fragments.append(m.group(1))

    # Pipe-delimited cells: | value | value |
    if "|" in line:
        for m in _PIPE_CELL_RE.finditer(line):
            val = m.group(1).strip()
            if val and val != "---":
                fragments.append(val)

    # XML/HTML tag values: <tag>value</tag>
    for m in _XML_TAG_VALUE_RE.finditer(line):
        val = m.group(1).strip()
        if val:
            fragments.append(val)

    # Code comments: # value  or  # key = value
    comment_m = _CODE_COMMENT_RE.match(line)
    if comment_m:
        comment_body = comment_m.group(1).strip()
        fragments.append(comment_body)
        # Also split the comment body on KV separators
        comment_parts = _KV_SEPARATOR_RE.split(comment_body)
        for part in comment_parts[1:]:
            val = part.strip().rstrip(",")
            if val:
                fragments.append(val)
                # Strip inline trailing comments: "33264  # million" → "33264"
                if "#" in val:
                    before_hash = val.split("#")[0].strip()
                    if before_hash:
                        fragments.append(before_hash)

    # Tab-separated cells
    if "\t" in line:
        for cell in line.split("\t"):
            cell = cell.strip()
            if cell:
                fragments.append(cell)

    # C-style inline comments: // value
    for c_match in _C_INLINE_COMMENT_RE.finditer(line):
        val = c_match.group(1).strip()
        if val:
            fragments.append(val)
            # Also split on KV separators within the comment
            for part in _KV_SEPARATOR_RE.split(val)[1:]:
                part = part.strip().rstrip(",")
                if part:
                    fragments.append(part)

    # Block comments: /* value */
    for b_match in _BLOCK_COMMENT_RE.finditer(line):
        val = b_match.group(1).strip()
        if val:
            fragments.append(val)

    # Extract digit sequences from compound identifiers (e.g., "42" from "timeout_42_seconds")
    for ident_match in _IDENTIFIER_RE.finditer(line):
        ident = ident_match.group()
        if any(c.isdigit() for c in ident) and any(c.isalpha() for c in ident):
            for digit_match in _DIGIT_SEQUENCE_RE.finditer(ident):
                fragments.append(digit_match.group())

    # Strip number formatting (commas, underscores, spaces between digits)
    for num_match in _FORMATTED_NUMBER_RE.finditer(line):
        raw = num_match.group()
        stripped = re.sub(r"[,_ ]", "", raw)
        if stripped != raw:
            fragments.append(stripped)

    return fragments


def _line_key(line: str) -> str:
    """Short stable key per line used to deduplicate (line, answer) pairs."""
    return hashlib.sha256(line.strip().encode("utf-8")).hexdigest()[:16]


def check_answer_matches(
    contents: dict[str, str],
    answer_hashes: frozenset[str] | list[str],
    min_exact_matches: int,
    *,
    skeleton_enabled: bool = True,
    max_evidence_line_len: int = DEFAULT_MAX_EVIDENCE_LINE_LEN,
) -> CheckResult:
    """Check content for lines/fragments whose canonicalised SHA-256 hash
    matches a known answer.

    ``contents`` maps file path → body; matches record the originating
    path in ``affected_paths`` (capped at 10) for fast manual review.

    Returns high confidence (0.95) when ``>= min_exact_matches`` unique
    ``(line_hash, answer_hash)`` pairs match, low (0.3) for any match
    below the threshold, 0.0 when none.
    """
    if not answer_hashes:
        return CheckResult(check_name=CHECK_NAME, confidence=0.0)

    known = answer_hashes if isinstance(answer_hashes, frozenset) else set(answer_hashes)
    matched_pairs: set[tuple[str, str]] = set()
    evidence: list[str] = []
    affected: set[str] = set()

    for path, piece in contents.items():
        for line in piece.splitlines():
            # Load-bearing: per-line ``.strip()`` closes the trailing-whitespace
            # stego channel (cf. retired SR-G06). A regression test in
            # test_answer_matcher.py pins this behaviour — do not remove
            # without first surfacing a stego detector.
            stripped = line.strip()
            if not stripped:
                continue
            # Extract fragments from the RAW line — the canonicaliser maps
            # several structural delimiters (e.g. ``|`` → ``l``) so applying
            # it before pipe-table / CSV extraction would destroy
            # delimiters. Canonicalise each extracted fragment instead.
            line_key = _line_key(stripped)
            for fragment in _extract_fragments(stripped):
                fragment = fragment.strip()
                if not fragment:
                    continue
                canonical = canonicalise(fragment, skeleton_enabled=skeleton_enabled)
                h = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
                pair = (line_key, h)
                if h in known:
                    # Track every originating path, even when the (line_key,
                    # answer_hash) pair was already counted toward confidence
                    # — otherwise multi-file collisions silently drop later
                    # offenders from ``affected_paths``. Synthetic sentinel
                    # keys (serialised config) never surface to admins.
                    if not is_sentinel_path(path):
                        affected.add(path)
                    if pair not in matched_pairs:
                        matched_pairs.add(pair)
                        preview = fragment[:max_evidence_line_len]
                        evidence.append(f"Answer hash match: {preview}")

    affected_paths = sorted(affected)[:MAX_AFFECTED_PATHS]
    count = len(matched_pairs)
    if count >= min_exact_matches:
        return CheckResult(check_name=CHECK_NAME, confidence=0.95, evidence=evidence, affected_paths=affected_paths)
    if count > 0:
        return CheckResult(check_name=CHECK_NAME, confidence=0.3, evidence=evidence, affected_paths=affected_paths)
    return CheckResult(check_name=CHECK_NAME, confidence=0.0)
