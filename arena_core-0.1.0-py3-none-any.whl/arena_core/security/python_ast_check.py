"""AST-walk checks for Python spawn primitives and outbound network use.

* ``check_python_daemon_spawn`` — catches structurally-obvious
  daemonisation: ``subprocess.Popen(start_new_session=True)``,
  ``os.fork()``, ``os.execv*``, ``os.posix_spawn``,
  ``multiprocessing.Process(daemon=True)``, ``daemonize`` imports.
* ``check_outbound_network`` — flags HTTP-client imports / calls and
  bare URLs that suggest the agent fetches data from outside its
  sandbox.

Both are best-effort and advisory (confidence ≤ 0.2): an evasion
downgrades to "missed flag", not "wrongful reject". Obfuscated forms
(``getattr(...)``, kw-splat, ``exec``-wrapped, runtime-built strings)
are out of scope.
"""

from __future__ import annotations

import ast
import logging
import re
from pathlib import PurePosixPath
from urllib.parse import urlparse

from arena_core.security.models import MAX_AFFECTED_PATHS, CheckResult

logger = logging.getLogger(__name__)

CHECK_NAME = "python_daemon_spawn"
_KIND_CALL = "daemon-call"
_KIND_IMPORT = "daemon-import"

_DAEMON_FUNCTION_NAMES = frozenset(
    {
        "fork",
        "forkpty",
        "execv",
        "execvp",
        "execve",
        "execvpe",
        "execl",
        "execle",
        "execlp",
        "execlpe",
        "posix_spawn",
        "posix_spawnp",
    }
)
_DAEMON_MODULE_NAMES = frozenset({"daemonize", "python_daemon"})


class _SpawnVisitor(ast.NodeVisitor):
    def __init__(self, path: str, max_evidence_line_len: int = 240) -> None:
        self.path = path
        self.max_evidence_line_len = max_evidence_line_len
        self.findings: list[str] = []

    def _record(self, node: ast.AST, kind: str, detail: str) -> None:
        self.findings.append(
            f"{self.path}:{getattr(node, 'lineno', '?')} — {kind}: " f"{detail[: self.max_evidence_line_len]}"
        )

    def visit_Import(self, node: ast.Import) -> None:
        for alias in node.names:
            if alias.name.split(".")[0] in _DAEMON_MODULE_NAMES:
                self._record(node, _KIND_IMPORT, f"import {alias.name}")
        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        if node.module and node.module.split(".")[0] in _DAEMON_MODULE_NAMES:
            self._record(node, _KIND_IMPORT, f"from {node.module} import ...")
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call) -> None:
        target = self._call_target_name(node.func)
        if target is None:
            self.generic_visit(node)
            return

        # subprocess.Popen / multiprocessing.Process with daemonising kwargs.
        if target in {"subprocess.Popen", "multiprocessing.Process"}:
            for kw in node.keywords:
                if kw.arg in {"start_new_session", "daemon"} and self._is_truthy_constant(kw.value):
                    self._record(node, _KIND_CALL, f"{target}({kw.arg}=True)")

        # Bare os.<spawn>() or `from os import fork; fork()` — match by tail.
        tail = target.rsplit(".", 1)[-1]
        if tail in _DAEMON_FUNCTION_NAMES and (target.startswith("os.") or "." not in target):
            self._record(node, _KIND_CALL, f"{target}()")

        self.generic_visit(node)

    @staticmethod
    def _call_target_name(func: ast.expr) -> str | None:
        """Stringify an attribute / name chain, e.g. ``os.fork`` or
        ``subprocess.Popen``. Returns None for dynamic dispatch
        (``getattr``, subscript, etc.) — those are out of scope."""
        parts: list[str] = []
        current: ast.expr | None = func
        while isinstance(current, ast.Attribute):
            parts.append(current.attr)
            current = current.value
        if isinstance(current, ast.Name):
            parts.append(current.id)
            return ".".join(reversed(parts))
        return None

    @staticmethod
    def _is_truthy_constant(value: ast.expr) -> bool:
        return isinstance(value, ast.Constant) and bool(value.value)


def check_python_daemon_spawn(
    file_contents: dict[str, str],
    *,
    max_evidence_line_len: int = 240,
) -> CheckResult:
    """Walk the AST of every ``.py`` file and flag spawn primitives.

    Malformed Python falls back silently — ``ast.parse`` raises
    ``SyntaxError`` which we catch and skip; the regex-based
    ``check_shell_patterns`` covers that path.
    """
    evidence: list[str] = []
    affected: set[str] = set()
    for path, content in file_contents.items():
        if PurePosixPath(path).suffix.lower() != ".py":
            continue
        try:
            tree = ast.parse(content, filename=path)
        except (SyntaxError, ValueError):
            continue
        visitor = _SpawnVisitor(path, max_evidence_line_len=max_evidence_line_len)
        visitor.visit(tree)
        if visitor.findings:
            evidence.extend(visitor.findings)
            affected.add(path)

    if evidence:
        return CheckResult(
            check_name=CHECK_NAME,
            confidence=0.2,
            evidence=evidence,
            affected_paths=sorted(affected)[:MAX_AFFECTED_PATHS],
        )
    return CheckResult(check_name=CHECK_NAME, confidence=0.0)


# ---------------------------------------------------------------------------
# check_outbound_network — flag HTTP-client use and bare URLs
# ---------------------------------------------------------------------------

OUTBOUND_NETWORK_CHECK_NAME = "outbound_network"

_NETWORK_MODULES = frozenset(
    {
        "requests",
        "httpx",
        "aiohttp",
        "urllib",
        "urllib3",
        "http",
    }
)

_NETWORK_CALL_TAILS = frozenset(
    {
        "get",
        "post",
        "put",
        "patch",
        "delete",
        "head",
        "options",
        "request",
        "urlopen",
        "fetch",
    }
)

_URL_RE = re.compile(r"https?://[^\s'\"`<>)]{4,}", re.IGNORECASE)

# Hosts (or host suffixes) that are noise rather than exfil. Conservative
# allowlist: dependency mirrors, model hubs, the LLM vendors we expect
# agents to call. Domains compared as suffixes so subdomains are accepted.
_BENIGN_HOST_SUFFIXES = (
    "pypi.org",
    "pythonhosted.org",
    "github.com",
    "githubusercontent.com",
    "huggingface.co",
    "openai.com",
    "anthropic.com",
    "googleapis.com",
    "google.com",
    "azure.com",
    "amazonaws.com",
    "readthedocs.io",
    "readthedocs.org",
    "wikipedia.org",
    "wikimedia.org",
    "example.com",
    "example.org",
    "localhost",
    "127.0.0.1",
    "0.0.0.0",
)


def _is_benign_host(url: str) -> bool:
    """Allow a URL if the *real* host (after userinfo/port) matches the
    benign suffix list. Uses ``urlparse`` so userinfo-bypass tricks like
    ``https://openai.com:443@attacker.example/`` resolve to the attacker
    host (rejected) instead of the visible label (accepted).
    """
    try:
        parsed = urlparse(url)
    except ValueError:
        return False
    host = (parsed.hostname or "").rstrip(".").lower()
    if not host:
        return False
    return any(host == s or host.endswith("." + s) for s in _BENIGN_HOST_SUFFIXES)


class _NetworkVisitor(ast.NodeVisitor):
    def __init__(self, path: str, max_evidence_line_len: int = 240) -> None:
        self.path = path
        self.max_evidence_line_len = max_evidence_line_len
        self.findings: list[str] = []

    def _record(self, node: ast.AST, kind: str, detail: str) -> None:
        line = f"{self.path}:{getattr(node, 'lineno', '?')} — {kind}: {detail}"
        self.findings.append(line[: self.max_evidence_line_len])

    def visit_Import(self, node: ast.Import) -> None:
        for alias in node.names:
            root = alias.name.split(".")[0]
            if root in _NETWORK_MODULES:
                self._record(node, "network-import", f"import {alias.name}")
        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        if node.module and node.module.split(".")[0] in _NETWORK_MODULES:
            self._record(node, "network-import", f"from {node.module} import ...")
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call) -> None:
        target = _SpawnVisitor._call_target_name(node.func)
        if target is not None:
            tail = target.rsplit(".", 1)[-1]
            head = target.split(".", 1)[0]
            if tail in _NETWORK_CALL_TAILS and head in _NETWORK_MODULES:
                self._record(node, "network-call", f"{target}(...)")
        self.generic_visit(node)


def check_outbound_network(
    file_contents: dict[str, str],
    *,
    max_evidence_line_len: int = 240,
) -> CheckResult:
    """Advisory: surface HTTP-client imports/calls and bare URLs.

    Confidence 0.2 — same advisory tier as daemon_spawn. Submissions that
    legitimately depend on PyPI / GitHub / model hubs do not trip because
    their URLs are filtered through ``_BENIGN_HOST_SUFFIXES``; only
    untrusted hosts surface as evidence.
    """
    evidence: list[str] = []
    affected: set[str] = set()

    for path, content in file_contents.items():
        # URL scan (all scannable file types)
        for match in _URL_RE.finditer(content):
            url = match.group(0)
            if _is_benign_host(url):
                continue
            # Trim trailing punctuation an agent comment might have appended.
            url = url.rstrip(".,;:")
            evidence.append(f"{path} — bare-url: {url[:max_evidence_line_len]}")
            affected.add(path)

        # AST scan (only .py)
        if PurePosixPath(path).suffix.lower() != ".py":
            continue
        try:
            tree = ast.parse(content, filename=path)
        except (SyntaxError, ValueError):
            continue
        visitor = _NetworkVisitor(path, max_evidence_line_len=max_evidence_line_len)
        visitor.visit(tree)
        if visitor.findings:
            evidence.extend(visitor.findings)
            affected.add(path)

    if evidence:
        return CheckResult(
            check_name=OUTBOUND_NETWORK_CHECK_NAME,
            confidence=0.2,
            evidence=evidence,
            affected_paths=sorted(affected)[:MAX_AFFECTED_PATHS],
        )
    return CheckResult(check_name=OUTBOUND_NETWORK_CHECK_NAME, confidence=0.0)
