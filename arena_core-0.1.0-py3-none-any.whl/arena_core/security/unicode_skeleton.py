"""Unicode canonicalisation for security review answer hashing.

Applies NFKC normalisation, strips zero-width characters, and (optionally)
maps each character through the UTS #39 confusables-skeleton table so
homoglyphs (e.g. Cyrillic 'а' vs Latin 'a', Greek 'ο' vs Latin 'o') hash
to the same value as their Latin lookalikes.

The confusables data file ships in the sibling workspace package
``arena_core_data`` (Unicode Security Mechanisms, regenerated via
``scripts/vendor_confusables.py``). When the file is missing — e.g. in a
broken install or CI without packaging — the skeleton step degrades to
identity and a warning is logged once.

``NORMALISER_VERSION`` bumps on any algorithm change so stored
``answer_hashes`` generated with a prior version surface as a
``normaliser_version_mismatch`` advisory in the L1 review pipeline.
"""

from __future__ import annotations

import logging
import unicodedata
from importlib.resources import files

logger = logging.getLogger(__name__)

NORMALISER_VERSION = 2

# Common zero-width / format characters used to obfuscate text. NFKC does
# not strip these, so we translate them out before skeleton lookup.
_ZERO_WIDTH: dict[int, str | None] = {
    0x200B: None,  # ZERO WIDTH SPACE
    0x200C: None,  # ZERO WIDTH NON-JOINER
    0x200D: None,  # ZERO WIDTH JOINER
    0x2060: None,  # WORD JOINER
    0xFEFF: None,  # ZERO WIDTH NO-BREAK SPACE / BOM
    0x180E: None,  # MONGOLIAN VOWEL SEPARATOR
}


def _load_skeleton_table() -> dict[int, str]:
    """Parse the vendored UTS #39 confusables.txt into a code-point → string
    map suitable for ``str.translate``. Lines look like:

        0041 ;  0061 ;  MA  # ( A → a ) LATIN CAPITAL LETTER A → ...

    The first column is the source code point; the second is one or more
    space-separated target code points (the skeleton form).
    """
    try:
        data_file = files("arena_core_data") / "confusables.txt"
        text = data_file.read_text(encoding="utf-8")
    except (FileNotFoundError, ModuleNotFoundError, OSError) as exc:
        logger.warning("confusables.txt missing — skeleton mapping disabled (%s)", exc)
        return {}

    table: dict[int, str] = {}
    for raw in text.splitlines():
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        parts = [p.strip() for p in line.split(";")]
        if len(parts) < 2:
            continue
        try:
            src = int(parts[0], 16)
            target = "".join(chr(int(cp, 16)) for cp in parts[1].split())
        except ValueError:
            continue
        table[src] = target
    return table


_SKELETON_TABLE: dict[int, str] = _load_skeleton_table()


def _skeleton(text: str) -> str:
    """Apply the confusables-skeleton mapping per character."""
    if not _SKELETON_TABLE:
        return text
    return text.translate(_SKELETON_TABLE)


def canonicalise(
    text: str,
    *,
    skeleton_enabled: bool = True,
    max_iterations: int = 3,
) -> str:
    """Return the canonical form of *text* for security-review hashing.

    Pipeline: NFKC → zero-width strip → (optional) UTS #39 skeleton.

    Iterates to a fixed point (or up to ``max_iterations``) so a single
    pass that introduces a code point requiring further normalisation
    still converges. ``max_iterations`` bounds the worst case under
    pathological input; 3 is sufficient for all real-world cases.

    Set ``skeleton_enabled=False`` for non-Latin-script competitions where
    the skeleton step over-collapses script-native content.
    """
    previous = ""
    for _ in range(max_iterations):
        text = unicodedata.normalize("NFKC", text)
        text = text.translate(_ZERO_WIDTH)
        if skeleton_enabled:
            text = _skeleton(text)
        if text == previous:
            return text
        previous = text
    return text
