"""StaticSecurityReview: Layer 1 pipeline orchestrator.

Runs all static checks sequentially with short-circuit on high confidence.
Pure Python, synchronous, no network I/O.
"""

from __future__ import annotations

import json
import logging
import os
import tarfile
from typing import Any, Literal, cast

from arena_core.security.answer_matcher import check_answer_matches
from arena_core.security.encoded_content import check_encoded_content, check_substitution_ciphers
from arena_core.security.flag_checks import (
    check_normalized_matches,
    check_number_words,
    check_prompt_size,
    check_shell_patterns,
    check_suspicious_content,
)
from arena_core.security.models import (
    MAX_AFFECTED_PATHS,
    SENTINEL_AGENT_CONFIG_PATH,
    SENTINEL_CONFIG_PATH,
    CheckResult,
    L1RunnerOutput,
    ReviewDecision,
    SecurityReviewConfig,
)
from arena_core.security.models import SkippedFile as SkippedFileModel
from arena_core.security.python_ast_check import (
    check_outbound_network,
    check_python_daemon_spawn,
)
from arena_core.security.tarball import (
    SkippedFile,
    TarScanResult,
    apply_l2_truncation,
    extract_text_content,
    safe_normalize_path,
)
from arena_core.security.unicode_skeleton import NORMALISER_VERSION

logger = logging.getLogger(__name__)

HIGH_CONFIDENCE_THRESHOLD = 0.9

CHECK_NAME_DECOMPRESSION_BOMB = "decompression_bomb"
CHECK_NAME_BINARY_POLICY = "binary_policy_violation"
CHECK_NAME_SCAN_INCOMPLETE = "scan_incomplete"
CHECK_NAME_LOW_COVERAGE = "low_scan_coverage"
CHECK_NAME_NORMALISER_VERSION_MISMATCH = "normaliser_version_mismatch"
CHECK_NAME_FORBIDDEN_FILENAME = "forbidden_filename_present"

_MAX_EVIDENCE_PATHS = 10
_MAX_BINARY_EVIDENCE_PATHS = 5


class StaticSecurityReview:
    """Layer 1 static security review pipeline.

    Pure Python, synchronous, no network I/O.
    Runs checks sequentially with short-circuit on high confidence.
    """

    def __init__(self, config: SecurityReviewConfig) -> None:
        self._config = config
        # Cache frozensets — config is immutable for the reviewer's lifetime,
        # so build them once instead of on every review() call.
        self._hard_reject_set = frozenset(config.hard_reject_extensions)
        self._allowed_binary_set = frozenset(config.allowed_binary_extensions)
        self._answer_hash_set = frozenset(config.answer_hashes)
        self._normalized_answer_hash_set = frozenset(config.normalized_answer_hashes)
        self._forbidden_filename_set = frozenset(config.forbidden_filenames)

    def _check_forbidden_filenames(self, scan: TarScanResult) -> CheckResult | None:
        """Hard-reject when a submission ships a filename on the per-
        competition denylist (typically the answer-bearing dataset CSV).

        Match is case-sensitive on the path basename — partial matches like
        ``my_officeqa_full.csv.bak`` do not trigger. Returns ``None`` when
        no match (caller continues with normal detector chain).
        """
        if not self._forbidden_filename_set:
            return None
        hits: list[str] = []
        for path in scan.contents:
            base = os.path.basename(path)
            if base in self._forbidden_filename_set:
                hits.append(path)
        for sk in scan.skipped:
            base = os.path.basename(sk.path)
            if base in self._forbidden_filename_set:
                hits.append(sk.path)
        if not hits:
            return None
        # Cap evidence to the same horizon as binary-policy violations so
        # a tarball with many copies doesn't blow up the JSONB row.
        capped = hits[:_MAX_BINARY_EVIDENCE_PATHS]
        return CheckResult(
            check_name=CHECK_NAME_FORBIDDEN_FILENAME,
            confidence=1.0,
            evidence=capped,
            affected_paths=capped[:MAX_AFFECTED_PATHS],
        )

    def review(
        self,
        *,
        agent_config: dict[str, Any],
        config: dict[str, Any],
        tarball_body: bytes | None = None,
        pre_built_scan: TarScanResult | None = None,
    ) -> ReviewDecision:
        """Run all checks and return a decision.

        Exactly one of ``tarball_body`` or ``pre_built_scan`` must be supplied.

        ``tarball_body`` (legacy): the gzipped tarball bytes; this method
        extracts text content via :func:`extract_text_content`. Tarball-layer
        errors (decompression bomb, corrupt archive) short-circuit to
        ``decision="reject"`` with deterministic evidence.

        ``pre_built_scan`` (new): an already-built ``TarScanResult`` from the
        S3-extracted-files scanner. Skips the tarfile parse entirely — the
        Lambda has already untarred the submission, and tarball-layer
        rejections are caught upstream as ``status="rejected"`` manifests
        (the L1 worker short-circuits on those and never calls this method).

        Returns "reject" on high confidence, "flag" on low confidence,
        or "clean" if nothing suspicious is found.

        Hard-reject binary policies short-circuit to ``decision="reject"``
        with deterministic evidence — they do not raise into the runner
        subprocess.
        """
        if (tarball_body is None) == (pre_built_scan is None):
            raise ValueError("review() requires exactly one of tarball_body or pre_built_scan")

        if not self._config.enabled:
            return ReviewDecision(decision="clean")

        if pre_built_scan is not None:
            scan = pre_built_scan
        else:
            # The XOR validation above guarantees tarball_body is set when
            # pre_built_scan is None; the assert narrows the type for mypy.
            assert tarball_body is not None
            # Extract tarball text content. TarError → deterministic reject so
            # the runner doesn't see a raw exception (which would map to
            # decision="timeout" via the worker's failure path).
            try:
                scan = extract_text_content(
                    tarball_body,
                    max_file_size=self._config.max_scannable_file_bytes,
                    max_total_bytes=self._config.max_total_scanned_bytes,
                    hard_reject_extensions=self._hard_reject_set,
                    allowed_binary_extensions=self._allowed_binary_set,
                )
            except tarfile.TarError as exc:
                logger.warning("L1 tarball error → deterministic reject: %s", exc)
                return ReviewDecision(
                    decision="reject",
                    check_results=[
                        CheckResult(
                            check_name=CHECK_NAME_DECOMPRESSION_BOMB,
                            confidence=0.95,
                            evidence=[str(exc)[: self._config.max_evidence_line_len]],
                        )
                    ],
                )

        results: list[CheckResult] = []

        # --- D5 hard-reject binary policy (short-circuit when configured) -
        hard_rejected = [s for s in scan.skipped if s.reason == "hard_reject_binary"]
        if hard_rejected and self._config.binary_extension_action == "reject":
            return ReviewDecision(
                decision="reject",
                check_results=[
                    CheckResult(
                        check_name=CHECK_NAME_BINARY_POLICY,
                        confidence=0.95,
                        evidence=_format_skipped_evidence(hard_rejected, _MAX_BINARY_EVIDENCE_PATHS),
                        affected_paths=[s.path for s in hard_rejected[:MAX_AFFECTED_PATHS]],
                    )
                ],
            )
        if hard_rejected:
            results.append(
                CheckResult(
                    check_name=CHECK_NAME_BINARY_POLICY,
                    confidence=0.85,
                    evidence=_format_skipped_evidence(hard_rejected, _MAX_BINARY_EVIDENCE_PATHS),
                    affected_paths=[s.path for s in hard_rejected[:MAX_AFFECTED_PATHS]],
                )
            )

        # Forbidden-filename short-circuit: per-competition list of dataset
        # names that must never ship in a submission (e.g. the answer-bearing
        # adapter CSV). Production replay against grounded-reasoning showed
        # 47% of flagged submissions ship the official dataset under its
        # canonical name; rejecting at L1 saves the L2 LLM tokens.
        forbidden = self._check_forbidden_filenames(scan)
        if forbidden is not None:
            return ReviewDecision(decision="reject", check_results=[forbidden])

        agent_config_json = json.dumps(agent_config)
        config_json = json.dumps(config)

        # L1-A5 content split: shell/suspicious/number checks scan tarball
        # file bodies only (no JSON-serialized config), eliminating the
        # `description: "screen-based UI"` class of false positives.
        # Answer/encoded/substitution/normalized checks see all content.
        # PR2's filename-aware checks (Python AST walker) read scan.contents
        # directly.
        #
        # Keys are file paths so each check populates ``CheckResult.affected_paths``
        # for fast manual review (#532). Synthetic keys ``<agent_config>`` and
        # ``<config>`` mark the serialised dicts in ``all_content`` so the
        # admin UI can distinguish "match in submitted code" from "match in
        # config metadata".
        exec_content: dict[str, str] = dict(scan.contents)
        # NUL-prefixed sentinels mark the JSON-serialised dicts so they
        # can never collide with a real tarball path (NUL is forbidden in
        # POSIX paths and would have failed earlier tarfile parsing).
        all_content: dict[str, str] = {
            SENTINEL_AGENT_CONFIG_PATH: agent_config_json,
            SENTINEL_CONFIG_PATH: config_json,
            **scan.contents,
        }

        config_bytes = len(agent_config_json.encode("utf-8")) + len(config_json.encode("utf-8"))

        # D2 normaliser-version drift: stored hashes generated with a
        # different normaliser version surface here as an advisory
        # (confidence 0.0 — never a flag). Worker reads this back to fire
        # a Slack alert on first occurrence.
        if self._config.normaliser_version != NORMALISER_VERSION:
            results.append(
                CheckResult(
                    check_name=CHECK_NAME_NORMALISER_VERSION_MISMATCH,
                    confidence=0.0,
                    evidence=[f"config v{self._config.normaliser_version} vs runtime v{NORMALISER_VERSION}"],
                )
            )

        skeleton_enabled = self._config.confusables_skeleton_enabled
        max_evidence_line_len = self._config.max_evidence_line_len
        min_exact_matches = self._config.min_exact_matches

        # High-confidence checks (can short-circuit to reject)
        if self._config.answer_hashes:
            r = check_answer_matches(
                all_content,
                self._answer_hash_set,
                min_exact_matches,
                skeleton_enabled=skeleton_enabled,
                max_evidence_line_len=max_evidence_line_len,
            )
            results.append(r)
            if r.confidence >= HIGH_CONFIDENCE_THRESHOLD:
                return ReviewDecision(decision="reject", check_results=results)

            r = check_encoded_content(
                all_content,
                self._answer_hash_set,
                min_exact_matches,
                encoding_max_depth=self._config.encoding_max_depth,
                max_decoded_total_bytes=self._config.max_decoded_total_bytes,
                skeleton_enabled=skeleton_enabled,
                max_evidence_line_len=max_evidence_line_len,
            )
            results.append(r)
            if r.confidence >= HIGH_CONFIDENCE_THRESHOLD:
                return ReviewDecision(decision="reject", check_results=results)

            r = check_substitution_ciphers(
                all_content,
                self._answer_hash_set,
                min_exact_matches,
                skeleton_enabled=skeleton_enabled,
                max_evidence_line_len=max_evidence_line_len,
            )
            results.append(r)
            if r.confidence >= HIGH_CONFIDENCE_THRESHOLD:
                return ReviewDecision(decision="reject", check_results=results)

        # Normalized matching (can reject when >= min_exact_matches after case/punct normalization)
        if self._config.normalized_answer_hashes:
            r = check_normalized_matches(
                all_content,
                self._normalized_answer_hash_set,
                min_exact_matches,
                skeleton_enabled=skeleton_enabled,
                max_evidence_line_len=max_evidence_line_len,
            )
            results.append(r)
            if r.confidence >= HIGH_CONFIDENCE_THRESHOLD:
                return ReviewDecision(decision="reject", check_results=results)

        # Low-confidence checks (always run when enabled)
        results.append(check_prompt_size(config_bytes, self._config.max_prompt_bytes))
        results.append(
            check_shell_patterns(
                exec_content,
                self._config.shell_patterns,
                contextual_patterns=self._config.shell_contextual_patterns,
            )
        )
        results.append(check_suspicious_content(exec_content))
        results.append(check_number_words(exec_content))
        # D6 AST walk for Python spawn primitives — needs filename-aware
        # access (skill files only) so receives the dict directly.
        results.append(check_python_daemon_spawn(scan.contents, max_evidence_line_len=max_evidence_line_len))
        results.append(check_outbound_network(scan.contents, max_evidence_line_len=max_evidence_line_len))

        # --- L1-A3 / L1-A4 surface incomplete scans -------------------------
        incomplete = _scan_incomplete_result(scan, self._config.min_skipped_files_for_flag)
        if incomplete is not None:
            results.append(incomplete)
        coverage = _coverage_result(scan, self._config.min_scan_coverage_ratio)
        if coverage is not None:
            results.append(coverage)

        has_flags = any(r.confidence > 0.0 for r in results)
        decision = "flag" if has_flags else "clean"
        return ReviewDecision(decision=decision, check_results=results)

    def review_runner(
        self,
        *,
        agent_config: dict[str, Any],
        config: dict[str, Any],
        tarball_body: bytes | None = None,
        pre_built_scan: TarScanResult | None = None,
    ) -> L1RunnerOutput:
        """Layer-1 entry point used by the runner subprocess.

        Returns ``L1RunnerOutput`` (decision + L2 staging digest). When
        ``config.enabled is False`` no scan runs and the digest is empty —
        the cheap "security review off" path stays cheap.

        Exactly one of ``tarball_body`` (legacy in-process untar) or
        ``pre_built_scan`` (Lambda-extracted path) must be supplied. With a
        pre-built scan the tarball is never parsed in this process, so
        tar-layer bombs cannot reach Layer-1 code.

        Otherwise the tarball is scanned exactly once and feeds both the
        verdict (``review``) and the digest (truncated + NFC-normalized).
        """
        if not self._config.enabled:
            return L1RunnerOutput(
                decision=ReviewDecision(decision="clean"),
                scanned_files={},
                skipped_files=[],
                partial_scan=False,
            )

        if pre_built_scan is not None and tarball_body is not None:
            raise ValueError("review_runner: pass exactly one of tarball_body or pre_built_scan, not both")

        if pre_built_scan is not None:
            scan = pre_built_scan
        elif tarball_body is not None:
            # Single scan; pass the result into both the verdict path and the
            # digest builder so we walk the tarball exactly once.
            try:
                scan = extract_text_content(
                    tarball_body,
                    max_file_size=self._config.max_scannable_file_bytes,
                    max_total_bytes=self._config.max_total_scanned_bytes,
                    hard_reject_extensions=self._hard_reject_set,
                    allowed_binary_extensions=self._allowed_binary_set,
                )
            except tarfile.TarError as exc:
                # Mirror review()'s deterministic-reject behaviour while still
                # signalling partial_scan=True so the L2 degraded-mode matrix
                # in PR 2 can react.
                logger.warning(
                    "L1 tarball error in review_runner → reject + partial_scan: %s",
                    exc,
                )
                return L1RunnerOutput(
                    decision=ReviewDecision(
                        decision="reject",
                        check_results=[
                            CheckResult(
                                check_name=CHECK_NAME_DECOMPRESSION_BOMB,
                                confidence=0.95,
                                evidence=[str(exc)[: self._config.max_evidence_line_len]],
                            )
                        ],
                    ),
                    scanned_files={},
                    skipped_files=[],
                    partial_scan=True,
                )
        else:
            raise ValueError("review_runner: pass exactly one of tarball_body or pre_built_scan")

        decision = self._decision_from_scan(
            agent_config=agent_config,
            config=config,
            scan=scan,
        )
        digest, skipped_models = self._digest_from_scan(scan)
        return L1RunnerOutput(
            decision=decision,
            scanned_files=digest,
            skipped_files=skipped_models,
            partial_scan=False,
        )

    def _digest_from_scan(
        self,
        scan: TarScanResult,
    ) -> tuple[dict[str, str], list[SkippedFileModel]]:
        """Translate an already-completed scan into the L2 digest.

        When a tarball entry's path contains control bytes the path is not
        safe to JSON-encode as a digest key. Such entries are dropped from
        ``digest`` and re-emitted in ``skipped_files`` with a sanitized
        placeholder path, preserving:

          - **size** (best-effort: the body length for an extracted entry; 0
            for an L1-skipped entry where size travels on the SkippedFile
            already).
          - **reason** when the source was already an L1-skipped entry —
            ``hard_reject_extension`` and ``oversized_file`` etc. survive
            so downstream auditing keeps the high-signal label.
          - For control-byte paths discovered on *extracted* contents (i.e.
            path looked benign during scan but has control bytes when keyed
            into the digest), the synthetic reason is ``binary_decode_failed``
            because we have no other categorical label.
        """
        digest: dict[str, str] = {}
        unsafe_extracted_paths: list[str] = []
        for path, text in scan.contents.items():
            norm = safe_normalize_path(path)
            if norm is None:
                unsafe_extracted_paths.append(path)
                continue
            digest[norm] = apply_l2_truncation(
                text,
                max_bytes=self._config.l2_per_file_truncate_bytes,
                strategy=self._config.l2_truncation_strategy,
            )

        skipped_models: list[SkippedFileModel] = []
        unsafe_idx = 0
        for s in scan.skipped:
            mapped_reason = _map_skipped_reason(s.reason)
            if mapped_reason is None:
                continue  # non_regular_member etc. — not L2-relevant
            norm = safe_normalize_path(s.path)
            if norm is None:
                # Sanitize the path but keep the original mapped reason so
                # signals like hard_reject_extension / max_scannable_file_bytes
                # don't get collapsed into binary_decode_failed.
                skipped_models.append(
                    SkippedFileModel(
                        path=f"<unsafe-path-{unsafe_idx}>",
                        size_bytes=s.size,
                        reason=cast(_L2SkippedReason, mapped_reason),
                    )
                )
                unsafe_idx += 1
                continue
            skipped_models.append(
                SkippedFileModel(
                    path=norm,
                    size_bytes=s.size,
                    reason=cast(_L2SkippedReason, mapped_reason),
                )
            )
        # Extracted entries with control-byte paths surface here as
        # binary_decode_failed since we have no L1 skip label to preserve.
        for path in unsafe_extracted_paths:
            skipped_models.append(
                SkippedFileModel(
                    path=f"<unsafe-path-{unsafe_idx}>",
                    size_bytes=len(scan.contents.get(path, "").encode("utf-8")),
                    reason="binary_decode_failed",
                )
            )
            unsafe_idx += 1
        return digest, skipped_models

    def _decision_from_scan(
        self,
        *,
        agent_config: dict[str, Any],
        config: dict[str, Any],
        scan: TarScanResult,
    ) -> ReviewDecision:
        """Run the detector chain against an already-completed scan.

        Same logic as ``review`` but skips the tarball walk — caller
        provides ``scan``. Used by ``review_runner`` to avoid scanning
        twice (once for the digest, once for the verdict).
        """
        results: list[CheckResult] = []

        hard_rejected = [s for s in scan.skipped if s.reason == "hard_reject_binary"]
        if hard_rejected and self._config.binary_extension_action == "reject":
            return ReviewDecision(
                decision="reject",
                check_results=[
                    CheckResult(
                        check_name=CHECK_NAME_BINARY_POLICY,
                        confidence=0.95,
                        evidence=_format_skipped_evidence(
                            hard_rejected,
                            _MAX_BINARY_EVIDENCE_PATHS,
                        ),
                        affected_paths=[s.path for s in hard_rejected[:MAX_AFFECTED_PATHS]],
                    )
                ],
            )
        if hard_rejected:
            results.append(
                CheckResult(
                    check_name=CHECK_NAME_BINARY_POLICY,
                    confidence=0.85,
                    evidence=_format_skipped_evidence(
                        hard_rejected,
                        _MAX_BINARY_EVIDENCE_PATHS,
                    ),
                    affected_paths=[s.path for s in hard_rejected[:MAX_AFFECTED_PATHS]],
                )
            )

        forbidden = self._check_forbidden_filenames(scan)
        if forbidden is not None:
            return ReviewDecision(decision="reject", check_results=[forbidden])

        agent_config_json = json.dumps(agent_config)
        config_json = json.dumps(config)
        exec_content: dict[str, str] = dict(scan.contents)
        # NUL-prefixed sentinels mark the JSON-serialised dicts so they
        # can never collide with a real tarball path (NUL is forbidden in
        # POSIX paths and would have failed earlier tarfile parsing).
        all_content: dict[str, str] = {
            SENTINEL_AGENT_CONFIG_PATH: agent_config_json,
            SENTINEL_CONFIG_PATH: config_json,
            **scan.contents,
        }
        config_bytes = len(agent_config_json.encode("utf-8")) + len(config_json.encode("utf-8"))

        if self._config.normaliser_version != NORMALISER_VERSION:
            results.append(
                CheckResult(
                    check_name=CHECK_NAME_NORMALISER_VERSION_MISMATCH,
                    confidence=0.0,
                    evidence=[f"config v{self._config.normaliser_version} " f"vs runtime v{NORMALISER_VERSION}"],
                )
            )

        skeleton_enabled = self._config.confusables_skeleton_enabled
        max_evidence_line_len = self._config.max_evidence_line_len
        min_exact_matches = self._config.min_exact_matches

        if self._config.answer_hashes:
            r = check_answer_matches(
                all_content,
                self._answer_hash_set,
                min_exact_matches,
                skeleton_enabled=skeleton_enabled,
                max_evidence_line_len=max_evidence_line_len,
            )
            results.append(r)
            if r.confidence >= HIGH_CONFIDENCE_THRESHOLD:
                return ReviewDecision(decision="reject", check_results=results)

            r = check_encoded_content(
                all_content,
                self._answer_hash_set,
                min_exact_matches,
                encoding_max_depth=self._config.encoding_max_depth,
                max_decoded_total_bytes=self._config.max_decoded_total_bytes,
                skeleton_enabled=skeleton_enabled,
                max_evidence_line_len=max_evidence_line_len,
            )
            results.append(r)
            if r.confidence >= HIGH_CONFIDENCE_THRESHOLD:
                return ReviewDecision(decision="reject", check_results=results)

            r = check_substitution_ciphers(
                all_content,
                self._answer_hash_set,
                min_exact_matches,
                skeleton_enabled=skeleton_enabled,
                max_evidence_line_len=max_evidence_line_len,
            )
            results.append(r)
            if r.confidence >= HIGH_CONFIDENCE_THRESHOLD:
                return ReviewDecision(decision="reject", check_results=results)

        if self._config.normalized_answer_hashes:
            r = check_normalized_matches(
                all_content,
                self._normalized_answer_hash_set,
                min_exact_matches,
                skeleton_enabled=skeleton_enabled,
                max_evidence_line_len=max_evidence_line_len,
            )
            results.append(r)
            if r.confidence >= HIGH_CONFIDENCE_THRESHOLD:
                return ReviewDecision(decision="reject", check_results=results)

        results.append(check_prompt_size(config_bytes, self._config.max_prompt_bytes))
        results.append(
            check_shell_patterns(
                exec_content,
                self._config.shell_patterns,
                contextual_patterns=self._config.shell_contextual_patterns,
            )
        )
        results.append(check_suspicious_content(exec_content))
        results.append(check_number_words(exec_content))
        results.append(
            check_python_daemon_spawn(
                scan.contents,
                max_evidence_line_len=max_evidence_line_len,
            )
        )
        results.append(
            check_outbound_network(
                scan.contents,
                max_evidence_line_len=max_evidence_line_len,
            )
        )

        incomplete = _scan_incomplete_result(scan, self._config.min_skipped_files_for_flag)
        if incomplete is not None:
            results.append(incomplete)
        coverage = _coverage_result(scan, self._config.min_scan_coverage_ratio)
        if coverage is not None:
            results.append(coverage)

        has_flags = any(r.confidence > 0.0 for r in results)
        decision = "flag" if has_flags else "clean"
        return ReviewDecision(decision=decision, check_results=results)


# Translation table from the legacy tarball.SkippedReason vocabulary to the
# closed Literal vocabulary on models.SkippedFile. ``non_regular_member`` is
# not surfaced to L2 (irrelevant: dirs/symlinks).
_L2SkippedReason = Literal[
    "hard_reject_extension",
    "max_scannable_file_bytes",
    "max_total_scanned_bytes",
    "decompression_bomb",
    "binary_decode_failed",
    "scan_unhandled_error",
]

_SKIPPED_REASON_MAP: dict[str, _L2SkippedReason | None] = {
    "hard_reject_binary": "hard_reject_extension",
    "non_text_extension": "binary_decode_failed",
    "oversized_file": "max_scannable_file_bytes",
    "total_cap_reached": "max_total_scanned_bytes",
    "non_regular_member": None,
}


def _map_skipped_reason(legacy: str) -> _L2SkippedReason | None:
    return _SKIPPED_REASON_MAP.get(legacy)


def _format_skipped_evidence(skipped: list[SkippedFile], limit: int) -> list[str]:
    """Render up to ``limit`` skipped files as evidence lines."""
    head = skipped[:limit]
    lines = [f"{s.path} ({s.reason}, {s.size} bytes)" for s in head]
    if len(skipped) > limit:
        lines.append(f"... and {len(skipped) - limit} more")
    return lines


def _scan_incomplete_result(scan: TarScanResult, min_skipped_to_flag: int) -> CheckResult | None:
    """Emit a low-confidence flag if enough files were skipped."""
    # Hard-rejected binaries already produced their own flag; report only
    # the residual skip categories.
    residual = [s for s in scan.skipped if s.reason != "hard_reject_binary"]
    if len(residual) < min_skipped_to_flag:
        return None
    return CheckResult(
        check_name=CHECK_NAME_SCAN_INCOMPLETE,
        confidence=0.2,
        evidence=_format_skipped_evidence(residual, _MAX_EVIDENCE_PATHS),
        affected_paths=[s.path for s in residual[:MAX_AFFECTED_PATHS]],
    )


def _coverage_result(scan: TarScanResult, min_ratio: float) -> CheckResult | None:
    """Emit a flag when the scan covered less than ``min_ratio`` of files."""
    if min_ratio <= 0.0 or scan.total_files <= 0:
        return None
    scanned = len(scan.contents)
    ratio = scanned / scan.total_files
    if ratio >= min_ratio:
        return None
    return CheckResult(
        check_name=CHECK_NAME_LOW_COVERAGE,
        confidence=0.3,
        evidence=[f"Scanned {scanned}/{scan.total_files} files ({ratio:.0%})"],
    )
