"""In-memory tarball extraction for security scanning.

Extracts text files from a gzipped tarball, filtering by extension and
per-file size cap. Non-text files are categorised: hard-rejected binary
types (archives, serialised stores) are surfaced explicitly; others are
recorded as skipped so the static review can flag them.

This module also exposes a length-limited gzip reader (``open_bounded_targz``)
that callers in both arena_core and executor use to bound decompressed
output and reject decompression bombs.
"""

from __future__ import annotations

import base64
import binascii
import contextlib
import gzip
import json
import logging
import os
import tarfile
from collections.abc import Iterator
from dataclasses import dataclass
from io import BytesIO
from pathlib import PurePosixPath
from typing import IO, BinaryIO, Literal, NamedTuple, cast

logger = logging.getLogger(__name__)

SCANNABLE_EXTENSIONS: frozenset[str] = frozenset(
    {
        ".py",
        ".yaml",
        ".yml",
        ".json",
        ".txt",
        ".md",
        ".cfg",
        ".toml",
        ".env",
        ".sh",
        ".ini",
        ".html",
        ".htm",
        ".xml",
        ".csv",
        ".tsv",
        ".conf",
        ".properties",
        ".sql",
        ".hex",
        ".b64",
        ".base64",
        ".js",
        ".ts",
        ".java",
        ".c",
        ".cpp",
        ".h",
        ".rs",
        ".go",
        ".rb",
        ".r",
        # Templates
        ".j2",
        ".jinja",
        ".jinja2",
        # Infrastructure / scripts
        ".dockerfile",
        ".tf",
        ".hcl",
        ".ps1",
        ".bat",
        ".cmd",
        ".lua",
        ".pl",
        ".pm",
        ".php",
        # Backup / alternate extensions (prevent hiding via rename)
        ".bak",
        ".old",
        ".orig",
        ".example",
        ".sample",
        ".template",
        # Data / config
        ".config",
        ".data",
        ".dat",
        ".log",
        ".out",
        # Additional text formats
        ".rst",
        ".adoc",
        ".tex",
        ".diff",
        ".patch",
        # Notebooks: extracted via _extract_notebook_text so cell sources +
        # output text reach the matcher as clean lines rather than escaped JSON.
        ".ipynb",
    }
)

SCANNABLE_BASENAMES: frozenset[str] = frozenset(
    {
        "dockerfile",
        "makefile",
        "gemfile",
        "rakefile",
        "vagrantfile",
        "procfile",
        "brewfile",
        "jenkinsfile",
        "containerfile",
        # Dotfile basenames: pathlib treats a leading-dot name as having
        # empty suffix, so these miss the extension allowlist entirely.
        ".env",
        ".envrc",
    }
)

MAX_SCANNABLE_FILE_SIZE: int = 512 * 1024  # 512 KB per file
MAX_TOTAL_EXTRACTED_BYTES: int = 10 * 1024 * 1024  # 10 MB total across all files
MAX_NESTED_ARCHIVE_DEPTH: int = 2  # outer tarball + 1 nested archive

SkippedReason = Literal[
    "hard_reject_binary",
    "non_text_extension",
    "oversized_file",
    "total_cap_reached",
    "non_regular_member",
]


def safe_normalize_path(path: str) -> str | None:
    """NFC-normalize a tarball entry path. Returns None if the path contains
    control bytes (other than tab/newline) — those would either confuse the
    JSON encoder for the staging digest or smuggle data past path-based checks.

    Used by ``apply_l2_digest`` so the L2 LLM sees a deterministic key set
    regardless of how the submitter typed/encoded the in-tarball path.
    """
    import unicodedata

    norm = unicodedata.normalize("NFC", path)
    if any(ord(c) < 0x20 and c not in "\t\n" for c in norm):
        return None
    return norm


def apply_l2_truncation(text: str, *, max_bytes: int, strategy: str) -> str:
    """Apply L2 per-file truncation. ``strategy`` is "head" (first ``max_bytes``)
    or "head_tail" (first half + truncation marker + last half). The byte count
    refers to char count for simplicity — staging stores text and the JSON
    encoder accounts for actual byte size when batching.
    """
    if len(text) <= max_bytes:
        return text
    if strategy == "head":
        return text[:max_bytes]
    half = max_bytes // 2
    return text[:half] + f"\n…[truncated {len(text) - 2 * half} bytes]…\n" + text[-half:]


@dataclass(frozen=True, slots=True)
class SkippedFile:
    """A tarball member that was not scanned, with the reason."""

    path: str
    reason: SkippedReason
    size: int


class TarScanResult(NamedTuple):
    """Result of ``extract_text_content``.

    - ``contents``: path → decoded text content for scanned files.
    - ``skipped``: per-member skip records (hard-reject binaries, oversize, etc.).
    - ``total_files``: total number of regular-file members in the tarball,
      used by ``StaticSecurityReview`` to compute scan-coverage ratio.
    """

    contents: dict[str, str]
    skipped: list[SkippedFile]
    total_files: int


class _BoundedGzipReader:
    """File-like wrapper around a binary stream that raises ``tarfile.TarError``
    once the cumulative number of bytes returned by ``read()`` exceeds
    ``max_bytes``. This bounds gzip decompression output so a small tarball
    cannot expand to gigabytes before the per-member loop notices.

    Tarfile in streaming mode (``r|gz``) only calls ``read`` and ``close``;
    ``write``/``tell``/``seek`` are stubbed to raise so any accidental
    seekable-mode use surfaces immediately.
    """

    def __init__(self, source: BinaryIO, *, max_bytes: int) -> None:
        self._source = source
        self._max_bytes = max_bytes
        self._read_total = 0

    def read(self, size: int = -1) -> bytes:
        chunk = self._source.read(size)
        self._read_total += len(chunk)
        if self._read_total > self._max_bytes:
            raise tarfile.TarError(f"decompression bomb: gzip stream exceeded {self._max_bytes} bytes")
        return chunk

    def write(self, _data: bytes) -> int:
        raise tarfile.TarError("bounded reader is read-only")

    def tell(self) -> int:
        return self._read_total

    def seek(self, _offset: int, _whence: int = 0) -> int:
        raise tarfile.TarError("bounded reader does not support seek (use streaming mode)")

    def close(self) -> None:
        self._source.close()

    def __enter__(self) -> _BoundedGzipReader:
        return self

    def __exit__(self, *_exc: object) -> None:
        self.close()


_BOMB_CAP_MULTIPLIER = 10
"""Headroom factor on top of the caller's scan cap before the bounded reader
declares a bomb. A legitimate tarball may exceed the scan cap when shipping
binary assets we won't extract; only inflation by this multiplier is treated
as bomb-class. 10× balances false positives (binary-heavy submissions) against
real bombs (small compressed → GB decompressed)."""


@contextlib.contextmanager
def open_bounded_targz(
    source: bytes | os.PathLike[str] | BinaryIO,
    *,
    max_decompressed_bytes: int,
) -> Iterator[tarfile.TarFile]:
    """Open a gzipped tarball with a decompression-bomb cap.

    The reader raises ``tarfile.TarError`` once the *decompressed* output
    exceeds ``max_decompressed_bytes * _BOMB_CAP_MULTIPLIER``. The cap is
    applied to the gzip output (after decompression), so a tiny compressed
    bomb that expands to gigabytes is rejected before the per-member loop
    runs.

    Accepts bytes (in-memory tarball), a path-like (file on disk), or a
    pre-opened binary file. The latter two avoid loading the full file into
    memory before extraction.

    ``tarfile.TarFile`` does not close its ``fileobj`` on exit, so we own
    the lifecycle of the compressed-source handle and the gzip wrapper —
    cleaned up here explicitly.
    """
    we_own_compressed = True
    if isinstance(source, (bytes, bytearray, memoryview)):
        compressed: BinaryIO = BytesIO(bytes(source))
    elif isinstance(source, (str, os.PathLike)):
        compressed = open(os.fspath(source), "rb")  # noqa: SIM115 — closed in finally
    else:
        compressed = source
        we_own_compressed = False

    decompressed: gzip.GzipFile | None = None
    try:
        decompressed = gzip.GzipFile(fileobj=compressed, mode="rb")
        bounded = _BoundedGzipReader(
            cast(BinaryIO, decompressed),
            max_bytes=max_decompressed_bytes * _BOMB_CAP_MULTIPLIER,
        )
        with tarfile.open(fileobj=cast(IO[bytes], bounded), mode="r|") as tar:
            yield tar
    finally:
        if decompressed is not None:
            decompressed.close()
        if we_own_compressed:
            compressed.close()


def _extract_notebook_text(raw: bytes) -> str:
    """Extract scannable text from a Jupyter ``.ipynb`` notebook.

    Returns the concatenation of every cell's source plus every output
    text/plain payload, joined by newlines. On any JSON parse error or
    unexpected shape, returns the raw UTF-8 decode so the matcher still
    sees the answer-bearing bytes (just with noisier evidence).
    """
    try:
        nb = json.loads(raw.decode("utf-8", errors="replace"))
    except (json.JSONDecodeError, UnicodeDecodeError):
        return raw.decode("utf-8", errors="replace")

    cells = nb.get("cells") if isinstance(nb, dict) else None
    if not isinstance(cells, list):
        return raw.decode("utf-8", errors="replace")

    parts: list[str] = []
    for cell in cells:
        if not isinstance(cell, dict):
            continue
        source = cell.get("source")
        if isinstance(source, list):
            parts.extend(s for s in source if isinstance(s, str))
        elif isinstance(source, str):
            parts.append(source)

        outputs = cell.get("outputs")
        if not isinstance(outputs, list):
            continue
        for out in outputs:
            if not isinstance(out, dict):
                continue
            text = out.get("text")
            if isinstance(text, list):
                parts.extend(t for t in text if isinstance(t, str))
            elif isinstance(text, str):
                parts.append(text)
            data = out.get("data")
            if isinstance(data, dict):
                plain = data.get("text/plain")
                if isinstance(plain, list):
                    parts.extend(p for p in plain if isinstance(p, str))
                elif isinstance(plain, str):
                    parts.append(plain)

    return "\n".join(parts)


def _looks_like_gzip(b: bytes) -> bool:
    return b[:2] == b"\x1f\x8b"


def _try_decode_nested_archive(raw: bytes, *, path: PurePosixPath) -> bytes | None:
    """If ``raw`` is (a base64 of) a gzip stream, return the gzip bytes.

    Returns ``None`` when the payload is not a recognisable nested archive.
    """
    if _looks_like_gzip(raw):
        return raw
    # Hint by extension: .b64 / .base64 wrappers around tarballs.
    suffix = path.suffix.lower()
    if suffix in (".b64", ".base64"):
        try:
            decoded = base64.b64decode(raw, validate=False)
        except (binascii.Error, ValueError):
            return None
        if _looks_like_gzip(decoded):
            return decoded
    return None


def _classify_extension(
    path: PurePosixPath,
    *,
    allowed_extensions: frozenset[str],
    allowed_basenames: frozenset[str],
    hard_reject_extensions: frozenset[str],
    allowed_binary_extensions: frozenset[str],
) -> Literal["scan", "hard_reject", "non_text"]:
    """Decide how to handle a tarball member based on its extension.

    Precedence:
      1. If the extension is in ``allowed_binary_extensions``, scan it
         (operator opt-in always wins).
      2. If in ``hard_reject_extensions``, return ``"hard_reject"``.
      3. If the extension or basename is in the scan allowlist, scan it.
      4. Compound extensions (``foo.py.bak``) check the inner extension.
      5. Otherwise, ``"non_text"``.
    """
    ext = path.suffix.lower()
    name_lower = path.name.lower()

    if ext in allowed_binary_extensions:
        return "scan"
    if ext in hard_reject_extensions:
        return "hard_reject"
    if ext in allowed_extensions or name_lower in allowed_basenames:
        return "scan"

    # Compound extension fallback: foo.py.bak → inner ext .py
    inner_ext = PurePosixPath(path.stem).suffix.lower()
    if inner_ext and inner_ext in allowed_extensions:
        return "scan"

    return "non_text"


_EntryDecision = Literal["scan", "hard_reject", "non_text", "oversized", "total_cap_reached"]


def _classify_entry(
    path: str,
    declared_size: int,
    *,
    total_extracted: int,
    allowed_extensions: frozenset[str],
    allowed_basenames: frozenset[str],
    max_file_size: int,
    max_total_bytes: int,
    hard_reject_extensions: frozenset[str],
    allowed_binary_extensions: frozenset[str],
) -> _EntryDecision:
    """Pre-body decision for a single regular-file entry. Pure function — no
    state mutation, no I/O.

    Returns ``"scan"`` if the caller should fetch the body and pass it to
    :func:`_decode_under_cap`. Any other return value is a skip reason that
    the caller records on the shared ``skipped`` list:

    - ``"hard_reject"``  → ``SkippedReason="hard_reject_binary"``
    - ``"non_text"``     → ``SkippedReason="non_text_extension"``
    - ``"oversized"``    → ``SkippedReason="oversized_file"``
    - ``"total_cap_reached"`` → ``SkippedReason="total_cap_reached"``; caller
      should also stop iterating (and drain remaining members for accurate
      ``total_files``, if the underlying source is a streaming tarball).

    Shared with the future S3-extracted scanner so the tar-driven and
    S3-driven scans produce byte-identical ``TarScanResult`` for the same
    logical content.
    """
    pure_path = PurePosixPath(path)
    classification = _classify_extension(
        pure_path,
        allowed_extensions=allowed_extensions,
        allowed_basenames=allowed_basenames,
        hard_reject_extensions=hard_reject_extensions,
        allowed_binary_extensions=allowed_binary_extensions,
    )
    if classification == "hard_reject":
        return "hard_reject"
    if classification == "non_text":
        return "non_text"
    if declared_size > max_file_size:
        return "oversized"
    # Pre-check against remaining headroom using the declared size as a lower
    # bound — saves reading the body when we'd reject anyway.
    if total_extracted + declared_size > max_total_bytes:
        return "total_cap_reached"
    return "scan"


def _decode_under_cap(
    body: bytes,
    *,
    total_extracted: int,
    max_total_bytes: int,
) -> tuple[str | None, int]:
    """Decode ``body`` as UTF-8 and return ``(content, content_bytes)``.

    Returns ``(None, len(body))`` if accepting this body would push past
    ``max_total_bytes`` after the actual byte count is known — the caller
    records a ``total_cap_reached`` skip in that case. Replacement chars
    from invalid bytes can shift byte length, so this re-checks the cap
    even though :func:`_classify_entry` did a lower-bound pre-check.

    ``content_bytes`` uses the raw byte length (not the re-encoded decoded
    text) to avoid a second full-content allocation per file.
    """
    content = body.decode("utf-8", errors="replace")
    content_bytes = len(body)
    if total_extracted + content_bytes > max_total_bytes:
        return None, content_bytes
    return content, content_bytes


def extract_text_content(
    tarball_bytes: bytes,
    *,
    allowed_extensions: frozenset[str] = SCANNABLE_EXTENSIONS,
    allowed_basenames: frozenset[str] = SCANNABLE_BASENAMES,
    max_file_size: int = MAX_SCANNABLE_FILE_SIZE,
    max_total_bytes: int = MAX_TOTAL_EXTRACTED_BYTES,
    hard_reject_extensions: frozenset[str] = frozenset(),
    allowed_binary_extensions: frozenset[str] = frozenset(),
    _nesting_depth: int = 0,
    _max_nesting_depth: int = MAX_NESTED_ARCHIVE_DEPTH,
) -> TarScanResult:
    """Extract text file contents from an in-memory gzipped tarball.

    Returns a ``TarScanResult`` mapping scanned paths to text content,
    plus a list of skipped members and the total regular-file count.

    Skipped categories:
      - ``hard_reject_binary``: extension is in ``hard_reject_extensions``
        (and not in ``allowed_binary_extensions``).
      - ``non_text_extension``: extension is not in the scan allowlist.
      - ``oversized_file``: ``member.size`` exceeds ``max_file_size``.
      - ``total_cap_reached``: extracting this file would exceed
        ``max_total_bytes`` (counted as UTF-8 bytes of decoded text).
      - ``non_regular_member``: not a regular file (symlink, device, dir).

    Raises ``tarfile.TarError`` if the gzip layer produces more bytes than
    ``max_total_bytes * 2`` — a decompression-bomb signal that the caller
    should surface as a deterministic reject verdict.

    The per-entry classification and decode logic lives in
    :func:`_classify_entry` and :func:`_decode_under_cap`. The future
    S3-extracted scanner uses the same two helpers so both paths produce
    byte-identical ``TarScanResult`` for the same logical content.
    """
    contents: dict[str, str] = {}
    skipped: list[SkippedFile] = []
    total_files = 0
    total_extracted = 0

    _SKIP_REASONS: dict[_EntryDecision, SkippedReason] = {
        "hard_reject": "hard_reject_binary",
        "non_text": "non_text_extension",
        "oversized": "oversized_file",
        "total_cap_reached": "total_cap_reached",
    }

    def _skip(member: tarfile.TarInfo, reason: SkippedReason) -> None:
        skipped.append(SkippedFile(path=member.name, reason=reason, size=member.size))

    def _drain_remaining(tar: tarfile.TarFile) -> int:
        """Advance the streaming iterator to count every remaining regular
        file without extracting bodies. ``for ... in tar`` would restart from
        ``tar.members[0]`` (each ``__iter__`` call returns a fresh
        generator) and double-count; ``tar.next()`` continues from the
        current stream position.
        """
        count = 0
        while True:
            remaining = tar.next()
            if remaining is None:
                break
            if remaining.isfile():
                count += 1
        return count

    with open_bounded_targz(tarball_bytes, max_decompressed_bytes=max_total_bytes) as tar:
        for member in tar:
            if not member.isfile():
                # Directories are not interesting; symlinks/devices are
                # filtered here. They don't count towards total_files.
                if member.type not in (tarfile.DIRTYPE,):
                    _skip(member, "non_regular_member")
                continue

            total_files += 1

            decision = _classify_entry(
                path=member.name,
                declared_size=member.size,
                total_extracted=total_extracted,
                allowed_extensions=allowed_extensions,
                allowed_basenames=allowed_basenames,
                max_file_size=max_file_size,
                max_total_bytes=max_total_bytes,
                hard_reject_extensions=hard_reject_extensions,
                allowed_binary_extensions=allowed_binary_extensions,
            )

            if decision == "oversized":
                logger.info(
                    "Skipping oversized file %s (%d bytes, limit %d)",
                    member.name,
                    member.size,
                    max_file_size,
                )
                _skip(member, _SKIP_REASONS[decision])
                continue

            if decision == "total_cap_reached":
                logger.warning(
                    "Reached total extraction limit (%d bytes), skipping %s and remaining",
                    max_total_bytes,
                    member.name,
                )
                _skip(member, _SKIP_REASONS[decision])
                total_files += _drain_remaining(tar)
                break

            if decision != "scan":
                _skip(member, _SKIP_REASONS[decision])
                continue

            f = tar.extractfile(member)
            if f is None:
                _skip(member, "non_regular_member")
                continue

            raw = f.read()
            content, content_bytes = _decode_under_cap(
                raw,
                total_extracted=total_extracted,
                max_total_bytes=max_total_bytes,
            )
            if content is None:
                # Decode-time replacement bytes pushed past the cap even after
                # the size pre-check passed; treat as the same skip category.
                # Drain remaining members for accurate total_files.
                logger.warning(
                    "Reached total extraction limit (%d bytes), skipping %s and remaining",
                    max_total_bytes,
                    member.name,
                )
                _skip(member, "total_cap_reached")
                total_files += _drain_remaining(tar)
                break

            path = PurePosixPath(member.name)
            if path.suffix.lower() == ".ipynb":
                # Replace the raw-JSON content with cell-aware extraction so
                # the matcher sees clean lines instead of escaped JSON. Byte
                # accounting stays on the raw size (already enforced by the
                # cap check above).
                content = _extract_notebook_text(raw)

            contents[member.name] = content
            total_extracted += content_bytes

            # Nested-archive recursion (G07). Guarded by depth cap; nested
            # contents inherit the parent's remaining byte budget so a
            # malicious deep wrap cannot blow the cap.
            if _nesting_depth + 1 < _max_nesting_depth:
                inner = _try_decode_nested_archive(raw, path=path)
                if inner is not None:
                    remaining = max(0, max_total_bytes - total_extracted)
                    if remaining > 0:
                        try:
                            nested = extract_text_content(
                                inner,
                                allowed_extensions=allowed_extensions,
                                allowed_basenames=allowed_basenames,
                                max_file_size=max_file_size,
                                max_total_bytes=remaining,
                                hard_reject_extensions=hard_reject_extensions,
                                allowed_binary_extensions=allowed_binary_extensions,
                                _nesting_depth=_nesting_depth + 1,
                                _max_nesting_depth=_max_nesting_depth,
                            )
                        except (tarfile.TarError, gzip.BadGzipFile, OSError):
                            nested = None
                        if nested is not None:
                            for inner_path, inner_content in nested.contents.items():
                                composite_key = f"{member.name}:{inner_path}"
                                contents[composite_key] = inner_content
                                total_extracted += len(inner_content.encode("utf-8"))
                            # Merge inner skip records so coverage / incomplete-
                            # scan signals reflect what we missed inside the
                            # nested archive too.
                            for sk in nested.skipped:
                                skipped.append(
                                    SkippedFile(
                                        path=f"{member.name}:{sk.path}",
                                        reason=sk.reason,
                                        size=sk.size,
                                    )
                                )
                            total_files += nested.total_files

    return TarScanResult(contents=contents, skipped=skipped, total_files=total_files)
