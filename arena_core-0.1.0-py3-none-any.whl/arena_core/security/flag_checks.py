"""Low-confidence flag checks: prompt size, shell patterns, suspicious content,
normalized answer matching, word-spelled number detection.

These checks never reach high confidence on their own — they always produce
advisory flags that are routed to Layer 2 LLM review.
"""

from __future__ import annotations

import hashlib
import re

from arena_core.security.models import MAX_AFFECTED_PATHS, CheckResult, is_sentinel_path
from arena_core.security.unicode_skeleton import canonicalise

CHECK_NAME_PROMPT_SIZE = "prompt_size"
CHECK_NAME_SHELL_PATTERNS = "shell_patterns"
CHECK_NAME_SUSPICIOUS_CONTENT = "suspicious_content"
CHECK_NAME_NORMALIZED_MATCHES = "normalized_matches"
CHECK_NAME_NUMBER_WORDS = "number_words"


# ---------------------------------------------------------------------------
# Prompt size check
# ---------------------------------------------------------------------------


def check_prompt_size(
    config_bytes: int,
    max_prompt_bytes: int,
) -> CheckResult:
    """Flag if combined serialized config size exceeds byte threshold."""
    total = config_bytes
    if total > max_prompt_bytes:
        return CheckResult(
            check_name=CHECK_NAME_PROMPT_SIZE,
            confidence=0.3,
            evidence=[f"Config size {total} bytes exceeds threshold {max_prompt_bytes} bytes"],
        )
    return CheckResult(check_name=CHECK_NAME_PROMPT_SIZE, confidence=0.0)


# ---------------------------------------------------------------------------
# Shell pattern detection
# ---------------------------------------------------------------------------

# Standalone & pattern: preceded and followed by whitespace, not part of &&
_AMPERSAND_RE = re.compile(r"(?<!\&)\s\&\s(?!\&)")


def _build_shell_regex(patterns: list[str]) -> re.Pattern[str] | None:
    """Build a compiled regex for word-boundary patterns, excluding '&'."""
    word_patterns = [p for p in patterns if p != "&"]
    if not word_patterns:
        return None
    return re.compile(r"\b(?:" + "|".join(re.escape(p) for p in word_patterns) + r")\b", re.IGNORECASE)


def _build_contextual_regex(patterns: list[str]) -> re.Pattern[str] | None:
    """Compile contextual shell patterns with re.MULTILINE | re.IGNORECASE
    so end-of-line anchors work and casing is normalised. Patterns are
    treated as raw regex (no escaping) so callers can constrain matches
    via lookahead / boundary syntax.
    """
    if not patterns:
        return None
    return re.compile("|".join(f"(?:{p})" for p in patterns), re.MULTILINE | re.IGNORECASE)


def check_shell_patterns(
    contents: dict[str, str],
    patterns: list[str],
    contextual_patterns: list[str] | None = None,
) -> CheckResult:
    """Detect shell backgrounding patterns in content.

    ``contents`` maps file path → body; matches record the originating
    path in ``affected_paths`` (capped at 10) for fast manual review.

    Two tiers:
    - ``patterns``: bare-word match via word boundary (existing behaviour).
    - ``contextual_patterns``: raw regex with required surrounding signal
      (``\\bat\\s+\\d``, ``\\bbg\\s*;``) — added for tokens like ``at`` /
      ``bg`` that collide with English prose if matched bare.

    Both tiers contribute to the same flag at confidence 0.2.
    """
    if not contents:
        return CheckResult(check_name=CHECK_NAME_SHELL_PATTERNS, confidence=0.0)
    if not patterns and not contextual_patterns:
        return CheckResult(check_name=CHECK_NAME_SHELL_PATTERNS, confidence=0.0)

    evidence: list[str] = []
    affected: set[str] = set()
    word_re = _build_shell_regex(patterns or [])
    contextual_re = _build_contextual_regex(contextual_patterns or [])
    has_ampersand = "&" in (patterns or [])

    for path, piece in contents.items():
        if word_re:
            for match in word_re.finditer(piece):
                evidence.append(f"Shell pattern '{match.group()}' detected")
                affected.add(path)
        if has_ampersand:
            for _match in _AMPERSAND_RE.finditer(piece):
                evidence.append("Backgrounding operator '&' detected")
                affected.add(path)
        if contextual_re:
            for match in contextual_re.finditer(piece):
                evidence.append(f"Contextual shell pattern '{match.group()}' detected")
                affected.add(path)

    if evidence:
        return CheckResult(
            check_name=CHECK_NAME_SHELL_PATTERNS,
            confidence=0.2,
            evidence=evidence,
            affected_paths=sorted(affected)[:MAX_AFFECTED_PATHS],
        )
    return CheckResult(check_name=CHECK_NAME_SHELL_PATTERNS, confidence=0.0)


# ---------------------------------------------------------------------------
# Suspicious content scoring
# ---------------------------------------------------------------------------

_LARGE_NUMERIC_RE = re.compile(r"\b\d{8,}\b")
_CSV_LINE_RE = re.compile(r"^[^,\n]+(?:,[^,\n]+){2,}$", re.MULTILINE)
_JSON_ARRAY_RE = re.compile(r'\[(?:\s*(?:"[^"]*"|\d+)\s*,\s*){3,}')


def check_suspicious_content(contents: dict[str, str]) -> CheckResult:
    """Flag large numeric literals, CSV-like data, and embedded JSON arrays."""
    evidence: list[str] = []
    affected: set[str] = set()

    for path, piece in contents.items():
        # Large numeric literals (8+ digits)
        nums = _LARGE_NUMERIC_RE.findall(piece)
        if nums:
            evidence.append(f"Large numeric literals: {', '.join(nums[:3])}{'...' if len(nums) > 3 else ''}")
            affected.add(path)

        # CSV-like data (5+ rows with 3+ comma-separated values)
        csv_lines = _CSV_LINE_RE.findall(piece)
        if len(csv_lines) >= 5:
            evidence.append(f"CSV-like data: {len(csv_lines)} rows detected")
            affected.add(path)

        # JSON arrays
        if _JSON_ARRAY_RE.search(piece):
            evidence.append("Embedded JSON array detected")
            affected.add(path)

    if evidence:
        return CheckResult(
            check_name=CHECK_NAME_SUSPICIOUS_CONTENT,
            confidence=0.2,
            evidence=evidence,
            affected_paths=sorted(affected)[:MAX_AFFECTED_PATHS],
        )
    return CheckResult(check_name=CHECK_NAME_SUSPICIOUS_CONTENT, confidence=0.0)


# ---------------------------------------------------------------------------
# Normalized answer matching
# ---------------------------------------------------------------------------

_NORMALIZE_PUNCT_RE = re.compile(r"[^\w\s]")
_NORMALIZE_SPACE_RE = re.compile(r"\s+")

# Leet substitutions applied ONLY to tokens that already contain an ASCII
# letter — guards numeric answers (`42`, `1247`) from being mangled into
# `ai`/`liei`. Single-meaning chars only: `1` is ambiguous (l/i) so it stays
# untouched and `4two` style digit-reinterpretation is out of scope.
_LEET_TABLE = str.maketrans({"0": "o", "3": "e", "4": "a", "5": "s", "7": "t", "@": "a", "$": "s"})
_TOKEN_RE = re.compile(r"\S+")
_HAS_LETTER_RE = re.compile(r"[A-Za-z]")


def _deleet(text: str) -> str:
    """Apply leet → plain substitution per token, only to tokens that
    already contain an ASCII letter. Pure-numeric tokens are preserved
    so e.g. ``42`` does not become ``ai``.
    """

    def _swap(match: re.Match[str]) -> str:
        token = match.group(0)
        if _HAS_LETTER_RE.search(token) is None:
            return token
        return token.translate(_LEET_TABLE)

    return _TOKEN_RE.sub(_swap, text)


def _normalize(text: str, *, skeleton_enabled: bool = True) -> str:
    """Canonicalise (NFKC + ZWJ + skeleton) → leet-de-substitute → lowercase
    → strip punctuation → collapse whitespace. Case-folding runs after
    canonicalisation so 'А' (Cyrillic) → 'A' → 'a'. The leet pass operates
    on alpha-containing tokens only — see ``_deleet`` for the guardrail.
    """
    text = canonicalise(text, skeleton_enabled=skeleton_enabled)
    text = _deleet(text)
    text = text.lower()
    text = _NORMALIZE_PUNCT_RE.sub("", text)
    return _NORMALIZE_SPACE_RE.sub(" ", text).strip()


def check_normalized_matches(
    contents: dict[str, str],
    normalized_answer_hashes: frozenset[str] | list[str],
    min_matches: int,
    *,
    skeleton_enabled: bool = True,
    max_evidence_line_len: int = 240,
) -> CheckResult:
    """Check content against normalized answer hashes.

    Normalization runs canonicalise → lowercase → punct strip → whitespace
    collapse. Catches 'PARIS' vs 'paris', '33,264' vs '33264', and
    Cyrillic / Greek homoglyph variants. Counts unique
    ``(line_hash, answer_hash)`` pairs to close the multiset bypass.
    """
    if not normalized_answer_hashes:
        return CheckResult(check_name=CHECK_NAME_NORMALIZED_MATCHES, confidence=0.0)

    from arena_core.security.answer_matcher import _extract_fragments, _line_key

    known = (
        normalized_answer_hashes if isinstance(normalized_answer_hashes, frozenset) else set(normalized_answer_hashes)
    )
    matched_pairs: set[tuple[str, str]] = set()
    evidence: list[str] = []
    affected: set[str] = set()

    for path, piece in contents.items():
        for line in piece.splitlines():
            stripped = line.strip()
            if not stripped:
                continue
            line_key = _line_key(stripped)
            # Extract fragments from raw line so delimiters survive (the
            # canonicaliser maps `|` → `l` which would break pipe-table
            # extraction). Canonicalise each fragment via `_normalize`.
            for fragment in _extract_fragments(stripped):
                fragment = fragment.strip()
                if not fragment:
                    continue
                normalized = _normalize(fragment, skeleton_enabled=skeleton_enabled)
                if not normalized:
                    continue
                h = hashlib.sha256(normalized.encode("utf-8")).hexdigest()
                pair = (line_key, h)
                if h in known:
                    # See note in check_answer_matches: credit every path,
                    # even when the pair was already counted. Synthetic
                    # sentinel keys (serialised config) never surface.
                    if not is_sentinel_path(path):
                        affected.add(path)
                    if pair not in matched_pairs:
                        matched_pairs.add(pair)
                        evidence.append(f"Normalized match: {fragment[:max_evidence_line_len]}")

    affected_paths = sorted(affected)[:MAX_AFFECTED_PATHS]
    if len(matched_pairs) >= min_matches:
        return CheckResult(
            check_name=CHECK_NAME_NORMALIZED_MATCHES,
            confidence=0.95,
            evidence=evidence,
            affected_paths=affected_paths,
        )
    if matched_pairs:
        return CheckResult(
            check_name=CHECK_NAME_NORMALIZED_MATCHES,
            confidence=0.1,
            evidence=evidence,
            affected_paths=affected_paths,
        )
    return CheckResult(check_name=CHECK_NAME_NORMALIZED_MATCHES, confidence=0.0)


# ---------------------------------------------------------------------------
# Word-spelled number detection
# ---------------------------------------------------------------------------

_NUMBER_WORDS = frozenset(
    {
        "zero",
        "one",
        "two",
        "three",
        "four",
        "five",
        "six",
        "seven",
        "eight",
        "nine",
        "ten",
        "eleven",
        "twelve",
        "thirteen",
        "fourteen",
        "fifteen",
        "sixteen",
        "seventeen",
        "eighteen",
        "nineteen",
        "twenty",
        "thirty",
        "forty",
        "fifty",
        "sixty",
        "seventy",
        "eighty",
        "ninety",
        "hundred",
        "thousand",
        "million",
        "billion",
    }
)

_NUMBER_PHRASE_RE = re.compile(
    r"\b(" + "|".join(_NUMBER_WORDS) + r")[\s-](" + "|".join(_NUMBER_WORDS) + r")\b",
    re.IGNORECASE,
)


def check_number_words(contents: dict[str, str]) -> CheckResult:
    """Flag compound number-word phrases that could be spelled-out answers."""
    evidence: list[str] = []
    affected: set[str] = set()

    for path, piece in contents.items():
        for match in _NUMBER_PHRASE_RE.finditer(piece):
            phrase = match.group(0)
            evidence.append(f"Number phrase: {phrase}")
            affected.add(path)

    if evidence:
        return CheckResult(
            check_name=CHECK_NAME_NUMBER_WORDS,
            confidence=0.2,
            evidence=evidence,
            affected_paths=sorted(affected)[:MAX_AFFECTED_PATHS],
        )
    return CheckResult(check_name=CHECK_NAME_NUMBER_WORDS, confidence=0.0)
