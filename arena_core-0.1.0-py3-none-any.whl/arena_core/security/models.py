"""Pydantic models for the static security review pipeline."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


class QuotaRefundConfig(BaseModel):
    """Per-competition controls over whether a team gets their daily quota back
    when a submission is rejected by the security review pipeline.

    Defaults are false for both paths — teams that try to cheat (L1 auto-reject)
    or that produced work an admin rejected should not recoup quota. Operators
    can opt-in per competition when appropriate (e.g. high-false-positive
    L1 configurations during onboarding).
    """

    model_config = ConfigDict(extra="forbid")

    on_l1_auto_reject: bool = False
    on_admin_reject: bool = False


class SecurityReviewConfig(BaseModel):
    """Configuration for the static security review, parsed from competition.config["security_review"].

    Uses ``extra="ignore"`` because the full config dict also contains Layer 2 fields
    (llm_model, slack_webhook_url, etc.) that Layer 1 does not need.
    """

    model_config = ConfigDict(extra="ignore")

    enabled: bool = False
    min_exact_matches: int = Field(default=5, ge=1)
    max_prompt_bytes: int = Field(default=51200, ge=0)
    answer_hashes: list[str] = Field(default_factory=list)
    normalized_answer_hashes: list[str] = Field(default_factory=list)

    # Bare-word shell tokens that always flag (word-boundary regex).
    shell_patterns: list[str] = Field(
        default_factory=lambda: [
            "nohup",
            "&",
            "disown",
            "setsid",
            "screen",
            "tmux",
            "batch",
            "cron",
            "crontab",
            "systemd-run",
            "daemon",
            "start-stop-daemon",
            "runuser",
        ]
    )

    # Contextual shell patterns that need surrounding signal to match,
    # avoiding the false-positive surface that bare words like `at` and
    # `bg` create against English prose. Compiled with re.MULTILINE |
    # re.IGNORECASE so $ anchors at line ends.
    shell_contextual_patterns: list[str] = Field(
        default_factory=lambda: [
            r"\bat\s+(?:\d{1,2}(?::\d{2})?|now|noon|midnight|tomorrow|next\s+\w+)\b",
            r"\bbg\s*(?:\(|;|$)",
        ]
    )

    # --- mode-aware review behaviour (PR #242 rebase Step 3) ---
    #
    # "flag_only" (default): L1/L2 workers auto-decide clean/reject; admin is
    # only pulled in on L2-suspect verdicts. Preserves today's throughput.
    #
    # "all" (strict advisory): workers never auto-transition. Every submission
    # parks UNDER_REVIEW until an admin acts. L1/L2 still run to produce
    # evidence that informs the admin's decision, but their verdict is never
    # terminal. Suited for closed/curated competitions with low volume.
    mode: Literal["flag_only", "all"] = "flag_only"

    # TODO(PR #242 follow-up): add `admin_notification: Literal["per_submission", "digest"]`
    # plus `digest_interval_minutes` when a digest worker ships. Until then the
    # field is omitted so the config schema stays honest about what it supports.

    # Configurable quota-refund policy (see QuotaRefundConfig).
    quota_refund: QuotaRefundConfig = Field(default_factory=QuotaRefundConfig)

    # When True, L1-auto-rejected tarballs are moved to a quarantine S3
    # prefix for admin forensics instead of deleted. The object key is
    # stored on the security_reviews row so the admin dashboard can issue
    # presigned download URLs.
    preserve_artifacts: bool = True

    # --- operational limits (PR #242 rebase Step 3) ---
    # L1 static review wall-clock timeout. After this the watchdog sends
    # SIGTERM to the ProcessPoolExecutor child; +5s grace, then SIGKILL.
    l1_timeout_seconds: int = Field(default=30, ge=1)

    # Max Redis-stream redeliveries before a submission is dead-lettered
    # (moved to the dedicated -deadletter stream and parked UNDER_REVIEW
    # with a Slack alert). Protects against poison payloads that crash
    # the worker repeatedly.
    l1_max_deliveries: int = Field(default=5, ge=1)
    l2_max_deliveries: int = Field(default=5, ge=1)

    # LLM retry budget within a single L2 delivery. Exponential backoff
    # between attempts. Stream redelivery is handled by l2_max_deliveries
    # on top of this.
    l2_retry_count: int = Field(default=3, ge=1)

    # --- L1 detection hardening (PR1: tarball-layer) ---
    # Per-file and total uncompressed-byte caps applied during tarball scan.
    # `max_total_scanned_bytes` is measured in UTF-8 byte length of decoded
    # text (not character count, see tarball.extract_text_content).
    max_scannable_file_bytes: int = Field(default=512 * 1024, ge=0)
    max_total_scanned_bytes: int = Field(default=10 * 1024 * 1024, ge=0)

    # Hard-reject extensions: archive/serialized binary types that can stash
    # answer keys regardless of size. Pass `[]` to disable for code-exec competitions.
    hard_reject_extensions: list[str] = Field(
        default_factory=lambda: [
            ".zip",
            ".tar",
            ".gz",
            ".7z",
            ".sqlite",
            ".pkl",
            ".npy",
            ".npz",
            ".parquet",
            ".safetensors",
            ".gguf",
            ".onnx",
            ".so",
        ],
    )

    # Per-competition opt-in for binary extensions. An extension in both
    # `hard_reject_extensions` and `allowed_binary_extensions` resolves to
    # allowed (operator opt-in is intentional).
    allowed_binary_extensions: list[str] = Field(default_factory=list)

    # Verdict to apply when a hard-reject binary is found:
    #   "reject" — strict, suitable for closed competitions with answer keys
    #   "flag"   — advisory, routes to L2 for human/LLM review
    binary_extension_action: Literal["reject", "flag"] = "reject"

    # Noise floor for the `scan_incomplete` flag — suppress when fewer than
    # this many files are skipped. Default 3 keeps single-icon submissions
    # unflagged; ops can drop to 1 for stricter competitions.
    min_skipped_files_for_flag: int = Field(default=3, ge=1)

    # Per-competition coverage-ratio floor. When `total_files > 0` and
    # `scanned/total < min_scan_coverage_ratio`, emit `low_scan_coverage`.
    # Default 0.0 = off (opt-in per competition).
    min_scan_coverage_ratio: float = Field(default=0.0, ge=0.0, le=1.0)

    # --- L1 detection hardening (PR2: detector-layer) ---

    # Encoding-chain recursion depth for `check_encoded_content`. Default 4
    # catches triple- and quadruple-base64 wrappings; raise carefully — each
    # depth level multiplies decoder cost.
    encoding_max_depth: int = Field(default=4, ge=1, le=8)

    # Memory cap on accumulated decoded intermediates across the depth loop.
    # If the decoded set exceeds this, emit `decode_cap_reached` flag and
    # stop decoding. Bounds memory under adversarial inputs; legitimate
    # encoded payloads are well under 20 MB total.
    max_decoded_total_bytes: int = Field(default=20 * 1024 * 1024, ge=0)

    # Per-line evidence preview length applied to all check_results. 240
    # chars preserves enough context for forensics without ballooning the
    # JSONB storage; raise per-competition if needed.
    max_evidence_line_len: int = Field(default=240, ge=40, le=2000)

    # Normaliser algorithm version for the canonicaliser used by
    # answer_matcher and flag_checks._normalize. Bumped on any change to
    # NFKC / ZWJ / confusables-skeleton logic. When a competition's stored
    # `answer_hashes` were generated with a different version than the
    # running code, static_review emits a `normaliser_version_mismatch`
    # advisory CheckResult so ops can re-key.
    normaliser_version: int = Field(default=2, ge=1)

    # Disable confusables-skeleton mapping for non-Latin-script
    # competitions (Cyrillic, Greek, Arabic, etc.) where Latin lookalike
    # collapse over-matches benign script-native content. NFKC + ZWJ
    # strip still apply.
    confusables_skeleton_enabled: bool = True

    # --- E1 verdict path ---
    # 0.70. Stack history: PR #457 raised this to 0.75 to park two
    # borderline FPs (0.75-shaped) at REVIEW_LOW_CONFIDENCE for admin
    # review; production replay then showed precision dropping below
    # acceptable bands so PR #459 returned the default to 0.70 — a
    # recall-favouring policy: anything ≥ 0.70 the LLM flags goes to
    # auto-quarantine, with admin handling the borderline band via
    # REVIEW_LOW_CONFIDENCE for verdicts <0.70 that the LLM still
    # tagged "suspicious". Operators can tune per competition.
    l2_suspicious_confidence_threshold: float = Field(default=0.70, ge=0.0, le=1.0)

    # --- E2 file batching ---
    l2_review_files_enabled: bool = False
    l2_per_file_truncate_bytes: int = Field(default=32 * 1024, ge=1024, le=1_048_576)
    l2_max_batch_bytes: int = Field(default=128 * 1024, ge=4096, le=2_097_152)
    l2_max_batches: int = Field(default=5, ge=1, le=50)
    # Match concurrency to max_batches so the second wave never waits on
    # the first when a submission packs cleanly. Replay observed a 218s
    # tail latency on a 4-batch submission with concurrency=3 — the 4th
    # batch sat in the semaphore until one of the first three returned.
    l2_batch_concurrency: int = Field(default=5, ge=1, le=20)
    l2_truncation_strategy: Literal["head", "head_tail"] = "head"
    l2_max_aggregated_evidence: int = Field(default=50, ge=1, le=500)
    l2_staging_ttl_days: int = Field(default=7, ge=1, le=30)

    # --- E3 token cap ---
    l2_daily_token_cap: int | None = Field(default=None, ge=1)
    l2_token_estimate_chars_per_token: int = Field(default=4, ge=1, le=16)
    l2_token_estimate_output_tokens: int = Field(default=1000, ge=1, le=64_000)
    # 25h (not 24h): the 1h overlap prevents day-boundary clock skew from
    # zeroing a worker's budget mid-call on a slow submission.
    l2_quota_redis_ttl_seconds: int = Field(default=25 * 3600, ge=3600)
    l2_context_safety_ratio: float = Field(default=0.8, gt=0.0, le=1.0)
    l2_prompt_overhead_bytes: int = Field(default=16 * 1024, ge=0)
    l2_model_context_overrides: dict[str, int] = Field(default_factory=dict)
    l2_strict_model_validation: bool = False

    # --- Operational ---
    l2_llm_model: str = "openrouter/minimax/MiniMax-M2.5"
    l2_llm_timeout_seconds: int = Field(default=60, ge=1, le=600)
    l2_retry_backoff_base_seconds: float = Field(default=5.0, ge=0.0, le=60.0)
    l2_terminal_http_statuses: list[int] = Field(default_factory=lambda: [400, 401, 403, 404, 422])
    l2_verdict_cache_ttl_seconds: int = Field(default=3600, ge=60, le=86_400)
    l2_verdict_cache_hash_prefix_len: int = Field(default=16, ge=8, le=64)
    l2_idempotency_cache_pepper_env: str = "ARENA_L2_CACHE_PEPPER"

    # --- L1 dataset-name hard-reject ---
    # Filenames that must never appear in a submission tarball — typically
    # the answer-bearing ground-truth CSVs / JSONLs distributed for the
    # competition's adapter (e.g. ``officeqa_full.csv`` for grounded-
    # reasoning). Match is case-sensitive on the path basename so partial
    # matches like ``my_officeqa_full.csv.bak`` do not trigger. When a
    # submission ships any of these, L1 emits the
    # ``forbidden_filename_present`` check at confidence 1.0 and the
    # decision is ``reject`` — no L2 LLM call needed, saving the token
    # budget for actually-ambiguous cases. Set per competition via
    # ``competition.config.security_review.forbidden_filenames``.
    forbidden_filenames: list[str] = Field(default_factory=list)


# Sentinel keys used in the dict[str, str] passed to aggregated checks
# (#532). NUL is forbidden in POSIX tar paths so these can never collide
# with a real tarball entry, even one a submitter constructed adversarially.
# Static-review aggregation prepends these to mark the JSON-serialised
# agent_config / competition config alongside scanned files.
SENTINEL_AGENT_CONFIG_PATH = "\x00agent_config"
SENTINEL_CONFIG_PATH = "\x00config"


def is_sentinel_path(p: str) -> bool:
    """True for the synthetic ``static_review`` aggregation keys; checks
    filter these out before constructing ``CheckResult.affected_paths``
    so persisted/admin output is real-files-only. A match found inside
    the serialised config is still attributed via ``check_name`` +
    ``evidence``."""
    return p.startswith("\x00")


MAX_AFFECTED_PATHS = 10
"""Cap on ``CheckResult.affected_paths`` length — bounds JSONB row size.
Producers MUST sort + truncate to this limit before constructing the
CheckResult; Pydantic's ``max_length`` raises ``ValidationError`` on read
for any row that exceeded the cap at write time."""


class CheckResult(BaseModel):
    """Result of a single security check."""

    model_config = ConfigDict(extra="forbid")

    check_name: str
    confidence: float = Field(ge=0.0, le=1.0)
    evidence: list[str] = Field(default_factory=list)
    # File paths inside the submission tarball that triggered this check,
    # capped at MAX_AFFECTED_PATHS. Empty list when the check operates on
    # aggregate data (e.g. ``prompt_size``) or matched only on synthetic
    # sentinel paths (serialised config). Manual reviewers grep on these
    # to open the offending file directly (#532).
    affected_paths: list[str] = Field(default_factory=list, max_length=MAX_AFFECTED_PATHS)


class ReviewDecision(BaseModel):
    """Overall decision from the static security review pipeline."""

    model_config = ConfigDict(extra="forbid")

    decision: Literal["reject", "flag", "clean"]
    check_results: list[CheckResult] = Field(default_factory=list)


class SkippedFile(BaseModel):
    """A tarball entry the L1 scanner declined to scan.

    The L2 LLM doesn't see the bytes but does see the path and size, closing
    the "hide answers in unscanned binaries" evasion class.
    """

    model_config = ConfigDict(extra="forbid")

    path: str
    size_bytes: int = Field(ge=0)
    reason: Literal[
        "hard_reject_extension",
        "max_scannable_file_bytes",
        "max_total_scanned_bytes",
        "decompression_bomb",
        "binary_decode_failed",
        "scan_unhandled_error",
    ]


class L1RunnerOutput(BaseModel):
    """Envelope the L1 subprocess writes to stdout.

    Adding a field here requires re-deploying runner and worker together
    (extra="forbid" rejects unknown values).
    """

    model_config = ConfigDict(extra="forbid")

    decision: ReviewDecision
    scanned_files: dict[str, str] = Field(default_factory=dict)
    skipped_files: list[SkippedFile] = Field(default_factory=list)
    partial_scan: bool = False


class ScannedFilesDigest(BaseModel):
    """Body of staging/<sub>/scanned_files.json — the per-file truncated text
    digest the L2 worker batches and ships to the LLM.
    """

    model_config = ConfigDict(extra="forbid")

    schema_version: Literal[1] = 1
    files: dict[str, str] = Field(default_factory=dict)
    skipped_files: list[SkippedFile] = Field(default_factory=list)
    partial_scan: bool = False


class _StagingObjectRef(BaseModel):
    """Pointer to a staged S3 object. ``version_id`` is the S3 VersionId when
    bucket versioning is enabled on the staging/ prefix; an empty string means
    "unversioned" — the L2 worker fetches the current object. The infra ticket
    that enables versioning + deny-overwrite policy populates this end-to-end.
    """

    model_config = ConfigDict(extra="forbid")
    key: str
    version_id: str = ""


class StagingManifest(BaseModel):
    """Body of staging/<sub>/manifest.json — the version-pinned pointer the L2
    worker resolves to fetch the actual staged objects."""

    model_config = ConfigDict(extra="forbid")

    schema_version: Literal[1] = 1
    submission_id: str
    agent_config: _StagingObjectRef
    scanned_files: _StagingObjectRef


def extract_security_config(competition_config: dict[str, Any] | None) -> SecurityReviewConfig:
    """Build ``SecurityReviewConfig`` from a competition row's ``config`` JSONB.

    Called from every layer that needs to know the review policy (producer,
    L1 worker, L2 worker, admin handler). Centralising the ``(config or {}).get(...)``
    dance keeps the four callsites from drifting apart silently.
    """
    section = (competition_config or {}).get("security_review", {})
    return SecurityReviewConfig(**section)
