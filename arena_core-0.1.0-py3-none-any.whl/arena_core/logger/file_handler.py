import os
from datetime import time as datetime_time
from logging.handlers import TimedRotatingFileHandler
from string import Template


class SentientTimedRotatingFileHandler(TimedRotatingFileHandler):
    def __init__(
        self,
        filename: str,
        when: str = "h",
        interval: int = 1,
        backupCount: int = 0,
        encoding: str | None = None,
        delay: bool = False,
        utc: bool = False,
        atTime: datetime_time | None = None,
        errors: str | None = None,
    ) -> None:
        filename = Template(filename).substitute(os.environ)
        logs_directory = os.path.dirname(filename)
        print(f"Creating logs directory at {logs_directory} for log file {filename}")
        os.makedirs(logs_directory, exist_ok=True)
        super().__init__(
            filename=filename,
            when=when,
            interval=interval,
            backupCount=backupCount,
            encoding=encoding,
            delay=delay,
            utc=utc,
            atTime=atTime,
            errors=errors,
        )
