import json
from logging import config
from pathlib import Path

DEFAULT_LOGGING_CONFIG = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "default": {
            "class": "logging.Formatter",
            "format": "%(levelname)-8s %(asctime)s %(name)-15s %(module)s:%(funcName)s:%(lineno)d: %(message)s",
        },
    },
    "handlers": {
        "console": {
            "level": "INFO",
            "class": "logging.StreamHandler",
            "formatter": "default",
            "stream": "ext://sys.stdout",
        },
    },
    "root": {
        "level": "INFO",
        "handlers": ["console"],
    },
}


class LoggingManager:
    def __init__(self, config_file: str | None = None) -> None:
        super().__init__()
        self.config_file = config_file or "logger.json"

    def init_logger(self) -> None:
        path = Path(self.config_file)
        if path.is_file():
            with open(path) as f:
                config_dict = json.load(f)
            config.dictConfig(config_dict)
        else:
            config.dictConfig(DEFAULT_LOGGING_CONFIG)
