"""arena.yaml configuration schema.

Parses and validates the arena.yaml file that defines an agent submission.
Supports harness agents (codex, goose, opencode, openhands) via declarative
YAML config with passthrough kwargs.

Uses OmegaConf for YAML loading (interpolation, env vars, merging) and
Pydantic for schema validation.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from arena_core.checks import (
    check_docker,
    check_import_path,
    check_samples_dir,
)
from arena_core.enums import AgentType, NetworkMode

# ---------------------------------------------------------------------------
# Harness agent import path mapping
# ---------------------------------------------------------------------------

HARNESS_IMPORT_MAP: dict[str, str] = {
    "codex": "arena_sdk.harness.codex:CodexAgent",
    "goose": "arena_sdk.harness.goose:GooseAgent",
    "opencode": "arena_sdk.harness.opencode:OpenCodeAgent",
    # "openhands": "arena_sdk.harness.openhands:OpenHandsAgent",  # disabled — use openhands-sdk instead
    "openhands-sdk": "arena_sdk.harness.openhands_sdk:OpenHandsSDKAgent",
}

_HARNESS_RESERVED_CONFIG_KEYS: frozenset[str] = frozenset(
    {
        "model",
        "model_name",
        "import_path",
        "env",
        "name",
        "version",
        "prompt_template_path",
        "skills_dir",
        "mcp_dir",
        "mcp_servers",
    }
)

# ---------------------------------------------------------------------------
# Agent section
# ---------------------------------------------------------------------------


class AgentConfig(BaseModel):
    """Agent section of arena.yaml.

    Supports two agent types:
    - python: Custom Python agent via import_path.
    - harness: Pre-built harness agent (codex, goose, opencode, openhands).
    """

    model_config = ConfigDict(extra="forbid")

    type: AgentType = AgentType.HARNESS

    # --- Tier 2: custom Python (required when type=python) ---
    import_path: str | None = None

    # --- Harness agents (required when type=harness) ---
    harness_name: str | None = None
    model: str | None = None

    # --- Harness common optional (Pydantic-validated) ---
    version: str | None = None
    prompt_template_path: str | None = None
    skills_dir: str | None = None
    mcp_dir: str | None = None
    mcp_servers: list[dict[str, Any]] | None = None

    # --- Agent-specific passthrough (forwarded as **kwargs) ---
    config: dict[str, Any] | None = None

    # --- Common ---
    env: dict[str, str] | None = None

    @model_validator(mode="after")
    def validate_by_type(self):
        if self.type == AgentType.PYTHON:
            if not self.import_path:
                raise ValueError("import_path required for python agents")
            if ":" not in self.import_path:
                raise ValueError(f"import_path must be 'module.path:ClassName', got '{self.import_path}'")
            mod, cls = self.import_path.rsplit(":", 1)
            if not mod or not cls:
                raise ValueError(f"import_path must have both module and class, got '{self.import_path}'")
        elif self.type == AgentType.HARNESS:
            if not self.harness_name:
                raise ValueError("harness_name required for harness agents")
            if self.harness_name not in HARNESS_IMPORT_MAP:
                raise ValueError(f"harness_name must be one of {sorted(HARNESS_IMPORT_MAP)}")
            if not self.model:
                raise ValueError("model required for harness agents")
            if self.config:
                bad = set(self.config) & _HARNESS_RESERVED_CONFIG_KEYS
                if bad:
                    raise ValueError(f"config keys {sorted(bad)} conflict with top-level fields; set them directly")
            if self.prompt_template_path and Path(self.prompt_template_path).is_absolute():
                raise ValueError("prompt_template_path must be a relative path")
            if self.skills_dir and Path(self.skills_dir).is_absolute():
                raise ValueError("skills_dir must be a relative path")
            if self.mcp_dir:
                normalized = self.mcp_dir.strip("/")
                if normalized != "mcp":
                    raise ValueError("mcp_dir must be 'mcp' or 'mcp/' — no other values are accepted")
            if self.mcp_servers:
                raise ValueError(
                    "mcp_servers is not supported. Use mcp_dir with mcp.toml " "files instead. See README for details."
                )
        return self

    @property
    def resolved_import_path(self) -> str | None:
        """Import path for both python and harness agents."""
        if self.type == AgentType.HARNESS:
            return HARNESS_IMPORT_MAP[self.harness_name]  # type: ignore[index]
        return self.import_path

    @property
    def module(self) -> str:
        """Extract module path (e.g., 'agent.main' or 'arena_sdk.harness.codex')."""
        path = self.resolved_import_path
        return path.rsplit(":", 1)[0] if path and ":" in path else ""

    @property
    def class_name(self) -> str:
        """Extract class name (e.g., 'MyAgent' or 'CodexAgent')."""
        path = self.resolved_import_path
        return path.rsplit(":", 1)[1] if path and ":" in path else ""

    @property
    def harness_kwargs(self) -> dict[str, Any]:
        """All harness kwargs for Harbor SDK: common fields + config passthrough."""
        kwargs: dict[str, Any] = {}
        if self.version is not None:
            kwargs["version"] = self.version
        if self.prompt_template_path is not None:
            kwargs["prompt_template_path"] = self.prompt_template_path
        if self.skills_dir is not None:
            kwargs["skills_dir"] = self.skills_dir
        if self.mcp_dir is not None:
            kwargs["mcp_dir"] = self.mcp_dir
        if self.mcp_servers is not None:
            kwargs["mcp_servers"] = self.mcp_servers
        if self.config:
            kwargs.update(self.config)
        return kwargs


# ---------------------------------------------------------------------------
# Environment section
# ---------------------------------------------------------------------------


class EnvironmentConfig(BaseModel):
    """Execution environment section of arena.yaml."""

    model_config = ConfigDict(extra="forbid")

    python_version: str = "3.11"
    memory: str = "4G"
    gpu: bool = False
    timeout_per_task: int = Field(default=300, ge=1, le=900)
    network: NetworkMode = NetworkMode.SANDBOX

    @field_validator("network")
    @classmethod
    def _no_proxy_only(cls, v: NetworkMode) -> NetworkMode:
        if v == NetworkMode.PROXY_ONLY:
            raise ValueError("PROXY_ONLY is not available for local config")
        return v


# ---------------------------------------------------------------------------
# Root config
# ---------------------------------------------------------------------------


class ArenaConfig(BaseModel):
    """Root arena.yaml schema.

    Required fields for v1: name, competition, agent.
    Everything else has sensible defaults.
    """

    model_config = ConfigDict(extra="forbid")

    # --- Required ---
    name: str
    competition: str  # Arena competition slug (e.g., "officeqa")

    # --- Optional metadata ---
    version: str | None = None
    description: str | None = None
    tags: list[str] | None = None

    # --- Agent definition (required) ---
    agent: AgentConfig

    # --- Execution environment ---
    environment: EnvironmentConfig = Field(default_factory=EnvironmentConfig)

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        if not v.replace("-", "").replace("_", "").isalnum():
            raise ValueError(f"name must be alphanumeric with hyphens/underscores, got '{v}'")
        return v

    def validate_environment(self, samples_dir: Path | None = None) -> list[str]:
        """Validate that the runtime environment matches this config.

        Checks import_path resolvability, Docker availability, and samples.
        Returns a list of error strings (empty = all OK).

        Args:
            samples_dir: Path to samples directory. Caller provides this
                         since path config is a CLI concern, not core.
        """
        results = [
            check_docker(),
            check_samples_dir(samples_dir) if samples_dir else None,
        ]

        # Import check applies to both types (python: custom module, harness: arena-sdk)
        if self.agent.module and self.agent.class_name:
            results.append(check_import_path(self.agent.module, self.agent.class_name))

        return [err for err in results if err is not None]


def load_arena_config(path: Path | str = "arena.yaml") -> ArenaConfig:
    """Load and validate an arena.yaml file.

    Uses OmegaConf for YAML loading (supports interpolation, env var
    resolution via ``${oc.env:VAR}``, and config merging) then validates
    with Pydantic.

    Args:
        path: Path to the arena.yaml file. Defaults to "arena.yaml" in cwd.

    Returns:
        Validated ArenaConfig instance.

    Raises:
        FileNotFoundError: If the file does not exist.
        arena_core.errors.ConfigError: If the YAML is invalid or fails validation.
    """
    from omegaconf import OmegaConf

    from arena_core.errors import ConfigError

    config_path = Path(path)
    if not config_path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")

    try:
        cfg = OmegaConf.load(config_path)
        raw = OmegaConf.to_container(cfg, resolve=True)
    except Exception as e:
        raise ConfigError(f"Invalid YAML in {config_path}: {e}") from e

    if not isinstance(raw, dict):
        raise ConfigError(f"Expected a YAML mapping in {config_path}, got {type(raw).__name__}")

    try:
        return ArenaConfig(**raw)  # type: ignore[arg-type]
    except Exception as e:
        raise ConfigError(f"Invalid arena.yaml: {e}") from e
