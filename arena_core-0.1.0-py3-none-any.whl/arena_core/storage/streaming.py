"""Reusable producer/consumer byte streaming helpers."""

from __future__ import annotations

import os
from collections.abc import AsyncIterator
from typing import IO

import anyio


class QueueByteStreamBridge:
    """Bridge sync writers and async byte consumers using an OS pipe."""

    def __init__(self, read_chunk_size: int = 1024 * 64) -> None:
        read_fd, write_fd = os.pipe()
        self._reader: IO[bytes] = os.fdopen(read_fd, "rb", buffering=0)
        self._writer: IO[bytes] = os.fdopen(write_fd, "wb", buffering=0)
        self._read_chunk_size = read_chunk_size
        self._finished = False
        self._error: Exception | None = None

    @property
    def writer(self) -> IO[bytes]:
        return self._writer

    def put_chunk(self, chunk: bytes) -> None:
        if self._finished:
            raise ValueError("Cannot put chunk on finished stream bridge")
        if not chunk:
            return
        self._writer.write(chunk)

    def fail(self, error: Exception) -> None:
        if self._finished:
            return
        self._error = error
        self.finish()

    def finish(self) -> None:
        if self._finished:
            return
        self._finished = True
        self._writer.close()

    async def iter_bytes(self) -> AsyncIterator[bytes]:
        try:
            while True:
                chunk = await anyio.to_thread.run_sync(self._reader.read, self._read_chunk_size)
                if not chunk:
                    break
                yield chunk
        finally:
            self._reader.close()
        if self._error is not None:
            raise self._error
