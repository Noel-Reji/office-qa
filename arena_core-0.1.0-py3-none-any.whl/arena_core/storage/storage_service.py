"""Storage service interface and AWS S3 implementation."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import AsyncIterator
from typing import Any

import aioboto3
from botocore.exceptions import ClientError

# ── Submission artifact helpers ──────────────────────────────────────────────


def build_submission_artifact_key(prefix: str, competition_id: str, submission_id: str) -> str:
    """Build the S3 object key for a submission's agent tarball.

    Pattern: ``{prefix}/{competition_id}/{submission_id}.tar.gz``

    Used by the API server (upload) and seed/test scripts (artifact_url construction).
    """
    return f"{prefix.rstrip('/')}/{competition_id}/{submission_id}.tar.gz"


def build_submission_artifact_url(bucket: str, prefix: str, competition_id: str, submission_id: str) -> str:
    """Build the full ``s3://`` URL for a submission's agent tarball."""
    key = build_submission_artifact_key(prefix, competition_id, submission_id)
    return f"s3://{bucket}/{key}"


def derive_extracted_base_from_artifact_key(artifact_key: str) -> str | None:
    """Inverse of the api server's paired-key convention:

        artifact_key   = f"{prefix}/{competition_id}/{submission_id}.tar.gz"
        extracted_base = f"{prefix}/extracted/{competition_id}/{submission_id}"

    Used by recovery-route consumers (orchestrator's L1 worker, executor's
    lambda-extracted ArtifactStore branch) that have an ``artifact_url`` /
    ``artifact_key`` but not an ``extracted_base`` in hand — the lambda's
    extracted prefix is deterministic from the tarball key, so the
    derivation produces the correct location without needing a separate
    config knob or message-schema field.

    Returns ``None`` for any shape that doesn't match the convention so
    callers can fail loud (dead-letter / submission FAILED) rather than
    fabricate an incorrect S3 location.
    """
    if not artifact_key.endswith(".tar.gz"):
        return None
    stem = artifact_key[: -len(".tar.gz")]
    parts = stem.rsplit("/", 2)
    if len(parts) != 3:
        return None
    prefix, competition_id, submission_id = parts
    if not (prefix and competition_id and submission_id):
        return None
    return f"{prefix}/extracted/{competition_id}/{submission_id}"


class StorageServiceError(Exception):
    """Raised when storage operations fail."""


class StorageService(ABC):
    """Abstract interface for object storage."""

    @abstractmethod
    async def head_object(self, bucket: str, key: str) -> None:
        """Verify the object exists (HEAD). Raises StorageServiceError on failure."""
        ...

    @abstractmethod
    def stream_object(self, bucket: str, key: str) -> AsyncIterator[bytes]:
        """Stream an object's bytes in backend-appropriate chunks."""
        ...

    @abstractmethod
    async def put_object(self, bucket: str, key: str, body: bytes) -> None:
        """Store bytes at the given key. Raises StorageServiceError on failure."""
        ...

    @abstractmethod
    async def list_objects(self, bucket: str, prefix: str) -> list[str]:
        """Return full keys under *prefix*. Raises StorageServiceError on failure."""
        ...

    @abstractmethod
    async def delete_object(self, bucket: str, key: str) -> None:
        """Delete the object at the given key. Raises StorageServiceError on failure."""
        ...

    async def get_object(self, bucket: str, key: str) -> bytes:
        """Return the full object body as bytes by consuming ``stream_object``.

        Convenience wrapper for small-to-medium objects (submission tarballs are
        capped at 200 MB by the API). Implementations can override with a
        single-shot get for efficiency.
        """
        buf = bytearray()
        async for chunk in self.stream_object(bucket, key):
            buf.extend(chunk)
        return bytes(buf)

    @abstractmethod
    async def copy_object(self, *, bucket: str, source_key: str, dest_key: str) -> None:
        """Copy an object within the same bucket. Raises StorageServiceError on failure."""
        ...

    @abstractmethod
    async def presigned_get_url(self, bucket: str, key: str, *, expires_in: int = 60) -> str:
        """Return a presigned GET URL valid for ``expires_in`` seconds.

        Used by the admin dashboard to hand the reviewer a short-lived link to
        a quarantined or staged submission artifact without proxying the bytes
        through the API server.
        """
        ...


class S3StorageService(StorageService):
    """Storage service backed by AWS S3 (async via aioboto3)."""

    def __init__(
        self,
        *,
        region_name: str | None = None,
        session: Any = None,
    ) -> None:
        """Create an S3-backed storage service.

        Uses an aioboto3 Session so the default credential chain can refresh (e.g. IAM
        role credentials on EC2/ECS).

        Args:
            region_name: AWS region for S3.
            session: Optional ``aioboto3.Session`` (or test double with ``.client()``).
        """
        self._session = session if session is not None else aioboto3.Session(region_name=region_name)

    async def head_object(self, bucket: str, key: str) -> None:
        """Verify object exists via HEAD request."""
        try:
            async with self._session.client("s3") as client:
                await client.head_object(Bucket=bucket, Key=key)
        except ClientError as e:
            raise StorageServiceError(f"S3 head_object failed for s3://{bucket}/{key}: {e}") from e

    async def stream_object(self, bucket: str, key: str) -> AsyncIterator[bytes]:
        """Stream an S3 object's bytes in reasonably sized chunks."""
        chunk_size = 1024 * 1024
        try:
            async with self._session.client("s3") as client:
                response = await client.get_object(Bucket=bucket, Key=key)
                body = response["Body"]
                while True:
                    chunk = await body.read(chunk_size)
                    if not chunk:
                        break
                    yield chunk
        except ClientError as e:
            raise StorageServiceError(f"S3 get_object failed for s3://{bucket}/{key}: {e}") from e

    async def get_object(self, bucket: str, key: str) -> bytes:
        """Single-shot GetObject — avoids the default ``bytearray`` concat loop."""
        try:
            async with self._session.client("s3") as client:
                response = await client.get_object(Bucket=bucket, Key=key)
                return await response["Body"].read()
        except ClientError as e:
            raise StorageServiceError(f"S3 get_object failed for s3://{bucket}/{key}: {e}") from e

    async def put_object(self, bucket: str, key: str, body: bytes) -> None:
        """Store bytes at the given S3 key."""
        try:
            async with self._session.client("s3") as client:
                await client.put_object(Bucket=bucket, Key=key, Body=body)
        except ClientError as e:
            raise StorageServiceError(f"S3 put_object failed for s3://{bucket}/{key}: {e}") from e

    async def list_objects(self, bucket: str, prefix: str) -> list[str]:
        """Return all S3 keys under *prefix*, paginating automatically."""
        try:
            keys: list[str] = []
            async with self._session.client("s3") as client:
                paginator = client.get_paginator("list_objects_v2")
                async for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
                    keys.extend(obj["Key"] for obj in page.get("Contents", []))
            return keys
        except ClientError as e:
            raise StorageServiceError(f"S3 list_objects failed for s3://{bucket}/{prefix}: {e}") from e

    async def delete_object(self, bucket: str, key: str) -> None:
        """Delete an S3 object at the given key."""
        try:
            async with self._session.client("s3") as client:
                await client.delete_object(Bucket=bucket, Key=key)
        except ClientError as e:
            raise StorageServiceError(f"S3 delete_object failed for s3://{bucket}/{key}: {e}") from e

    async def copy_object(self, *, bucket: str, source_key: str, dest_key: str) -> None:
        """Server-side copy within a single bucket — avoids download-then-upload."""
        try:
            async with self._session.client("s3") as client:
                await client.copy_object(
                    Bucket=bucket,
                    Key=dest_key,
                    CopySource={"Bucket": bucket, "Key": source_key},
                )
        except ClientError as e:
            raise StorageServiceError(f"S3 copy_object failed for s3://{bucket}/{source_key} → {dest_key}: {e}") from e

    async def presigned_get_url(self, bucket: str, key: str, *, expires_in: int = 60) -> str:
        """Generate a presigned GET URL via boto3's ``generate_presigned_url``."""
        try:
            async with self._session.client("s3") as client:
                return await client.generate_presigned_url(
                    "get_object",
                    Params={"Bucket": bucket, "Key": key},
                    ExpiresIn=expires_in,
                )
        except ClientError as e:
            raise StorageServiceError(f"S3 presigned_get_url failed for s3://{bucket}/{key}: {e}") from e
