"""Redis-backed leaderboard manager for competitions.

Follows the Redis leaderboard pattern: a sorted set for rankings (score per member)
and a hash for extra data keyed by the same member (see https://redis.io/solutions/leaderboards/).

- Sorted set key: leaderboard:{competition_id} — member = team_id, score = best score.
- Hash key: leaderboard:{competition_id}:data — field = team_id (same as sorted set member),
  value = submission_id that achieved that score.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime, timezone

import redis.asyncio as redis

logger = logging.getLogger(__name__)

LEADERBOARD_KEY_PREFIX = "leaderboard:"
DATA_SUFFIX = ":data"
META_SUFFIX = ":meta"


def _leaderboard_key(competition_id: str) -> str:
    return f"{LEADERBOARD_KEY_PREFIX}{competition_id}"


def _leaderboard_data_key(competition_id: str) -> str:
    """Hash key for leaderboard extra data; same key pattern as sorted set, field = member (team_id), value = data."""
    return f"{_leaderboard_key(competition_id)}{DATA_SUFFIX}"


def _leaderboard_meta_key(competition_id: str) -> str:
    """Hash key for leaderboard metadata (e.g. last updated timestamp)."""
    return f"{_leaderboard_key(competition_id)}{META_SUFFIX}"


class LeaderboardManager:
    """Manages competition leaderboards in Redis using sorted sets.

    - One entry per user; the stored score is the user's highest score.
    - Updates only replace the score when the new score is greater than the current one.
    """

    def __init__(self, redis_client: redis.Redis) -> None:
        """Initialize with an async Redis client.

        Args:
            redis_client: Connected redis.asyncio.Redis instance (decode_responses=True recommended).
        """
        self._redis = redis_client

    async def ping(self) -> bool:
        """Check Redis connectivity."""
        return await self._redis.ping()

    async def create_leaderboard(self, competition_id: str) -> None:
        """Create or reset the leaderboard for a competition.

        If the key already exists, it is deleted so the leaderboard starts empty.
        If it does not exist, this is a no-op (the key is created on first update_score).
        Also deletes the leaderboard data hash for this competition.

        Args:
            competition_id: Unique competition identifier.
        """
        key = _leaderboard_key(competition_id)
        data_key = _leaderboard_data_key(competition_id)
        meta_key = _leaderboard_meta_key(competition_id)
        await self._redis.delete(key, data_key, meta_key)
        logger.info("Leaderboard created/reset for competition %s", competition_id)

    async def update_score(
        self,
        competition_id: str,
        team_id: str,
        score: float,
        submission_id: str,
    ) -> bool:
        """Update the score for a team in the competition leaderboard.

        Only updates if the new score is greater than the team's current score
        (or adds the team if they are not yet on the leaderboard). Ensures
        at most one entry per team, with the highest score kept. When updated,
        stores the submission_id that achieved this score.

        Args:
            competition_id: Competition identifier.
            team_id: Team identifier.
            score: New score to consider.
            submission_id: Submission that produced this score.

        Returns:
            True if the leaderboard was updated (new team added or score increased),
            False if the team already had an equal or higher score.
        """
        key = _leaderboard_key(competition_id)
        # GT: only update if new score is greater than current (or add if new member).
        # CH: count members with changed scores as updated (needed to track improved scores).
        updated = await self._redis.zadd(key, {team_id: score}, gt=True, ch=True)
        if updated:
            data_key = _leaderboard_data_key(competition_id)
            meta_key = _leaderboard_meta_key(competition_id)
            async with self._redis.pipeline(transaction=True) as pipe:
                pipe.hset(data_key, team_id, submission_id)
                pipe.hset(meta_key, mapping={"updated_at": datetime.now(timezone.utc).isoformat()})
                await pipe.execute()
        return bool(updated)

    @dataclass
    class Entry:
        team_id: str
        score: float
        submission_id: str | None

    @dataclass
    class Leaderboard:
        items: list["LeaderboardManager.Entry"]
        updated_at: datetime | None

    async def _get_last_updated(self, competition_id: str) -> datetime | None:
        """Return when the leaderboard for this competition was last updated, if known."""
        meta_key = _leaderboard_meta_key(competition_id)
        raw = await self._redis.hget(meta_key, "updated_at")
        if raw is None:
            return None
        try:
            return datetime.fromisoformat(raw)
        except ValueError:
            logger.warning(
                "Invalid updated_at value for leaderboard %s: %s",
                competition_id,
                raw,
            )
            return None

    async def get_score_for_submission(
        self,
        competition_id: str,
        team_id: str,
        submission_id: str,
    ) -> float | None:
        """Return the leaderboard score for a submission if it is the team's current best.

        Returns None if the team has no leaderboard entry, or if a different submission
        achieved the team's best score.
        """
        key = _leaderboard_key(competition_id)
        data_key = _leaderboard_data_key(competition_id)
        async with self._redis.pipeline(transaction=False) as pipe:
            pipe.zscore(key, team_id)
            pipe.hget(data_key, team_id)
            score_raw, best_submission_id = await pipe.execute()
        if score_raw is None or best_submission_id is None:
            return None
        # Handle bytes when Redis client is configured with decode_responses=False.
        if isinstance(best_submission_id, bytes):
            best_submission_id = best_submission_id.decode()
        if best_submission_id != submission_id:
            return None
        return float(score_raw)

    async def get_leaderboard(
        self,
        competition_id: str,
        *,
        start: int = 0,
        stop: int = -1,
    ) -> "LeaderboardManager.Leaderboard":
        """Return the leaderboard for a competition, highest scores first.

        Args:
            competition_id: Competition identifier.
            start: Start rank (0-based). Default 0.
            stop: End rank (inclusive). Default -1 for all.

        Returns:
            Leaderboard object with items ordered by score descending (best first) and
            updated_at timestamp if known.
        """
        key = _leaderboard_key(competition_id)
        data_key = _leaderboard_data_key(competition_id)
        raw = await self._redis.zrevrange(key, start, stop, withscores=True)
        if not raw:
            return self.Leaderboard(items=[], updated_at=await self._get_last_updated(competition_id))

        team_ids = [member for member, _ in raw]
        # Hash uses same member (team_id) as sorted set; value is submission_id
        submission_ids = await self._redis.hmget(data_key, team_ids)
        items = [
            self.Entry(team_id=tid, score=float(score), submission_id=sub_id if sub_id is not None else None)
            for (tid, score), sub_id in zip(raw, submission_ids, strict=True)
        ]
        updated_at = await self._get_last_updated(competition_id)
        return self.Leaderboard(items=items, updated_at=updated_at)
