"""Utilities for computing composite leaderboard scores."""

from __future__ import annotations

from math import log2


class SubmissionScoreCalculator:
    """Compute Arena score using configured baselines and adjustment bounds."""

    def __init__(
        self,
        cost_baseline_per_task: float,
        time_baseline_per_task: float,
        cost_floor_per_task: float,
        time_floor_per_task: float,
        cost_adj_weight: float,
        cost_adj_cap: float,
        time_adj_weight: float,
        time_adj_cap: float,
    ) -> None:
        self.cost_baseline_per_task = cost_baseline_per_task
        self.time_baseline_per_task = time_baseline_per_task
        self.cost_floor_per_task = cost_floor_per_task
        self.time_floor_per_task = time_floor_per_task
        self.cost_adj_weight = cost_adj_weight
        self.cost_adj_cap = cost_adj_cap
        self.time_adj_weight = time_adj_weight
        self.time_adj_cap = time_adj_cap

        if self.cost_baseline_per_task <= 0:
            raise ValueError("cost_baseline_per_task must be greater than 0")
        if self.time_baseline_per_task <= 0:
            raise ValueError("time_baseline_per_task must be greater than 0")
        if self.cost_floor_per_task <= 0:
            raise ValueError("cost_floor_per_task must be greater than 0")
        if self.time_floor_per_task <= 0:
            raise ValueError("time_floor_per_task must be greater than 0")
        if self.cost_adj_weight < 0:
            raise ValueError("cost_adj_weight must be non-negative")
        if self.cost_adj_cap < 0:
            raise ValueError("cost_adj_cap must be non-negative")
        if self.time_adj_weight < 0:
            raise ValueError("time_adj_weight must be non-negative")
        if self.time_adj_cap < 0:
            raise ValueError("time_adj_cap must be non-negative")

    @staticmethod
    def _clamp(value: float, minimum: float, maximum: float) -> float:
        return max(minimum, min(value, maximum))

    def _compute_adjustment(self, *, baseline: float, average: float, weight: float, cap: float) -> float:
        return self._clamp(
            value=log2(baseline / average) * weight,
            minimum=-cap,
            maximum=cap,
        )

    def calculate_submission_score(
        self,
        number_of_tasks: int,
        total_cost: float,
        total_execution_time: float,
        total_correct: int,
    ) -> float:
        """Compute Arena score from per-submission correctness, cost, and time."""
        if number_of_tasks <= 0:
            raise ValueError("number_of_tasks must be greater than 0")
        if total_cost < 0:
            raise ValueError("total_cost must be non-negative")
        if total_execution_time < 0:
            raise ValueError("total_execution_time must be non-negative")
        if total_correct < 0:
            raise ValueError("total_correct must be non-negative")
        if total_correct == 0:
            return 0.0

        avg_cost_per_task = max(total_cost / number_of_tasks, self.cost_floor_per_task)
        avg_time_per_task = max(
            total_execution_time / number_of_tasks,
            self.time_floor_per_task,
        )

        cost_adj = self._compute_adjustment(
            baseline=self.cost_baseline_per_task,
            average=avg_cost_per_task,
            weight=self.cost_adj_weight,
            cap=self.cost_adj_cap,
        )
        time_adj = self._compute_adjustment(
            baseline=self.time_baseline_per_task,
            average=avg_time_per_task,
            weight=self.time_adj_weight,
            cap=self.time_adj_cap,
        )

        return float(total_correct) * (1.0 + cost_adj + time_adj)
