"""Reusable settings base classes for Arena services."""

from __future__ import annotations

from urllib.parse import quote_plus

from pydantic_settings import BaseSettings, SettingsConfigDict


class DatabaseSettings(BaseSettings):
    """Base settings for any service that connects to PostgreSQL.

    Subclasses inherit database connection fields and the computed
    ``database_url`` property.  Override fields with ``Field(...)``
    in subclasses to add validation aliases or defaults.
    """

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    database_host: str
    database_port: int
    database_username: str
    database_password: str
    database_name: str

    @property
    def database_url(self) -> str:
        """PostgreSQL async URL built from individual connection fields."""
        return (
            "postgresql+asyncpg://"
            f"{quote_plus(self.database_username)}:{quote_plus(self.database_password)}"
            f"@{self.database_host}:{self.database_port}/{self.database_name}"
        )
