from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from cli_commons.client import routes

from arena_cli.client.base import ArenaClient
from arena_core.models.submission import (
    Submission,
    SubmissionCancelResponse,
    SubmissionComparison,
    SubmissionCreateResponse,
    SubmissionListResponse,
)


async def create_submission(
    client: ArenaClient,
    metadata: dict,
    slug: str,
    agent_tarball: Path | None = None,
) -> SubmissionCreateResponse:
    """POST /api/v1/submissions/submissions (multipart/form-data)"""
    data = {
        "metadata": json.dumps(metadata),
        "slug": slug,
    }
    files: dict[str, tuple[str, Any, str]] | None = None
    file_handle = None
    try:
        if agent_tarball:
            file_handle = open(agent_tarball, "rb")
            files = {"agent": (agent_tarball.name, file_handle, "application/gzip")}
        # httpx requires a non-empty files dict to use multipart encoding;
        # when no tarball is provided, send an empty-content sentinel field.
        if not files:
            files = {"_": ("", b"", "application/octet-stream")}
        response = await client.post_multipart(
            routes.SUBMISSIONS,
            data=data,
            files=files,
        )
        return SubmissionCreateResponse(**response.json())
    finally:
        if file_handle:
            file_handle.close()


async def list_submissions(
    client: ArenaClient,
    slug: str,
    limit: int = 20,
    offset: int = 0,
) -> SubmissionListResponse:
    """GET /api/v1/submissions/submissions"""
    params: dict = {"slug": slug, "limit": limit, "offset": offset}
    response = await client.get(routes.SUBMISSIONS, params=params)
    return SubmissionListResponse(**response.json())


async def get_submission(client: ArenaClient, submission_id: str, slug: str | None = None) -> Submission:
    """GET /api/v1/submissions/submissions/{submission_id}"""
    params = {}
    if slug:
        params["slug"] = slug
    response = await client.get(routes.SUBMISSION.format(submission_id=submission_id), params=params)
    return Submission(**response.json())


async def compare_submissions(client: ArenaClient, id_a: str, id_b: str) -> SubmissionComparison:
    """GET /api/v1/submissions/compare?ids=a,b"""
    response = await client.get(routes.SUBMISSIONS_COMPARE, params={"ids": f"{id_a},{id_b}"})
    return SubmissionComparison(**response.json())


async def cancel_submission(
    client: ArenaClient,
    submission_id: str,
    slug: str | None = None,
) -> SubmissionCancelResponse:
    """DELETE /api/v1/submissions/submissions/{submission_id}"""
    params = {}
    if slug:
        params["slug"] = slug
    response = await client.delete(routes.SUBMISSION.format(submission_id=submission_id), params=params)
    return SubmissionCancelResponse(**response.json())
