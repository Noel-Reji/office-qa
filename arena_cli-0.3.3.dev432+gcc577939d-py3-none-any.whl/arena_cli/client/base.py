"""Arena CLI-specific client wrapper."""

from cli_commons.client.base import BaseArenaClient


class ArenaClient(BaseArenaClient):
    """Arena user CLI client with built-in auth guidance."""

    def __init__(self, token: str, base_url: str):
        super().__init__(token=token, base_url=base_url, auth_hint="arena auth login")


__all__ = ["ArenaClient"]
