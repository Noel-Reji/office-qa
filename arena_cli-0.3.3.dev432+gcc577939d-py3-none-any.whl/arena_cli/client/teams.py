from __future__ import annotations

from cli_commons.client import routes

from arena_cli.client.base import ArenaClient
from arena_core.models.team import QuotaResponse


async def get_quota(client: ArenaClient, slug: str) -> QuotaResponse:
    """GET /api/v1/teams/me/quota"""
    response = await client.get(routes.TEAM_QUOTA, params={"slug": slug})
    return QuotaResponse(**response.json())
