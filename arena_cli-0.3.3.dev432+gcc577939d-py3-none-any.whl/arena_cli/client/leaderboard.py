from __future__ import annotations

from cli_commons.client import routes

from arena_cli.client.base import ArenaClient
from arena_core.models.leaderboard import LeaderboardResponse


async def get_leaderboard(
    client: ArenaClient,
    competition: str,
    top: int = 10,
) -> LeaderboardResponse:
    """GET /api/v1/leaderboard?slug=&top="""
    response = await client.get(
        routes.LEADERBOARD,
        params={"slug": competition, "top": top},
    )
    return LeaderboardResponse(**response.json())
