from __future__ import annotations

import json
import tarfile
import tempfile
import time
from pathlib import Path

from cli_commons.client import routes

from arena_cli.client.base import ArenaClient
from arena_core.models.competition import CompetitionDetail, CompetitionListResponse


async def list_competitions(client: ArenaClient) -> CompetitionListResponse:
    """GET /api/v1/competitions"""
    response = await client.get(routes.COMPETITIONS)
    return CompetitionListResponse(**response.json())


async def get_competition(client: ArenaClient, slug: str) -> CompetitionDetail:
    """GET /api/v1/competitions/{slug}"""
    response = await client.get(routes.COMPETITION.format(slug=slug))
    return CompetitionDetail(**response.json())


async def download_samples(
    client: ArenaClient,
    slug: str,
    dest: Path,
    since_version: str | None = None,
    manifest_path: Path | None = None,
) -> Path:
    """GET /api/v1/competitions/{slug}/samples

    Downloads gzipped tarball and extracts to dest.
    Writes manifest.json if manifest_path is provided.
    Returns path to extracted samples directory.
    """
    params = {}
    if since_version:
        params["since_version"] = since_version

    response = await client.get(routes.COMPETITION_SAMPLES.format(slug=slug), params=params)

    with tempfile.NamedTemporaryFile(suffix=".tar.gz", delete=False) as tmp:
        tmp.write(response.content)
        tmp_path = Path(tmp.name)

    try:
        # Clean existing task dirs to prevent stale tasks from removed benchmarks.
        # Preserve manifest.json (sibling-level, written separately below).
        if dest.exists() and not since_version:
            for child in dest.iterdir():
                if child.is_dir():
                    import shutil

                    shutil.rmtree(child)
        dest.mkdir(parents=True, exist_ok=True)
        with tarfile.open(tmp_path, "r:gz") as tar:
            tar.extractall(path=dest, filter="data")
    finally:
        tmp_path.unlink(missing_ok=True)

    if manifest_path is not None:
        version = response.headers.get("X-Arena-Version") or f"ts-{int(time.time())}"
        manifest_path.parent.mkdir(parents=True, exist_ok=True)
        manifest_path.write_text(json.dumps({"version": version}))

    return dest
