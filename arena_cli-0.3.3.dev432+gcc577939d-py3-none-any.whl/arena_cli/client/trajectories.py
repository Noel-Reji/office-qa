from __future__ import annotations

import asyncio
import shutil
import tarfile
import tempfile
from pathlib import Path

import aiofiles
import aiofiles.os
from cli_commons.client import routes

from arena_cli.client.base import ArenaClient
from arena_core.enums import TaskStatus
from arena_core.models.trajectory import (
    TrajectoryDetail,
    TrajectoryListResponse,
)


def _extract_tarball(source: Path, dest: Path) -> None:
    with tarfile.open(source, mode="r:gz") as tar:
        tar.extractall(dest, filter="data")


async def list_trajectories(
    client: ArenaClient,
    submission_id: str | None = None,
    slug: str | None = None,
    status: TaskStatus | None = None,
    limit: int = 500,
    offset: int = 0,
) -> TrajectoryListResponse:
    """GET /api/v1/trajectories"""
    params: dict = {"limit": limit, "offset": offset}
    if submission_id:
        params["submission_id"] = submission_id
    if slug:
        params["slug"] = slug
    if status:
        params["status"] = status

    response = await client.get(routes.TRAJECTORIES, params=params)
    return TrajectoryListResponse(**response.json())


async def get_trajectory(
    client: ArenaClient,
    trajectory_id: str,
    slug: str | None = None,
) -> TrajectoryDetail:
    """GET /api/v1/trajectories/{trajectory_id}"""
    params: dict = {}
    if slug:
        params["slug"] = slug
    response = await client.get(routes.TRAJECTORY.format(trajectory_id=trajectory_id), params=params)
    return TrajectoryDetail(**response.json())


async def download_execution_artifacts(
    client: ArenaClient,
    submission_id: str,
    slug: str,
    dest: Path,
) -> Path:
    """Download execution artifacts tar.gz and extract to dest.

    Uses atomic extraction: extracts to a temp directory first, then
    renames to dest on success, so partial downloads don't pollute cache.

    Returns the path to the extracted directory.
    """
    params = {"submission_id": submission_id, "slug": slug}
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp_dir = Path(tempfile.mkdtemp(dir=dest.parent, prefix=f".{dest.name}-"))
    with tempfile.NamedTemporaryFile(suffix=".tar.gz", delete=False) as temp_file:
        temp_path = Path(temp_file.name)
    try:
        async with client.stream_get(routes.TRAJECTORIES_DOWNLOAD, params=params, timeout=300.0) as response:
            async with aiofiles.open(temp_path, "wb") as out_file:
                async for chunk in response.aiter_bytes():
                    if chunk:
                        await out_file.write(chunk)

        await asyncio.to_thread(_extract_tarball, temp_path, tmp_dir)

        if dest.exists():
            shutil.rmtree(dest)
        tmp_dir.rename(dest)
    except Exception:
        shutil.rmtree(tmp_dir, ignore_errors=True)
        raise
    finally:
        try:
            await aiofiles.os.remove(temp_path)
        except FileNotFoundError:
            pass

    return dest
