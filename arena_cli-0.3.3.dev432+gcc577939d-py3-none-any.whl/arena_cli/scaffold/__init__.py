"""Scaffold templates and static files for arena init."""

from __future__ import annotations

import shutil
from pathlib import Path

from jinja2 import Environment, FileSystemLoader

_SCAFFOLD_DIR = Path(__file__).parent
_TEMPLATES_DIR = _SCAFFOLD_DIR / "templates"
_STATIC_DIR = _SCAFFOLD_DIR / "static"
_env = Environment(loader=FileSystemLoader(str(_TEMPLATES_DIR)), keep_trailing_newline=True)


def render(template_name: str, **context: object) -> str:
    """Render a Jinja2 template from scaffold/templates/."""
    return _env.get_template(template_name).render(**context)


def copy_statics(dest: Path) -> list[Path]:
    """Copy static files and directories to dest, skipping existing. Returns created paths."""
    created: list[Path] = []
    if not _STATIC_DIR.is_dir():
        return created
    for f in sorted(_STATIC_DIR.iterdir()):
        target = dest / f.name
        if target.exists():
            continue
        if f.is_file():
            shutil.copy2(f, target)
            created.append(target)
        elif f.is_dir():
            shutil.copytree(f, target)
            created.append(target)
    return created
