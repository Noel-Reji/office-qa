"""Backward-compatible re-export from scaffold package."""

from arena_cli.scaffold import render

__all__ = ["render"]
