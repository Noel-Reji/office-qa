from __future__ import annotations

import json

import pydantic
import typer
from cli_commons.cli.errors import handle_errors, require_slug, run_async
from cli_commons.output.console import get_console
from cli_commons.output.tables import (
    print_local_comparison,
    print_server_comparison,
    print_submission_results,
    print_trajectory_detail,
    print_trajectory_list,
)

from arena_cli.cli._api import api_call
from arena_cli.client.base import ArenaClient
from arena_cli.client.submissions import compare_submissions, get_submission
from arena_cli.client.trajectories import get_trajectory, list_trajectories
from arena_cli.config.auth import resolve_token
from arena_cli.config.settings import get_settings
from arena_cli.output.streaming import stream_submission_progress
from arena_core.enums import SubmissionStatus
from arena_core.errors import ArenaError, NetworkError
from arena_core.models.results import RunResults

_ACTIVE_STATUSES = frozenset(
    {
        SubmissionStatus.SUBMITTED,
        SubmissionStatus.UNDER_REVIEW,
        SubmissionStatus.APPROVED,
        SubmissionStatus.IN_PROGRESS,
    }
)


def status(
    submission_id: str = typer.Argument(help="Submission ID to check"),
    slug: str | None = typer.Option(None, "--slug", "-s", help="Competition slug (defaults to arena.yaml)"),
    token: str | None = typer.Option(None, "--token", "-t", help="Arena API token"),
):
    """Check the status of a submitted submission."""
    console = get_console()
    resolved_slug = require_slug(slug, console)

    async def _op(client, resolved_token):
        return await get_submission(client, submission_id, slug=resolved_slug)

    submission = api_call(token, _op, console)

    console.print(f"  Submission: {submission.id}")
    console.print(f"  Status:     {submission.status}")
    if submission.stages:
        if submission.stages.execute:
            console.print(f"  Execute: score={submission.stages.execute.score:.3f}")


# Uses manual pattern (not api_call) because streaming requires the client
# to remain open across multiple awaits within the same session.
def results(
    submission_id: str = typer.Argument(help="Submission ID to get results for"),
    # no_stream: bool = typer.Option(False, "--no-stream", help="Don't stream if still running"),
    slug: str | None = typer.Option(None, "--slug", "-s", help="Competition slug (defaults to arena.yaml)"),
    token: str | None = typer.Option(None, "--token", "-t", help="Arena API token"),
):
    """Get full results for a submitted submission."""
    # todo remove when streaming is implemented
    no_stream = True
    console = get_console()
    settings = get_settings()
    resolved_slug = require_slug(slug, console)

    with handle_errors(console):
        resolved_token = resolve_token(token)

    async def _results():
        async with ArenaClient(token=resolved_token, base_url=settings.api_url) as client:
            submission = await get_submission(client, submission_id, slug=resolved_slug)

            if submission.status in _ACTIVE_STATUSES and not no_stream:
                console.print(f"Submission {submission_id} is {submission.status}. Streaming progress...\n")
                try:
                    await stream_submission_progress(client, submission_id, console)
                except (TimeoutError, NetworkError) as e:
                    console.print(f"\n[yellow]Stream interrupted:[/yellow] {e}")
                    console.print("Fetching final status...")
                submission = await get_submission(client, submission_id, slug=resolved_slug)

            return submission

    submission = run_async(_results, console)

    print_submission_results(submission, console)

    if submission.status == SubmissionStatus.COMPLETED:
        console.print(f"\n  [dim]Tip: run 'arena traces {submission_id}' for step-by-step agent logs[/dim]")


# Uses manual pattern (not api_call) because of the local-run fallback
# path that skips API calls entirely.
def compare(
    id_a: str = typer.Argument(help="First submission ID (or local run ID)"),
    id_b: str = typer.Argument(help="Second submission ID (or local run ID)"),
    token: str | None = typer.Option(None, "--token", "-t", help="Arena API token"),
):
    """Compare results of two submissions or local runs."""
    console = get_console()
    settings = get_settings()

    # Check if either ID is a local run
    runs_dir = settings.paths.runs_dir
    local_a = runs_dir / id_a / "results.json"
    local_b = runs_dir / id_b / "results.json"

    if local_a.exists() and local_b.exists():
        try:
            results_a = RunResults(**json.loads(local_a.read_text()))
            results_b = RunResults(**json.loads(local_b.read_text()))
        except (json.JSONDecodeError, pydantic.ValidationError) as e:
            raise ArenaError(f"Invalid local results file: {e}") from e
        print_local_comparison((results_a, results_b), console)
        return

    with handle_errors(console):
        resolved_token = resolve_token(token)

    async def _compare():
        async with ArenaClient(token=resolved_token, base_url=settings.api_url) as client:
            return await compare_submissions(client, id_a, id_b)

    comparison = run_async(_compare, console)

    print_server_comparison(comparison, console)


def traces(
    submission_id: str = typer.Argument(help="Submission ID to get traces for"),
    task_id: str | None = typer.Option(None, "--task", help="Task name from the list (e.g. officeqa-uid0003)"),
    trace_id: str | None = typer.Option(None, "--trace", help="Trace ID from the list (UUID in Trace ID column)"),
    limit: int = typer.Option(500, "--limit", "-n", help="Max number of tasks to list"),
    slug: str | None = typer.Option(None, "--slug", "-s", help="Competition slug (defaults to arena.yaml)"),
    token: str | None = typer.Option(None, "--token", "-t", help="Arena API token"),
):
    """List or inspect agent trajectories for a submission."""
    console = get_console()
    with handle_errors(console):
        if task_id and trace_id:
            raise ArenaError("Use --task or --trace, not both")
    resolved_slug = require_slug(slug, console)
    limit = max(1, min(limit, 500))

    async def _op(client, resolved_token):
        if trace_id:
            return await get_trajectory(client, trace_id, slug=resolved_slug)
        if task_id:
            offset = 0
            page_size = 500
            while True:
                listing = await list_trajectories(
                    client, submission_id=submission_id, slug=resolved_slug, limit=page_size, offset=offset
                )
                match = next((t for t in listing.items if t.task_id == task_id), None)
                if match is not None:
                    return await get_trajectory(client, match.trajectory_id, slug=resolved_slug)
                offset += page_size
                if offset >= listing.total:
                    break

            raise ArenaError(f"No trajectory found for task '{task_id}' in submission '{submission_id}'")
        return await list_trajectories(client, submission_id=submission_id, slug=resolved_slug, limit=limit)

    result = api_call(token, _op, console)

    if task_id or trace_id:
        print_trajectory_detail(result, console)
    else:
        print_trajectory_list(result, console)
