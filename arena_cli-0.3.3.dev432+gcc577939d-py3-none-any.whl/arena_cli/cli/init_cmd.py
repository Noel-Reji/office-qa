from __future__ import annotations

import json
import re
import subprocess
from pathlib import Path

import typer
from cli_commons.cli.errors import handle_errors
from cli_commons.output.console import get_console
from rich.console import Console
from rich.prompt import Prompt

from arena_cli.cli._api import api_call
from arena_cli.client.competitions import download_samples, get_competition
from arena_cli.config.settings import get_settings
from arena_cli.scaffold import copy_statics, render
from arena_core import EnvironmentConfig, load_arena_config
from arena_core.config import HARNESS_IMPORT_MAP
from arena_core.enums import AgentType


def _prompt_or_default(
    value: str | None,
    label: str,
    default: str,
    no_interactive: bool,
    console: Console,
    choices: list[str] | None = None,
) -> str:
    if value is not None:
        return value
    if no_interactive:
        return default
    return Prompt.ask(label, choices=choices, default=default, console=console)


def init(
    competition_slug: str = typer.Argument(help="Arena competition slug (e.g. 'officeqa')"),
    agent_type: AgentType | None = typer.Option(None, "--agent-type", help="Agent type: python or harness"),
    harness_name: str | None = typer.Option(None, "--harness-name", help="Harness agent name"),
    model: str | None = typer.Option(None, "--model", help="Model name for harness agent"),
    no_interactive: bool = typer.Option(False, "--no-interactive", help="Skip interactive prompts, use defaults"),
    token: str | None = typer.Option(None, "--token", "-t", help="Arena API token"),
):
    """Initialize a new Arena agent project for a competition.

    Downloads sample tasks and scaffolds a complete project with arena.yaml,
    pyproject.toml, .python-version, and optionally an agent stub.
    """
    console = get_console()
    settings = get_settings()

    async def _op(client, resolved_token):
        comp = await get_competition(client, competition_slug)
        settings.paths.ensure_dirs()
        samples_path = await download_samples(
            client, competition_slug, settings.paths.samples_dir, manifest_path=settings.paths.manifest_path
        )
        return comp, samples_path

    comp, samples_path = api_call(token, _op, console)

    # TODO: re-enable python agent type when fully supported
    if agent_type == AgentType.PYTHON:
        console.print("[red]Error:[/red] Python agent type is not yet supported. Use --agent-type harness.")
        raise typer.Exit(1)

    # Resolve agent_type — only harness supported for now
    if agent_type is None:
        agent_type = AgentType.HARNESS
        # TODO: re-enable interactive prompt when python is supported
        # agent_type = AgentType(
        #     _prompt_or_default(None, "Agent type", "harness", no_interactive, console, choices=["harness", "python"])
        # )

    harness_name = _prompt_or_default(
        harness_name, "Harness agent", "opencode", no_interactive, console, choices=sorted(HARNESS_IMPORT_MAP)
    )
    model = _prompt_or_default(model, "Model", "openrouter/z-ai/glm-5", no_interactive, console)

    # Compute project_name and env defaults once, unconditionally
    safe_slug = re.sub(r"[^a-zA-Z0-9_-]", "-", competition_slug).strip("-")
    project_name = f"my-{safe_slug}-agent"
    _env = EnvironmentConfig()

    # Scaffold arena.yaml if it doesn't exist
    config_path = Path(settings.config_filename)
    if not config_path.exists():
        content = render(
            "arena.yaml.harness.j2",
            competition_slug=competition_slug,
            project_name=project_name,
            memory=_env.memory,
            timeout_per_task=_env.timeout_per_task,
            harness_name=harness_name,
            model=model,
        )
        # TODO: re-enable python template when supported
        # if agent_type == AgentType.PYTHON:
        #     content = render("arena.yaml.j2", **template_ctx)
        config_path.write_text(content)
        console.print(f"  Created {config_path}")
    else:
        console.print(f"  {config_path} already exists, skipping")

    # Scaffold pyproject.toml
    pyproject_path = Path("pyproject.toml")
    if not pyproject_path.exists():
        pyproject_content = render(
            "pyproject.toml.j2",
            project_name=project_name,
            competition_slug=competition_slug,
            python_version=_env.python_version,
            agent_type=agent_type.value,
        )
        pyproject_path.write_text(pyproject_content)
        console.print(f"  Created {pyproject_path}")

    # Scaffold .python-version
    python_version_path = Path(".python-version")
    if not python_version_path.exists():
        python_version_path.write_text(f"{_env.python_version}\n")
        console.print(f"  Created {python_version_path}")

    # TODO: re-enable python agent stub when fully supported
    # if agent_type == AgentType.PYTHON:
    #     agent_dir = Path("agent")
    #     agent_dir.mkdir(exist_ok=True)
    #     (agent_dir / "__init__.py").touch()
    #     agent_main = agent_dir / "main.py"
    #     if not agent_main.exists():
    #         agent_main.write_text(render("agent_main.py.j2", project_name=project_name))
    #         console.print(f"  Created {agent_main}")

    # Run uv lock (best-effort) — only for python agents; harness agents resolve deps server-side
    if agent_type == AgentType.PYTHON:
        try:
            subprocess.run(["uv", "lock"], check=True, capture_output=True, text=True, cwd=Path.cwd())
            console.print("  Created uv.lock")
        except FileNotFoundError:
            console.print("[yellow]  Warning: 'uv' not found — install it and run 'uv lock' manually[/yellow]")
        except subprocess.CalledProcessError as e:
            console.print("[yellow]  Warning: 'uv lock' failed — run manually[/yellow]")
            if e.stderr:
                console.print(f"[dim]  {e.stderr.strip()}[/dim]")

    # Copy static scaffold files (README.md, .gitignore)
    for created in copy_statics(Path.cwd()):
        console.print(f"  Created {created.name}")

    console.print(f"\n[green]Initialized project for competition '{competition_slug}'[/green]")
    console.print(f"  Competition: {comp.name}")
    console.print(f"  Samples: {samples_path}")
    console.print("\nNext steps:")
    # TODO: re-enable python next steps when fully supported
    # if agent_type == AgentType.PYTHON:
    #     console.print("  1. Implement your agent logic in agent/main.py")
    # else:
    console.print("  1. Review arena.yaml configuration")
    console.print("  2. Run 'arena test --dry-run' to validate")
    console.print("  3. Run 'arena submit' to submit")


def pull(
    token: str | None = typer.Option(None, "--token", "-t", help="Arena API token"),
):
    """Download or update sample tasks for the current project.

    Reads the competition from arena.yaml and downloads the latest samples.
    """
    console = get_console()
    settings = get_settings()

    with handle_errors(console):
        config = load_arena_config(settings.config_filename)

    # Check existing manifest for incremental updates
    since_version = None
    manifest_path = settings.paths.manifest_path
    if manifest_path.exists():
        try:
            manifest = json.loads(manifest_path.read_text())
            since_version = manifest.get("version")
        except (json.JSONDecodeError, OSError):
            console.print("  [yellow]WARN[/yellow]  Corrupt manifest — doing full re-download")
            since_version = None

    async def _op(client, resolved_token):
        settings.paths.ensure_dirs()
        return await download_samples(
            client,
            config.competition,
            settings.paths.samples_dir,
            since_version=since_version,
            manifest_path=manifest_path,
        )

    samples_path = api_call(token, _op, console)

    console.print(f"[green]Samples updated:[/green] {samples_path}")
