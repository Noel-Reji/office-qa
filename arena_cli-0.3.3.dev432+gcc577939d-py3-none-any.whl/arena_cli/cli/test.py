from __future__ import annotations

import typer
from cli_commons.cli.errors import handle_errors, run_async
from cli_commons.output.console import get_console
from cli_commons.output.tables import format_task_status, print_run_results

from arena_cli.config.settings import get_settings
from arena_cli.harbor.runner import run_local_test
from arena_core import load_arena_config

app = typer.Typer(invoke_without_command=True)


@app.callback()
def test(
    dry_run: bool = typer.Option(False, "--dry-run", help="Validate config without running"),
    smoke: bool = typer.Option(False, "--smoke", help="Run a single task as a smoke test"),
    n: int | None = typer.Option(None, "--n", "-n", help="Number of tasks to run"),
    all_tasks: bool = typer.Option(False, "--all", help="Run all sample tasks"),
    task_filter: str | None = typer.Option(None, "--filter", help="Glob pattern to filter tasks"),
    tag: str | None = typer.Option(None, "--tag", help="Tag for this test run"),
):
    """Run agent locally using Harbor SDK.

    Validates arena.yaml, resolves samples, and executes agent tasks
    in a local Docker environment.
    """
    console = get_console()
    settings = get_settings()

    with handle_errors(console):
        config = load_arena_config(settings.config_filename)

    samples_dir = settings.paths.samples_dir
    runs_dir = settings.paths.runs_dir

    if not all_tasks and n is None and not smoke and not task_filter and not dry_run:
        n = settings.default_test_task_count

    def _on_trial_ended(event):
        task_id = getattr(event, "task_name", "unknown")
        reward = 0.0
        trial = getattr(event, "result", None)
        if trial and trial.verifier_result and trial.verifier_result.rewards:
            reward = trial.verifier_result.rewards.get("reward", 0.0) or 0.0
        status = format_task_status("passed" if reward > 0 else "failed")
        console.print(f"  {status} {task_id} (reward={reward:.2f})")

    async def _run():
        return await run_local_test(
            config=config,
            samples_dir=samples_dir,
            runs_dir=runs_dir,
            n_tasks=n,
            task_filter=task_filter,
            tag=tag,
            smoke=smoke,
            dry_run=dry_run,
            on_trial_ended=_on_trial_ended,
        )

    results = run_async(_run, console)

    if dry_run:
        console.print("[green]Dry run passed![/green] Config and environment are valid.")
    else:
        print_run_results(results, console)
