from __future__ import annotations

import fnmatch
import subprocess
import tarfile
import tempfile
from pathlib import Path

import typer
from cli_commons.cli.errors import handle_errors, run_async
from cli_commons.output.console import get_console
from rich.console import Console

from arena_cli.client.base import ArenaClient
from arena_cli.client.submissions import create_submission
from arena_cli.client.teams import get_quota
from arena_cli.config.auth import resolve_token
from arena_cli.config.settings import Settings, get_settings
from arena_core import load_arena_config
from arena_core.config import ArenaConfig
from arena_core.enums import AgentType
from arena_core.errors import SubmitError
from arena_core.models.submission_metadata import AgentMetadata, SubmissionPayload


def _build_agent_metadata(config: ArenaConfig) -> AgentMetadata:
    """Build the agent section of submission metadata, varying by agent type."""
    if config.agent.type == AgentType.HARNESS:
        return AgentMetadata(
            type=config.agent.type.value,
            import_path=config.agent.resolved_import_path,
            model=config.agent.model,
            harness_name=config.agent.harness_name,
            harness_config=config.agent.harness_kwargs or None,
            env=config.agent.env,
        )
    return AgentMetadata(
        type=config.agent.type.value,
        import_path=config.agent.import_path,
        env=config.agent.env,
    )


def _validate_before_submit(
    config: ArenaConfig,
    settings: Settings,
    console: Console,
) -> None:
    """Run pre-submit validation checks. Prints warnings for non-fatal issues."""
    from arena_core.checks import (
        check_docker,
        check_import_path,
        check_samples_dir,
    )

    warnings: list[str] = []

    # Import path — WARN only (deps may not be locally installed)
    err = check_import_path(config.agent.module, config.agent.class_name)
    if err:
        warnings.append(err)

    # Docker — WARN only
    err = check_docker()
    if err:
        warnings.append(f"{err} (not required for submit)")

    # Samples — WARN only
    err = check_samples_dir(settings.paths.samples_dir)
    if err:
        warnings.append(err)

    for w in warnings:
        console.print(f"  [yellow]WARN[/yellow]  {w}")


def _check_tarball_size(tarball_path: Path, *, max_mb: int) -> None:
    """Raise SubmitError if tarball exceeds the size limit."""
    size_mb = tarball_path.stat().st_size / (1024 * 1024)
    if size_mb > max_mb:
        raise SubmitError(
            f"Tarball too large: {size_mb:.1f} MB (limit: {max_mb} MB). "
            "Exclude large files via tarball_exclude_patterns."
        )


def _ensure_uv_lock(config: ArenaConfig, console: Console) -> None:
    """Generate uv.lock if pyproject.toml exists and uv.lock is missing.

    Skipped for harness agents — their deps are resolved server-side.
    """
    if config.agent.type == AgentType.HARNESS:
        return
    if not Path("pyproject.toml").exists():
        return
    if Path("uv.lock").exists():
        return

    console.print("  Generating uv.lock...")
    try:
        subprocess.run(["uv", "lock"], check=True, capture_output=True, text=True)
        console.print("  [green]Created uv.lock[/green]")
    except FileNotFoundError:
        console.print("  [yellow]WARN[/yellow]  'uv' not found — run 'uv lock' manually")
    except subprocess.CalledProcessError as e:
        raise SubmitError(
            "'uv lock' failed — a lock file is required for Python agents. "
            f"Run 'uv lock' manually.\n{e.stderr or ''}"
        ) from e


def submit(
    tag: list[str] | None = typer.Option(None, "--tag", help="Tags for this submission (repeatable)"),
    token: str | None = typer.Option(None, "--token", "-t", help="Arena API token"),
):
    """Package and submit agent to Arena for evaluation.

    Creates a tarball of the project and uploads it.
    """
    console = get_console()
    settings = get_settings()

    with handle_errors(console):
        config = load_arena_config(settings.config_filename)

    with handle_errors(console):
        resolved_token = resolve_token(token)

    with handle_errors(console):
        # Check quota before doing any expensive work (packaging/upload)
        async def _check_quota():
            async with ArenaClient(token=resolved_token, base_url=settings.api_url) as client:
                return await get_quota(client, config.competition)

        quota = run_async(_check_quota, console)
        if quota.remaining <= 0:
            console.print(
                f"[red]Error:[/red] Daily submission quota exceeded "
                f"({quota.used_today}/{quota.daily_limit}). "
                f"Resets at {quota.resets_at}."
            )
            raise typer.Exit(1)
        console.print(f"  Quota: {quota.used_today}/{quota.daily_limit} used today ({quota.remaining} remaining)")

    with handle_errors(console):
        # Pre-submit validation
        _validate_before_submit(config, settings, console)

        # Ensure uv.lock exists
        _ensure_uv_lock(config, console)

    # Package tarball — cleanup must happen even if size check or upload fails
    console.print("Packaging agent...")
    with handle_errors(console):
        tarball_path = _create_tarball(
            settings.tarball_exclude_patterns,
            settings.tarball_exclude_extensions,
            settings.tarball_exclude_files,
            settings.tarball_exclude_name_prefixes,
        )
    console.print(f"  Created tarball: {tarball_path}")

    try:
        with handle_errors(console):
            _check_tarball_size(tarball_path, max_mb=settings.max_tarball_size_mb)

        tags: list[str] = list(tag) if tag else []
        if config.tags:
            tags.extend(config.tags)

        payload = SubmissionPayload(
            name=config.name,
            version=config.version or "0.1.0",
            description=config.description,
            agent=_build_agent_metadata(config),
            environment=config.environment.model_dump(mode="json"),
            tags=tags,
        )
        metadata = payload.model_dump(mode="json", exclude_none=True)

        async def _submit():
            async with ArenaClient(token=resolved_token, base_url=settings.api_url) as client:
                # TODO: re-enable streaming when SSE endpoint is implemented
                return await create_submission(client, metadata, slug=config.competition, agent_tarball=tarball_path)

        result = run_async(_submit, console)
    finally:
        # Clean up tarball even if size check or upload fails
        tarball_path.unlink(missing_ok=True)

    # dashboard_url = f"{settings.dashboard_base_url}/submissions/{result.id}"
    console.print("\n[green]Submitted![/green]")
    console.print(f"  Submission ID: {result.id}")
    # console.print(f"  Dashboard:     {dashboard_url}")


def _create_tarball(
    exclude_patterns: frozenset[str],
    exclude_extensions: frozenset[str],
    exclude_files: frozenset[str],
    exclude_name_prefixes: frozenset[str] = frozenset(),
) -> Path:
    """Create a gzipped tarball of the current directory, excluding specified patterns."""
    tmp = tempfile.NamedTemporaryFile(suffix=".tar.gz", delete=False)
    tmp_path = Path(tmp.name)
    tmp.close()

    project_root = Path.cwd().resolve()

    def _filter(info: tarfile.TarInfo) -> tarfile.TarInfo | None:
        path = Path(info.name)
        # Glob pattern match (directory or path)
        for pattern in exclude_patterns:
            if any(fnmatch.fnmatch(part, pattern) for part in path.parts):
                return None
            if fnmatch.fnmatch(str(path), pattern):
                return None
        # File extension match
        if path.suffix in exclude_extensions:
            return None
        # Exact filename match
        if path.name in exclude_files:
            return None
        # Filename prefix match (e.g., .env, .env.local, .env.production)
        if any(path.name.startswith(prefix) for prefix in exclude_name_prefixes):
            return None
        # Reject symlinks pointing outside the project tree
        if info.issym() or info.islnk():
            target = (Path(info.name).parent / info.linkname).resolve()
            if not target.is_relative_to(project_root):
                return None
        return info

    try:
        with tarfile.open(tmp_path, "w:gz") as tar:
            tar.add(".", filter=_filter)
    except Exception as e:
        tmp_path.unlink(missing_ok=True)
        raise SubmitError(f"Failed to create tarball: {e}") from e

    return tmp_path
