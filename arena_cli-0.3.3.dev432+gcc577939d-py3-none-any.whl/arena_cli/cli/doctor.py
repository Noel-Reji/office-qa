from __future__ import annotations

import asyncio
from pathlib import Path

import httpx
import typer
from cli_commons.client import routes
from cli_commons.output.console import get_console

from arena_cli.client.base import ArenaClient
from arena_cli.config.auth import resolve_token
from arena_cli.config.settings import get_settings
from arena_core import load_arena_config
from arena_core.checks import check_docker, check_harbor_sdk, check_import_path
from arena_core.enums import AgentType
from arena_core.errors import ArenaError


def doctor(
    token: str | None = typer.Option(None, "--token", "-t", help="Arena API token"),
):
    """Run diagnostic checks on your Arena setup.

    Validates project structure, config, imports, Docker, Harbor SDK,
    and backend connectivity.
    """
    console = get_console()
    settings = get_settings()
    has_errors = False

    def _pass(msg: str) -> None:
        console.print(f"  [green]PASS[/green]  {msg}")

    def _fail(msg: str) -> None:
        nonlocal has_errors
        has_errors = True
        console.print(f"  [red]FAIL[/red]  {msg}")

    def _warn(msg: str) -> None:
        console.print(f"  [yellow]WARN[/yellow]  {msg}")

    def _skip(msg: str) -> None:
        console.print(f"  [dim]SKIP[/dim]  {msg}")

    # ── 1. Project structure ──────────────────────────────────────────────
    console.print("\n[bold]Project structure[/bold]")

    config_path = Path(settings.config_filename)
    if config_path.exists():
        _pass(f"{settings.config_filename} exists")
    else:
        _fail(f"{settings.config_filename} not found — run 'arena init <competition>'")

    arena_dir = settings.paths.arena_dir
    if arena_dir.exists():
        _pass(f"{arena_dir}/ directory exists")
    else:
        _warn(f"{arena_dir}/ not found — run 'arena init <competition>'")

    samples_dir = settings.paths.samples_dir
    if samples_dir.exists():
        n_tasks = sum(1 for d in samples_dir.iterdir() if d.is_dir())
        if n_tasks > 0:
            _pass(f"Samples: {n_tasks} task(s) in {samples_dir}")
        else:
            _warn("Samples directory exists but is empty — run 'arena pull'")
    else:
        _warn("Samples not downloaded — run 'arena pull'")

    runs_dir = settings.paths.runs_dir
    if runs_dir.exists():
        n_runs = sum(1 for d in runs_dir.iterdir() if d.is_dir())
        _pass(f"Runs directory: {n_runs} local run(s)")
    else:
        _pass("Runs directory: will be created on first 'arena test'")

    # ── 2. Config validation ──────────────────────────────────────────────
    console.print("\n[bold]Configuration[/bold]")

    config = None
    if config_path.exists():
        try:
            config = load_arena_config(settings.config_filename)
            if config.agent.type == AgentType.HARNESS:
                _pass(
                    f"arena.yaml valid — competition='{config.competition}', harness='{config.agent.harness_name}', model='{config.agent.model}'"
                )
            else:
                _pass(f"arena.yaml valid — competition='{config.competition}', agent='{config.agent.import_path}'")
        except ArenaError as e:
            _fail(f"arena.yaml invalid — {e}")

    # ── 3. Agent files ────────────────────────────────────────────────────
    if config:
        console.print("\n[bold]Agent files[/bold]")

        if config.agent.type == AgentType.HARNESS:
            _pass(f"Harness agent: {config.agent.harness_name}")
            _pass(f"Model: {config.agent.model}")

            # Verify harness module + class importable (arena-sdk installed)
            err = check_import_path(config.agent.module, config.agent.class_name)
            if err:
                _fail(f"{err}. Install: pip install arena-sdk")
            else:
                _pass(f"Harness class: {config.agent.module}:{config.agent.class_name}")

            # Verify optional file paths
            for field, label in (
                (config.agent.prompt_template_path, "Prompt template"),
                (config.agent.skills_dir, "Skills directory"),
            ):
                if field:
                    p = Path(field)
                    (_pass if p.exists() else _fail)(f"{label}: {p}")

            # MCP directory — per-server mcp.toml validation
            if config.agent.mcp_dir:
                mcp_path = Path(config.agent.mcp_dir)
                if mcp_path.is_dir():
                    _pass(f"MCP directory: {mcp_path}")
                    from arena_sdk.harness.mcp_utils import (
                        _SKIP_DIRS,
                        _validate_server_name,
                        parse_mcp_toml,
                    )

                    local_names = []
                    for sub in sorted(mcp_path.iterdir()):
                        if not sub.is_dir() or sub.name.startswith(".") or sub.name in _SKIP_DIRS:
                            continue
                        try:
                            _validate_server_name(sub.name)
                            cfg = parse_mcp_toml(sub)
                            deps_str = f", deps: {list(cfg.dependencies.keys())}" if cfg.has_dependencies else ""
                            _pass(f"MCP server: {sub.name}/ (entrypoint: {cfg.entrypoint}{deps_str})")
                            local_names.append(sub.name)
                        except (FileNotFoundError, ValueError) as e:
                            _fail(f"MCP server: {sub.name}/ — {e}")

                    # Check for name collisions with remote/packaged mcp_servers
                    if config.agent.mcp_servers and local_names:
                        remote_names = [s.get("name") for s in config.agent.mcp_servers if isinstance(s, dict)]
                        duplicates = set(local_names) & set(remote_names)
                        if duplicates:
                            _fail(
                                f"Duplicate MCP server names between mcp_dir and mcp_servers: "
                                f"{sorted(duplicates)}. Rename one of the duplicates."
                            )
                else:
                    _fail(f"MCP directory: {mcp_path} (not found)")
        else:
            # Python agent checks
            # Import path resolvability
            err = check_import_path(config.agent.module, config.agent.class_name)
            if err:
                _fail(err)
            else:
                _pass(f"Import path: {config.agent.import_path} loadable")

    # ── 4. Runtime dependencies ───────────────────────────────────────────
    console.print("\n[bold]Runtime dependencies[/bold]")

    err = check_docker()
    if err:
        _fail(err)
    else:
        _pass("Docker found in PATH")

    err = check_harbor_sdk()
    if err:
        _warn(err)
    else:
        _pass("Harbor SDK installed")

    # ── 5. Authentication ─────────────────────────────────────────────────
    console.print("\n[bold]Authentication[/bold]")

    resolved_token = None
    try:
        resolved_token = resolve_token(token)
        _pass("Token found")
    except ArenaError:
        _warn("Not authenticated — run 'arena auth login'")

    # ── 6. Backend connectivity ───────────────────────────────────────────
    console.print("\n[bold]Backend connectivity[/bold]")

    if resolved_token:
        api_base_url = settings.api_base_url

        async def _health():
            async with ArenaClient(
                token=resolved_token,
                base_url=api_base_url,
            ) as client:
                response = await client.get(routes.HEALTH)
                return response.status_code == 200

        try:
            healthy = asyncio.run(_health())
            if healthy:
                _pass(f"Backend reachable at {api_base_url}")
            else:
                _fail(f"Unhealthy response from {api_base_url}")
        except (httpx.HTTPError, OSError, ArenaError) as e:
            _fail(f"Cannot reach backend — {e}")
    else:
        _skip("Backend check — authenticate first")

    # ── Summary ───────────────────────────────────────────────────────────
    console.print()
    if has_errors:
        console.print("[red]Some checks failed.[/red] Fix the issues above and re-run 'arena doctor'.")
        raise typer.Exit(1)
    else:
        console.print("[green]All checks passed![/green]")
