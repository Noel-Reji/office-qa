from __future__ import annotations

import socket

import typer
from cli_commons.output.console import get_console

from arena_cli.config.settings import get_settings


def _find_available_port(host: str, start: int, end: int) -> int | None:
    for port in range(start, end + 1):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind((host, port))
                return port
        except OSError:
            continue
    return None


def _resolve_run_dir(runs_dir, run_id: str | None):
    """Resolve the run directory — latest if no run_id given."""
    if run_id:
        d = runs_dir / run_id
        if not d.exists():
            return None, f"Run '{run_id}' not found in {runs_dir}"
        return d, None

    if not runs_dir.exists():
        return None, f"No runs directory found at {runs_dir}"

    run_dirs = sorted(
        [d for d in runs_dir.iterdir() if d.is_dir()],
        key=lambda d: d.stat().st_mtime,
        reverse=True,
    )
    if not run_dirs:
        return None, "No runs found. Run 'arena test' first."

    return run_dirs[0], None


def view(
    run_id: str | None = typer.Argument(None, help="Local Run ID to view (default: latest)"),
    remote: str | None = typer.Option(None, "--remote", "-r", help="Remote submission ID to download and view"),
    slug: str | None = typer.Option(None, "--slug", "-s", help="Competition slug (for remote)"),
    token: str | None = typer.Option(None, "--token", "-t", help="Arena API token (for remote)"),
    force: bool = typer.Option(False, "--force", help="Re-download remote artifacts even if cached"),
    port: str = typer.Option("8080-8089", "--port", "-p", help="Port or port range"),
    host: str = typer.Option("127.0.0.1", "--host", help="Host to bind to"),
):
    """Resolve a local test run or remote submission's artifacts.

    By default, only the artifact location is reported. When the
    `view_interactive` setting is enabled, an interactive web UI is launched
    to browse jobs, trials, trajectories, and agent logs.

    For remote submissions, artifacts are downloaded from the API and cached
    in .arena/traces/ for subsequent views.
    """
    console = get_console()
    settings = get_settings()

    if run_id and remote:
        console.print("[red]Error:[/red] Cannot use both a run ID and --remote. Choose one.")
        raise typer.Exit(1)

    if remote:
        jobs_dir = _resolve_remote(remote, slug, token, force, settings, console)
    else:
        run_dir, err = _resolve_run_dir(settings.paths.runs_dir, run_id)
        if err:
            console.print(f"[red]Error:[/red] {err}")
            raise typer.Exit(1)
        jobs_dir = run_dir

    label = f"Submission {remote}" if remote else jobs_dir.name

    if not settings.view_interactive:
        _print_artifact_summary(console, label, jobs_dir, remote=remote is not None)
        return

    # Parse port range
    try:
        if "-" in port:
            start, end = port.split("-", 1)
            start_port, end_port = int(start), int(end)
        else:
            start_port = end_port = int(port)
    except ValueError:
        console.print(f"[red]Error:[/red] Invalid port: '{port}'. Use a number or range like '8080-8089'.")
        raise typer.Exit(1) from None

    available_port = _find_available_port(host, start_port, end_port)
    if available_port is None:
        console.print(f"[red]Error:[/red] No available port in range {start_port}-{end_port}")
        raise typer.Exit(1)

    try:
        import uvicorn
        from harbor.viewer import create_app
    except ImportError:
        console.print("[red]Error:[/red] Harbor viewer not available. Ensure harbor is installed.")
        raise typer.Exit(1) from None

    app = create_app(jobs_dir)

    console.print("[green]Starting Arena Viewer[/green]")
    console.print(f"  Source: {label}")
    console.print(f"  Server: http://{host}:{available_port}")
    console.print()

    config = uvicorn.Config(app, host=host, port=available_port, log_level="info")
    server = uvicorn.Server(config)
    server.run()


def _print_artifact_summary(console, label: str, jobs_dir, *, remote: bool) -> None:
    """Print artifact location details without launching the viewer."""
    console.print("[green]Arena artifacts ready[/green]")
    console.print(f"  Source: {label}")
    console.print(f"  Path:   {jobs_dir}")

    if jobs_dir.exists():
        entries = [p for p in jobs_dir.iterdir() if not p.name.startswith(".")]
        console.print(f"  Items:  {len(entries)}")
    else:
        console.print("  [yellow]Path does not exist on disk.[/yellow]")


def _resolve_remote(submission_id, slug, token, force, settings, console):
    """Download remote execution artifacts (cached) and return the jobs_dir path."""
    from cli_commons.cli.errors import require_slug

    from arena_cli.cli._api import api_call
    from arena_cli.client.trajectories import download_execution_artifacts

    resolved_slug = require_slug(slug, console)

    cache_dir = settings.paths.traces_dir / submission_id

    # Cache check: if directory has contents and not forcing, skip download
    if not force and cache_dir.exists() and any(cache_dir.iterdir()):
        console.print(f"  [dim]Using cached artifacts from {cache_dir}[/dim]")
        return cache_dir

    console.print(f"  Downloading execution artifacts for submission {submission_id}...")

    async def _download(client, resolved_token):
        return await download_execution_artifacts(
            client,
            submission_id=submission_id,
            slug=resolved_slug,
            dest=cache_dir,
        )

    api_call(token, _download, console)

    console.print(f"  [green]Artifacts cached at {cache_dir}[/green]")
    return cache_dir
