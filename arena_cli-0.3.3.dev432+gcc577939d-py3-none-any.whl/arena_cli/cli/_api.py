from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import TypeVar

from cli_commons.cli.errors import api_call as shared_api_call
from rich.console import Console

from arena_cli.client.base import ArenaClient
from arena_cli.config.settings import get_settings

T = TypeVar("T")


def api_call(
    token: str | None,
    fn: Callable[[ArenaClient, str], Awaitable[T]],
    console: Console | None = None,
) -> T:
    settings = get_settings()
    return shared_api_call(
        token,
        fn,
        console,
        credentials_path=settings.credentials_path,
        api_url=settings.api_url,
        client_factory=ArenaClient,
    )
