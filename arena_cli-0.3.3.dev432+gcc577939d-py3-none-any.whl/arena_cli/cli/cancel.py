from __future__ import annotations

import typer
from cli_commons.cli.errors import require_slug
from cli_commons.output.console import get_console

from arena_cli.cli._api import api_call
from arena_cli.client.submissions import cancel_submission


def cancel(
    submission_id: str = typer.Argument(help="Submission ID to cancel"),
    slug: str | None = typer.Option(None, "--slug", "-s", help="Competition slug (defaults to arena.yaml)"),
    token: str | None = typer.Option(None, "--token", "-t", help="Arena API token"),
):
    """Cancel a submission."""
    console = get_console()
    resolved_slug = require_slug(slug, console)

    async def _cancel_submission(client, resolved_token):
        return await cancel_submission(client, submission_id=submission_id, slug=resolved_slug)

    cancelled = api_call(token, _cancel_submission, console)
    console.print(f"[green]Cancelled submission:[/green] {cancelled.submission_id}")
    console.print(f"  Status: {cancelled.status}")
