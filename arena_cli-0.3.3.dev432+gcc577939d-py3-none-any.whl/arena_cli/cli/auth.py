import typer
from cli_commons.cli.errors import run_async
from cli_commons.client.auth import verify_token
from cli_commons.output.console import get_console

from arena_cli.client.base import ArenaClient
from arena_cli.config.auth import save_token
from arena_cli.config.settings import get_settings
from arena_core.errors import AuthError

app = typer.Typer()


@app.command()
def login(
    token: str = typer.Option(None, "--token", "-t", help="Arena API token (art_...)"),
):
    """Authenticate with Arena.

    Without --token: opens browser to arena.dev/auth for token.
    With --token: validates and saves the provided token.
    """
    console = get_console()

    settings = get_settings()
    if not token:
        console.print(f"Opening {settings.auth_url} in your browser...")
        import webbrowser

        webbrowser.open(settings.auth_url)
        token = typer.prompt("Paste your token")

    if not token.strip():
        console.print("[red]Error:[/red] Token cannot be empty")
        raise typer.Exit(AuthError.exit_code) from None

    async def _verify():
        async with ArenaClient(token=token, base_url=settings.api_url) as client:
            return await verify_token(client, token)

    user_info = run_async(_verify, console)

    path = save_token(token)
    console.print(f"[green]Authenticated as {user_info.email}[/green]")
    console.print(f"  Token saved to {path}")
