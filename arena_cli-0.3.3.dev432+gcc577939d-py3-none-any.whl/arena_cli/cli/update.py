"""Explicit update command for arena-cli."""

from __future__ import annotations

import typer
from cli_commons.cli.errors import handle_errors
from cli_commons.output.console import get_console
from packaging.version import InvalidVersion, Version

from arena_cli import __version__
from arena_cli.config.auth import resolve_token
from arena_cli.updater import do_upgrade, fetch_latest_version


def update(
    token: str | None = typer.Option(None, "--token", "-t", help="Arena API token"),
) -> None:
    """Check for and install the latest version of arena-cli."""
    console = get_console()

    with handle_errors(console):
        resolved_token = resolve_token(token)

    latest = fetch_latest_version(resolved_token)
    if latest is None:
        console.print("[red]Error:[/red] Could not check for updates. Check your network connection.")
        raise typer.Exit(1)

    try:
        current = Version(__version__)
    except InvalidVersion as exc:
        console.print(f"[red]Error:[/red] Invalid current version: {__version__}")
        raise typer.Exit(1) from exc

    if latest <= current:
        console.print(f"arena-cli is already up to date (v{current})")
        return

    console.print(f"Updating arena-cli {current} \u2192 {latest}...")

    if do_upgrade(resolved_token):
        console.print(f"[green]Successfully updated to arena-cli {latest}[/green]")
    else:
        from arena_cli.config.settings import get_settings

        settings = get_settings()
        bundle_url = f"{settings.api_base_url}/cli/arena-cli-latest.tar.gz"
        console.print("[red]Error:[/red] Update failed. Try re-downloading the bundle:")
        console.print(f"  curl -fSL {bundle_url} | tar xz")
        console.print("  ./install.sh")
        raise typer.Exit(1)
