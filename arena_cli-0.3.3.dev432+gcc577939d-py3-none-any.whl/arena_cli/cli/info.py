from __future__ import annotations

import typer
from cli_commons.output.console import get_console
from cli_commons.output.tables import (
    print_competition_detail,
    print_leaderboard,
    print_local_history,
    print_quota,
    print_submission_list,
)

from arena_cli.cli._api import api_call
from arena_cli.client.competitions import get_competition
from arena_cli.client.leaderboard import get_leaderboard
from arena_cli.client.submissions import list_submissions
from arena_cli.client.teams import get_quota
from arena_cli.config.settings import get_settings
from arena_core import load_arena_config
from arena_core.errors import ConfigError


def _resolve_competition_slug(slug: str | None, settings, console) -> str:
    """Resolve competition slug from argument or arena.yaml."""
    if slug:
        return slug
    try:
        config = load_arena_config(settings.config_filename)
        return config.competition
    except FileNotFoundError:
        console.print(f"[red]Error:[/red] {settings.config_filename} not found.")
        raise typer.Exit(ConfigError.exit_code) from None
    except ConfigError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(ConfigError.exit_code) from None


def history(
    competition_slug: str | None = typer.Argument(None, help="Competition slug (defaults to arena.yaml competition)"),
    local: bool = typer.Option(False, "--local", help="Show local run history from .arena/runs/"),
    limit: int = typer.Option(20, "--limit", "-n", help="Number of results to show"),
    token: str | None = typer.Option(None, "--token", "-t", help="Arena API token"),
):
    """Show submission history."""
    console = get_console()
    settings = get_settings()

    if local:
        print_local_history(settings.paths.runs_dir, limit, console)
        return

    competition_slug = _resolve_competition_slug(competition_slug, settings, console)

    async def _op(client, resolved_token):
        return await list_submissions(client, slug=competition_slug, limit=limit)

    print_submission_list(
        api_call(token, _op, console),
        console,
    )


def leaderboard(
    competition_slug: str | None = typer.Argument(None, help="Competition slug (defaults to arena.yaml competition)"),
    top: int = typer.Option(10, "--top", "-n", help="Number of top entries"),
    token: str | None = typer.Option(None, "--token", "-t", help="Arena API token"),
):
    """Show leaderboard for a competition."""
    console = get_console()
    settings = get_settings()

    competition_slug = _resolve_competition_slug(competition_slug, settings, console)

    async def _op(client, resolved_token):
        return await get_leaderboard(client, competition_slug, top=top)

    print_leaderboard(
        api_call(token, _op, console),
        console,
    )


def competition(
    competition_slug: str | None = typer.Argument(None, help="Competition slug (defaults to arena.yaml competition)"),
    token: str | None = typer.Option(None, "--token", "-t", help="Arena API token"),
):
    """Show details for a competition."""
    console = get_console()
    settings = get_settings()

    competition_slug = _resolve_competition_slug(competition_slug, settings, console)

    async def _op(client, resolved_token):
        return await get_competition(client, competition_slug)

    print_competition_detail(
        api_call(token, _op, console),
        console,
    )


def quota(
    competition_slug: str | None = typer.Argument(None, help="Competition slug (defaults to arena.yaml competition)"),
    token: str | None = typer.Option(None, "--token", "-t", help="Arena API token"),
):
    """Show daily submission quota."""
    console = get_console()
    settings = get_settings()

    competition_slug = _resolve_competition_slug(competition_slug, settings, console)

    async def _op(client, resolved_token):
        return await get_quota(client, competition_slug)

    print_quota(
        api_call(token, _op, console),
        console,
    )
