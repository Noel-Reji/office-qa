import typer

from arena_cli.cli import auth, cancel, doctor, info, init_cmd, results, submit, test, update
from arena_cli.updater import check_and_update

app = typer.Typer(
    name="arena",
    help="Arena CLI — build, test, and submit agents for evaluation.",
)


@app.callback(invoke_without_command=True)
def _root_callback(
    ctx: typer.Context,
    version: bool = typer.Option(False, "--version", "-V", help="Show version and exit", is_eager=True),
) -> None:
    if version:
        from cli_commons.output.console import get_console

        from arena_cli import __version__

        get_console().print(f"arena-cli {__version__}")
        raise typer.Exit()

    check_and_update()

    if ctx.invoked_subcommand is None:
        raise SystemExit(ctx.get_help())


# Register command groups
app.add_typer(auth.app, name="auth", help="Authentication commands")
app.command(name="init")(init_cmd.init)
app.command(name="pull")(init_cmd.pull)
app.add_typer(test.app, name="test", help="Local testing with Harbor", invoke_without_command=True)
app.command(name="submit")(submit.submit)
app.command(name="cancel")(cancel.cancel)
app.command(name="status")(results.status)
app.command(name="results")(results.results)
app.command(name="traces")(results.traces)
app.command(name="history")(info.history)
app.command(name="leaderboard")(info.leaderboard)
app.command(name="competition")(info.competition)
app.command(name="quota")(info.quota)
app.command(name="doctor")(doctor.doctor)
app.command(name="update")(update.update)
# app.command(name="view")(view.view)

if __name__ == "__main__":
    app()
