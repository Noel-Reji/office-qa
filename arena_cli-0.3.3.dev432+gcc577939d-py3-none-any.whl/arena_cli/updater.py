"""Auto-update logic for arena-cli."""

from cli_commons.updater import (
    check_and_update as run_shared_updater,
)
from cli_commons.updater import (
    configure as configure_shared_updater,
)
from cli_commons.updater import (
    do_upgrade as run_shared_upgrade,
)
from cli_commons.updater import (
    fetch_latest_version as run_shared_fetch_latest,
)

from arena_cli import __version__
from arena_cli.config.auth import resolve_token
from arena_cli.config.settings import get_settings
from arena_cli.updater_config import ArenaCliUpdaterConfig


def _configure_updater() -> None:
    configure_shared_updater(
        ArenaCliUpdaterConfig(
            api_base_url=get_settings().api_base_url,
            app_label="arena-cli",
            module_entrypoint="arena_cli.main",
            bundle_prefix="cli",
            token_resolver=resolve_token,
            current_version=__version__,
            update_fail_message="Update failed. Run `arena update` to try again.",
        )
    )


def check_and_update() -> None:
    _configure_updater()
    run_shared_updater()


def fetch_latest_version(token: str):
    _configure_updater()
    return run_shared_fetch_latest(token)


def do_upgrade(token: str) -> bool:
    _configure_updater()
    return run_shared_upgrade(token)
