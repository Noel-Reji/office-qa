"""Updater configuration for arena-cli (install root resolution)."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from cli_commons.config.install_dir import user_install_dir
from cli_commons.updater import UpdaterConfig


@dataclass(frozen=True)
class ArenaCliUpdaterConfig(UpdaterConfig):
    """Install dir from ARENA_INSTALL_DIR (default ~/.arena)."""

    def resolve_install_dir(self) -> Path:
        return user_install_dir()
