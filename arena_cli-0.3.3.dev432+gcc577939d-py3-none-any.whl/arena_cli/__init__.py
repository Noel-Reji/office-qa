"""arena-cli: CLI for the Arena agent evaluation platform."""

try:
    from arena_cli._version import __version__
except ModuleNotFoundError:  # editable install without build
    __version__ = "0.0.0-dev"
