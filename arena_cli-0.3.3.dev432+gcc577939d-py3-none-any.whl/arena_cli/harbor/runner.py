from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

from arena_core.config import ArenaConfig
from arena_core.constants import DEFAULT_TIMEOUT_PER_TASK
from arena_core.enums import AgentType, TaskStatus
from arena_core.errors import HarborError
from arena_core.models.results import RunMeta, RunResults, TaskResult

try:
    # Harbor's orchestration API (distinct from harbor.agents.base used for
    # agent subclassing in arena_sdk).
    from harbor.sdk import Harbor, HarborSDKError

    _HARBOR_AVAILABLE = True
except ImportError:
    _HARBOR_AVAILABLE = False


async def run_local_test(
    config: ArenaConfig,
    samples_dir: Path,
    runs_dir: Path,
    n_tasks: int | None = None,
    task_names: list[str] | None = None,
    task_filter: str | None = None,
    tag: str | None = None,
    smoke: bool = False,
    dry_run: bool = False,
    on_trial_ended: Callable | None = None,
) -> RunResults:
    """Run agent locally using Harbor SDK.

    Args:
        config: Parsed arena.yaml
        samples_dir: Path to samples directory (from CLI settings)
        runs_dir: Path to runs directory (from CLI settings)
        n_tasks: Number of tasks to run (--n flag)
        task_names: Specific task names to run
        task_filter: Glob pattern to filter tasks (--filter flag)
        tag: Tag for this run (--tag flag)
        smoke: If True, run exactly 1 task (--smoke flag)
        dry_run: If True, validate only, don't execute (--dry-run flag)
        on_trial_ended: Callback for progress display

    Returns:
        RunResults with scores and task details

    Raises:
        HarborError: If Harbor SDK is not available or raises any error
    """
    if smoke:
        n_tasks = 1

    if dry_run:
        errors = config.validate_environment(samples_dir=samples_dir)
        if errors:
            raise HarborError("Dry run failed:\n" + "\n".join(f"  - {e}" for e in errors))
        return RunResults(
            run_id="dry-run",
            score=0.0,
            tasks_total=0,
            tasks_passed=0,
            tasks_failed=0,
            avg_latency_sec=0.0,
            avg_cost_usd=0.0,
            total_cost_usd=0.0,
        )

    if not _HARBOR_AVAILABLE:
        raise HarborError(
            "Harbor SDK not yet available. Install harbor to use local testing.\n"
            "Use 'arena test --dry-run' for config validation without Harbor."
        )

    if task_filter and not task_names:
        task_names = _resolve_task_filter(samples_dir, task_filter)
        if not task_names:
            raise HarborError(f"Filter '{task_filter}' matched 0 tasks in {samples_dir}")

    run_id = _generate_run_id()
    run_dir = runs_dir / run_id

    try:
        h = Harbor()
        if config.agent.type == AgentType.HARNESS:
            h = h.agent(
                import_path=config.agent.resolved_import_path,
                model=config.agent.model,
                env=config.agent.env or {},
                **config.agent.harness_kwargs,
            )
        else:
            h = h.agent(import_path=config.agent.import_path)
        h = h.dataset(
            str(samples_dir),
            n_tasks=n_tasks,
            task_names=task_names,
        )
        h = h.environment(
            "docker",
            memory_mb=_parse_memory(config.environment.memory),
        )
        h = h.job_name(tag or run_id)
        h = h.jobs_dir(str(run_dir))
        h = h.timeout_multiplier(config.environment.timeout_per_task / DEFAULT_TIMEOUT_PER_TASK)

        if on_trial_ended:
            h = h.on_trial_ended(on_trial_ended)

        result = await h.run()

    except HarborSDKError as e:
        raise HarborError(f"Harbor execution failed: {e}") from e

    run_results = _convert_results(run_id, result)
    _save_run(run_dir, config, tag, run_results)

    return run_results


def _generate_run_id() -> str:
    import uuid

    ts = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    short = uuid.uuid4().hex[:6]
    return f"run-{ts}-{short}"


def _parse_memory(memory_str: str) -> int:
    """Parse memory string like '4G' or '1.5G' to MB."""
    memory_str = memory_str.upper().strip()
    if memory_str.endswith("GB"):
        return int(float(memory_str[:-2]) * 1024)
    if memory_str.endswith("GI"):
        return int(float(memory_str[:-2]) * 1024)
    if memory_str.endswith("G"):
        return int(float(memory_str[:-1]) * 1024)
    if memory_str.endswith("MB"):
        return int(float(memory_str[:-2]))
    if memory_str.endswith("MI"):
        return int(float(memory_str[:-2]))
    if memory_str.endswith("M"):
        return int(float(memory_str[:-1]))
    try:
        return int(float(memory_str))
    except ValueError:
        raise HarborError(f"Invalid memory format: '{memory_str}'. Use e.g. '4G', '512M', '1.5G'.") from None


def _resolve_task_filter(samples_dir: Path, pattern: str) -> list[str]:
    """Resolve glob pattern to task names in samples directory."""
    import fnmatch

    if not samples_dir.exists():
        return []
    all_tasks = [d.name for d in samples_dir.iterdir() if d.is_dir()]
    return [t for t in all_tasks if fnmatch.fnmatch(t, pattern)]


def _convert_results(run_id: str, job_result) -> RunResults:
    """Convert Harbor JobResult to arena RunResults."""
    tasks = []
    total_latency = 0.0
    total_cost = 0.0
    passed = 0
    failed = 0

    for trial in getattr(job_result, "trial_results", []):
        # Extract reward from verifier_result.rewards dict
        reward = 0.0
        verifier_result = getattr(trial, "verifier_result", None)
        if verifier_result and verifier_result.rewards:
            reward = verifier_result.rewards.get("reward", 0.0) or 0.0

        # Extract cost from agent_result
        cost = 0.0
        agent_result = getattr(trial, "agent_result", None)
        if agent_result:
            cost = getattr(agent_result, "cost_usd", 0.0) or 0.0

        # Calculate duration from timestamps
        latency = 0.0
        started_at = getattr(trial, "started_at", None)
        finished_at = getattr(trial, "finished_at", None)
        if started_at and finished_at:
            latency = (finished_at - started_at).total_seconds()

        # Extract error from exception_info
        error = None
        exception_info = getattr(trial, "exception_info", None)
        if exception_info:
            error = str(exception_info)

        status = TaskStatus.PASSED if reward > 0 else TaskStatus.FAILED

        if status == TaskStatus.PASSED:
            passed += 1
        else:
            failed += 1

        total_latency += latency
        total_cost += cost

        tasks.append(
            TaskResult(
                task_id=getattr(trial, "task_name", "unknown"),
                status=status,
                reward=reward,
                latency_sec=latency,
                cost_usd=cost,
                error=error,
            )
        )

    n = len(tasks) or 1
    score = passed / n

    return RunResults(
        run_id=run_id,
        score=score,
        tasks_total=len(tasks),
        tasks_passed=passed,
        tasks_failed=failed,
        avg_latency_sec=total_latency / n,
        avg_cost_usd=total_cost / n,
        total_cost_usd=total_cost,
        tasks=tasks,
    )


def _build_config_snapshot(config: ArenaConfig) -> dict:
    """Build config snapshot for run metadata, varying by agent type."""
    snapshot: dict = {
        "memory": config.environment.memory,
        "timeout_per_task": config.environment.timeout_per_task,
    }
    if config.agent.type == AgentType.PYTHON:
        snapshot["import_path"] = config.agent.import_path
    elif config.agent.type == AgentType.HARNESS:
        snapshot["harness_name"] = config.agent.harness_name
        snapshot["model"] = config.agent.model
        snapshot["harness_kwargs"] = config.agent.harness_kwargs
    if config.agent.env:
        snapshot["env"] = config.agent.env
    return snapshot


def _save_run(run_dir: Path, config: ArenaConfig, tag: str | None, results: RunResults) -> None:
    """Save run metadata and results to runs/<run-id>/."""
    run_dir.mkdir(parents=True, exist_ok=True)

    meta = RunMeta(
        run_id=results.run_id,
        tag=tag,
        agent_name=config.name,
        agent_version=config.version,
        competition=config.competition,
        timestamp=datetime.now(timezone.utc),
        n_tasks=results.tasks_total,
        config_snapshot=_build_config_snapshot(config),
    )

    with open(run_dir / "meta.json", "w") as f:
        json.dump(meta.model_dump(mode="json"), f, indent=2)

    with open(run_dir / "results.json", "w") as f:
        json.dump(results.model_dump(mode="json"), f, indent=2)
