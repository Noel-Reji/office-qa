from __future__ import annotations

import asyncio

from cli_commons.client import routes
from cli_commons.output.tables import format_task_status
from rich.console import Console
from rich.progress import BarColumn, Progress, SpinnerColumn, TextColumn

from arena_cli.client.base import ArenaClient
from arena_core.enums import SubmissionEventType

# Max seconds to wait between SSE events before assuming the stream is stalled.
_STREAM_EVENT_TIMEOUT = 300


async def stream_submission_progress(client: ArenaClient, submission_id: str, console: Console):
    """Stream SSE submission progress with a live Rich progress bar."""
    tasks_total = 0
    tasks_done = 0

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TextColumn("{task.completed}/{task.total}"),
        console=console,
    ) as progress:
        task = None

        sse = client.stream_sse(routes.SUBMISSION_STREAM.format(submission_id=submission_id))
        async for event_type, data in _with_event_timeout(sse, _STREAM_EVENT_TIMEOUT):
            if event_type == SubmissionEventType.RUNNING:
                tasks_total = data.get("tasks_total", 0)
                task = progress.add_task("Running trials...", total=tasks_total)

            elif event_type == SubmissionEventType.TRIAL_COMPLETED:
                tasks_done += 1
                reward = data.get("reward", 0.0)
                task_id = data.get("task_id", "unknown")
                status = format_task_status(data.get("status", ""))

                if task is not None:
                    progress.update(task, completed=tasks_done)

                progress.console.print(f"  {status} {task_id} (reward={reward:.2f}, {data.get('latency_sec', 0):.1f}s)")

            elif event_type == SubmissionEventType.COMPLETED:
                if task is not None:
                    progress.update(task, completed=tasks_total)
                score = data.get("score", 0.0)
                progress.console.print(f"\n  [green]Completed![/green] Score: {score:.3f}")

            elif event_type == SubmissionEventType.FAILED:
                error = data.get("error", "Unknown error")
                progress.console.print(f"\n  [red]Failed:[/red] {error}")


async def _with_event_timeout(sse_iter, timeout_sec: int):
    """Wrap an async SSE iterator with a per-event timeout.

    If no event is received within *timeout_sec*, the iterator is abandoned
    and an error is printed instead of hanging indefinitely.
    """
    aiter = sse_iter.__aiter__()
    while True:
        try:
            event = await asyncio.wait_for(aiter.__anext__(), timeout=timeout_sec)
            yield event
        except StopAsyncIteration:
            break
        except asyncio.TimeoutError:
            raise TimeoutError(
                f"No SSE event received for {timeout_sec}s — stream may be stalled. "
                "Use --no-stream to fetch results directly."
            ) from None
