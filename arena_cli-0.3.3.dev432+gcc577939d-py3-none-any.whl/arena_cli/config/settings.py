from __future__ import annotations

import functools

from cli_commons.config.install_dir import user_install_dir
from cli_commons.config.settings import ArenaPaths, ArenaSettingsBase
from pydantic_settings import BaseSettings


class ArenaCliSettings(ArenaSettingsBase):
    """User CLI settings. env.json under ARENA_INSTALL_DIR (default ~/.arena)."""

    credentials_path: str = "~/.arena/credentials"
    config_filename: str = "arena.yaml"
    paths: ArenaPaths = ArenaPaths()

    tarball_exclude_patterns: frozenset[str] = frozenset(
        {
            ".arena",
            ".git",
            "__pycache__",
            ".env",
            ".venv",
            "node_modules",
            ".mypy_cache",
            ".pytest_cache",
            ".ruff_cache",
            ".ssh",
            ".aws",
        }
    )

    tarball_exclude_extensions: frozenset[str] = frozenset({".pem", ".key", ".p12", ".pfx"})

    tarball_exclude_files: frozenset[str] = frozenset(
        {
            "credentials.json",
            ".DS_Store",
            "id_rsa",
            "id_ed25519",
            "id_ecdsa",
            "id_dsa",
        }
    )

    tarball_exclude_name_prefixes: frozenset[str] = frozenset({".env"})

    max_tarball_size_mb: int = 500

    default_test_task_count: int = 5

    # When False, `arena view` skips launching the Harbor web UI and only resolves
    # (downloading if remote) the artifacts, printing their on-disk location.
    view_interactive: bool = False

    @classmethod
    def settings_customise_sources(cls, settings_cls: type[BaseSettings], **kwargs):
        """Priority: init_settings > env vars > env.json file > defaults."""
        from pydantic_settings import JsonConfigSettingsSource

        json_path = user_install_dir() / "env.json"
        sources = [kwargs["init_settings"], kwargs["env_settings"]]
        try:
            sources.append(JsonConfigSettingsSource(settings_cls, json_file=str(json_path)))
        except Exception:
            pass
        return tuple(sources)


Settings = ArenaCliSettings


@functools.lru_cache(maxsize=1)
def get_arena_cli_settings() -> ArenaCliSettings:
    """Load user CLI settings (ARENA_* env vars; env.json from user install dir)."""
    return ArenaCliSettings()


get_settings = get_arena_cli_settings

__all__ = ["ArenaCliSettings", "ArenaPaths", "Settings", "get_settings", "get_arena_cli_settings"]
