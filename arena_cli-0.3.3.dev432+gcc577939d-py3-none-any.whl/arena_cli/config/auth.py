from __future__ import annotations

from cli_commons.config.auth import clear_token as _clear_token
from cli_commons.config.auth import resolve_token as _resolve_token
from cli_commons.config.auth import save_token as _save_token

from arena_cli.config.settings import get_settings

__all__ = ["resolve_token", "save_token", "clear_token"]


def resolve_token(token_flag: str | None = None) -> str:
    return _resolve_token(token_flag, credentials_path=get_settings().credentials_path)


def save_token(token: str):
    return _save_token(token, credentials_path=get_settings().credentials_path)


def clear_token() -> None:
    _clear_token(credentials_path=get_settings().credentials_path)
